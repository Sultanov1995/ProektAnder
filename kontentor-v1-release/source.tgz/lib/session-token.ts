import { createHmac, timingSafeEqual } from "node:crypto";

export const SESSION_COOKIE = "kontentor_session";
export type SessionPayload = { userId: string; workspaceId: string; role: string; sv: number; exp: number };

function secret() {
  const value = process.env.AUTH_SECRET;
  if (!value || value.length < 32) throw new Error("AUTH_SECRET должен содержать минимум 32 символа");
  return value;
}
function signRaw(value: string) { return createHmac("sha256", secret()).update(value).digest("base64url"); }

export function createSessionToken(input: Omit<SessionPayload,"exp">, ttlSeconds = 60 * 60 * 24 * 7) {
  const payload: SessionPayload = { ...input, exp: Math.floor(Date.now()/1000) + ttlSeconds };
  const raw = Buffer.from(JSON.stringify(payload)).toString("base64url");
  return `${raw}.${signRaw(raw)}`;
}
export function verifySessionToken(token?: string | null): SessionPayload | null {
  if (!token) return null;
  const [raw, sig] = token.split(".");
  if (!raw || !sig) return null;
  try {
    const expected = Buffer.from(signRaw(raw));
    const actual = Buffer.from(sig);
    if (expected.length !== actual.length || !timingSafeEqual(expected, actual)) return null;
    const payload = JSON.parse(Buffer.from(raw,"base64url").toString("utf8")) as SessionPayload;
    if (!payload.userId || !payload.workspaceId || !payload.role || !Number.isInteger(payload.sv) || payload.sv < 1 || !payload.exp || payload.exp <= Math.floor(Date.now()/1000)) return null;
    return payload;
  } catch { return null; }
}
