import { readMediaFile } from "@/lib/media-store";
import { textForPlatform, type PublicationRecord } from "@/lib/publication-store";
import { sendTelegramMedia, sendTelegramPost } from "@/lib/telegram";
import type { TelegramConnection } from "@/lib/telegram-vault";

export async function publishRecordToTelegram(
  record: PublicationRecord,
  connection: TelegramConnection,
): Promise<{ messageId: number; mediaMessageId?: number; publicLink?: string }> {
  if (record.channelId && record.channelId !== connection.channelId) {
    throw new Error("Подключённый Telegram-канал изменился после создания публикации.");
  }
  const text = textForPlatform(record, "telegram");
  const sent = record.media
    ? await sendTelegramMedia(connection.token, connection.channelId, text, {
        buffer: await readMediaFile(record.media),
        fileName: record.media.name,
        mimeType: record.media.mimeType,
        kind: record.media.kind,
      })
    : await sendTelegramPost(connection.token, connection.channelId, text);

  const publicLink = connection.channelUsername ? `https://t.me/${connection.channelUsername}/${sent.messageId}` : undefined;
  return { ...sent, publicLink };
}
