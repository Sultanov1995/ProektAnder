import { createHash, randomUUID } from "crypto";
import { lookup } from "dns/promises";
import { isIP } from "net";
import type { RadarFeed, RadarItem, RadarSettings } from "@/lib/radar-store";
import { listRadarItems, markRadarScanned, mergeRadarItems } from "@/lib/radar-store";

type RawFeedItem = {
  title: string;
  url: string;
  sourceName: string;
  sourceType: "news_search" | "rss";
  snippet?: string;
  publishedAt?: string;
};

function decodeEntities(value: string) {
  return value
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'")
    .replace(/&#(\d+);/g, (_, code) => String.fromCharCode(Number(code)))
    .replace(/&#x([0-9a-f]+);/gi, (_, code) => String.fromCharCode(parseInt(code, 16)));
}

function stripHtml(value = "") {
  const decoded = decodeEntities(value);
  return decoded.replace(/<br\s*\/?\s*>/gi, "\n").replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ").trim();
}

function tag(block: string, name: string) {
  const escaped = name.replace(":", "\\:");
  const match = block.match(new RegExp(`<${escaped}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${escaped}>`, "i"));
  return match ? stripHtml(match[1]) : "";
}

function atomLink(block: string) {
  const match = block.match(/<link\b[^>]*\bhref=["']([^"']+)["'][^>]*>/i);
  return match ? decodeEntities(match[1]).trim() : "";
}

function parseDate(value: string) {
  if (!value) return undefined;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? undefined : date.toISOString();
}

export function parseFeedXml(xml: string, fallbackSource: string, sourceType: RawFeedItem["sourceType"]): RawFeedItem[] {
  const isAtom = !/<item\b/i.test(xml) && /<entry\b/i.test(xml);
  const blocks = [...xml.matchAll(isAtom ? /<entry\b[^>]*>([\s\S]*?)<\/entry>/gi : /<item\b[^>]*>([\s\S]*?)<\/item>/gi)]
    .map((match) => match[1]);

  return blocks.map((block) => {
    const title = tag(block, "title").slice(0, 300);
    const url = (isAtom ? atomLink(block) : tag(block, "link")).slice(0, 2000);
    const sourceName = (tag(block, "source") || fallbackSource).slice(0, 160);
    const snippetRaw = tag(block, "description") || tag(block, "summary") || tag(block, "content:encoded");
    const snippet = snippetRaw ? snippetRaw.slice(0, 1000) : undefined;
    const publishedAt = parseDate(tag(block, "pubDate") || tag(block, "published") || tag(block, "updated"));
    return { title, url, sourceName, sourceType, snippet, publishedAt };
  }).filter((item) => item.title && item.url);
}

function normalizeText(value: string) {
  return value.toLowerCase().replace(/ё/g, "е").replace(/[^a-zа-я0-9]+/gi, " ").replace(/\s+/g, " ").trim();
}

function tokens(value: string) {
  return new Set(normalizeText(value).split(" ").filter((word) => word.length > 2));
}

function jaccard(a: string, b: string) {
  const left = tokens(a); const right = tokens(b);
  if (!left.size || !right.size) return 0;
  let intersection = 0;
  for (const word of left) if (right.has(word)) intersection += 1;
  return intersection / (left.size + right.size - intersection);
}

function clamp(value: number) { return Math.max(0, Math.min(1, value)); }

function freshnessScore(publishedAt?: string) {
  if (!publishedAt) return 0.45;
  const ageHours = Math.max(0, (Date.now() - new Date(publishedAt).getTime()) / 36e5);
  if (ageHours <= 12) return 1;
  if (ageHours <= 24) return 0.9;
  if (ageHours <= 72) return 0.76;
  if (ageHours <= 168) return 0.58;
  if (ageHours <= 720) return 0.35;
  return 0.15;
}

function relevanceScore(item: RawFeedItem, topics: string[]) {
  const haystack = normalizeText(`${item.title} ${item.snippet || ""}`);
  if (!topics.length) return { score: 0.5, matched: [] as string[] };
  const matched = topics.filter((topic) => {
    const topicWords = [...tokens(topic)];
    return topicWords.length > 0 && topicWords.filter((word) => haystack.includes(word)).length / topicWords.length >= 0.5;
  });
  const title = normalizeText(item.title);
  const titleBoost = topics.some((topic) => [...tokens(topic)].some((word) => title.includes(word))) ? 0.22 : 0;
  return { score: clamp(0.2 + matched.length / Math.max(1, topics.length) * 0.62 + titleBoost), matched };
}

function qualityScore(item: RawFeedItem) {
  let score = item.sourceType === "rss" ? 0.72 : 0.64;
  if (item.snippet && item.snippet.length > 80) score += 0.12;
  if (item.title.length >= 25 && item.title.length <= 160) score += 0.08;
  if (item.publishedAt) score += 0.05;
  return clamp(score);
}

function excluded(item: RawFeedItem, words: string[]) {
  const value = normalizeText(`${item.title} ${item.snippet || ""}`);
  return words.some((word) => normalizeText(word) && value.includes(normalizeText(word)));
}

function fingerprint(title: string) {
  return createHash("sha256").update(normalizeText(title)).digest("hex").slice(0, 32);
}

function privateIPv4(ip: string) {
  const [a, b] = ip.split(".").map(Number);
  return a === 10 || a === 127 || a === 0 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127) || a >= 224;
}

function privateIp(ip: string) {
  if (isIP(ip) === 4) return privateIPv4(ip);
  const value = ip.toLowerCase();
  return value === "::1" || value === "::" || value.startsWith("fc") || value.startsWith("fd") || value.startsWith("fe8") || value.startsWith("fe9") || value.startsWith("fea") || value.startsWith("feb");
}

export async function assertPublicFeedUrl(input: string) {
  const url = new URL(input);
  if (!["http:", "https:"].includes(url.protocol)) throw new Error("RSS-адрес должен начинаться с http:// или https://");
  const hostname = url.hostname.toLowerCase();
  if (hostname === "localhost" || hostname.endsWith(".local") || hostname.endsWith(".internal")) throw new Error("Локальные адреса нельзя использовать как RSS-источник");
  if (isIP(hostname) && privateIp(hostname)) throw new Error("Приватные IP-адреса нельзя использовать как RSS-источник");
  if (!isIP(hostname)) {
    const records = await lookup(hostname, { all: true, verbatim: true });
    if (!records.length || records.some((record) => privateIp(record.address))) throw new Error("RSS-источник ведёт на недоступный локальный адрес");
  }
  return url;
}

async function fetchXml(url: URL, validateRedirects = false) {
  let current = url;
  for (let hop = 0; hop < 5; hop += 1) {
    const response = await fetch(current, {
      headers: { "user-agent": "KONTENTOR-Radar/0.4 (+RSS reader)" },
      signal: AbortSignal.timeout(12000), cache: "no-store", redirect: validateRedirects ? "manual" : "follow",
    });
    if (validateRedirects && response.status >= 300 && response.status < 400) {
      const location = response.headers.get("location");
      if (!location) throw new Error("RSS-источник вернул редирект без адреса");
      current = await assertPublicFeedUrl(new URL(location, current).toString());
      continue;
    }
    if (!response.ok) throw new Error(`Источник вернул HTTP ${response.status}`);
    const length = Number(response.headers.get("content-length") || 0);
    if (length > 2_000_000) throw new Error("RSS-источник слишком большой");
    const text = await response.text();
    if (text.length > 2_000_000) throw new Error("RSS-источник слишком большой");
    return text;
  }
  throw new Error("Слишком много перенаправлений RSS-источника");
}

async function fetchCustomFeed(feed: RadarFeed) {
  const url = await assertPublicFeedUrl(feed.url);
  const xml = await fetchXml(url, true);
  return parseFeedXml(xml, feed.name, "rss");
}

async function fetchNewsTopic(topic: string) {
  const url = new URL("https://news.google.com/rss/search");
  url.searchParams.set("q", topic);
  url.searchParams.set("hl", "ru");
  url.searchParams.set("gl", "RU");
  url.searchParams.set("ceid", "RU:ru");
  const xml = await fetchXml(url);
  return parseFeedXml(xml, "Новости по теме", "news_search").slice(0, 30);
}

export async function scanRadar(settings: RadarSettings, workspaceId?: string) {
  const topics = settings.topics.map((topic) => topic.trim()).filter(Boolean).slice(0, 12);
  if (!topics.length && !settings.feeds.some((feed) => feed.enabled)) throw new Error("Добавьте хотя бы одну тему или RSS-источник");

  const settled = await Promise.allSettled([
    ...topics.map((topic) => fetchNewsTopic(topic)),
    ...settings.feeds.filter((feed) => feed.enabled).slice(0, 20).map((feed) => fetchCustomFeed(feed)),
  ]);
  const raw = settled.flatMap((result) => result.status === "fulfilled" ? result.value : []);
  const errors = settled.flatMap((result) => result.status === "rejected" ? [result.reason instanceof Error ? result.reason.message : "Источник недоступен"] : []);
  const existing = await listRadarItems(workspaceId);
  const seenTitles: string[] = existing.map((item) => item.title);
  const seenFingerprints = new Set(existing.map((item) => item.fingerprint));
  const localFingerprints = new Set<string>();
  const now = new Date().toISOString();
  const items: RadarItem[] = [];

  for (const candidate of raw) {
    if (excluded(candidate, settings.excludeKeywords)) continue;
    const fp = fingerprint(candidate.title);
    if (seenFingerprints.has(fp) || localFingerprints.has(fp)) continue;
    const maxSimilarity = seenTitles.reduce((max, title) => Math.max(max, jaccard(candidate.title, title)), 0);
    if (maxSimilarity >= 0.82) continue;

    const relevance = relevanceScore(candidate, topics);
    if (topics.length && candidate.sourceType === "news_search" && relevance.matched.length === 0) continue;
    const novelty = clamp(1 - maxSimilarity);
    const freshness = freshnessScore(candidate.publishedAt);
    const quality = qualityScore(candidate);
    const score = clamp(relevance.score * 0.45 + novelty * 0.28 + freshness * 0.17 + quality * 0.10);
    if (score < 0.38) continue;

    items.push({
      id: randomUUID(), fingerprint: fp, title: candidate.title, url: candidate.url,
      sourceName: candidate.sourceName, sourceType: candidate.sourceType, snippet: candidate.snippet,
      publishedAt: candidate.publishedAt, discoveredAt: now, matchedTopics: relevance.matched,
      relevance: relevance.score, novelty, freshness, quality, score, status: "new",
    });
    localFingerprints.add(fp); seenTitles.push(candidate.title);
  }

  const ranked = items.sort((a, b) => b.score - a.score).slice(0, 100);
  const merged = await mergeRadarItems(ranked, workspaceId);
  await markRadarScanned(now, workspaceId);
  return { found: raw.length, accepted: ranked.length, added: merged.added, errors: errors.slice(0, 8), items: ranked.slice(0, 20) };
}
