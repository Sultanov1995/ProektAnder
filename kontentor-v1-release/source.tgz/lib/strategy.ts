import { listAudienceSnapshots } from "@/lib/analytics-store";
import { getAutomationSettings } from "@/lib/automation-store";
import { listMtprotoSnapshots } from "@/lib/mtproto-store";
import { listInstagramInsights } from "@/lib/instagram-insights";
import { getInstagramConnection } from "@/lib/instagram-vault";
import { createWeeklyStrategyWithAI } from "@/lib/openai";
import { listPublications } from "@/lib/publication-store";
import { listRadarItems } from "@/lib/radar-store";
import { saveWeeklyStrategy } from "@/lib/strategy-store";
import { getTelegramConnection } from "@/lib/telegram-vault";
import { getValidVkConnection } from "@/lib/vk-vault";
import { listVkAnalytics } from "@/lib/vk-analytics";
import { getValidYouTubeConnection } from "@/lib/youtube-vault";
import { listYouTubeInsights } from "@/lib/youtube-insights";
import { nextSevenDates, weekdayInZone, weekStartInZone } from "@/lib/timezone";

export async function generateWeeklyStrategy(workspaceId?: string) {
  const settings = await getAutomationSettings(workspaceId);
  const connection = await getTelegramConnection(workspaceId);
  const instagramConnection = await getInstagramConnection(workspaceId);
  const vkConnection = await getValidVkConnection(workspaceId);
  const youtubeConnection = await getValidYouTubeConnection(workspaceId);
  if (!connection && !instagramConnection && !vkConnection && !youtubeConnection) throw new Error("Подключите хотя бы одну соцсеть перед генерацией стратегии.");
  const weekStart = weekStartInZone(new Date(), settings.timezone);
  const dates = nextSevenDates(weekStart);

  const [audience, detailed, instagramInsights, vkInsights, youtubeInsights, publications, radar] = await Promise.all([
    connection ? listAudienceSnapshots(connection.channelId, workspaceId) : Promise.resolve([]),
    connection ? listMtprotoSnapshots(connection.channelUsername ? `@${connection.channelUsername}` : connection.channelId, workspaceId) : Promise.resolve([]),
    instagramConnection ? listInstagramInsights(instagramConnection.userId, workspaceId) : Promise.resolve([]),
    vkConnection ? listVkAnalytics(vkConnection.groupId, 90, workspaceId) : Promise.resolve([]),
    youtubeConnection ? listYouTubeInsights(youtubeConnection.channelId, 90, workspaceId) : Promise.resolve([]),
    listPublications(workspaceId),
    listRadarItems(workspaceId),
  ]);

  const firstAudience = audience[0];
  const lastAudience = audience[audience.length - 1];
  const latestDetailed = detailed[detailed.length - 1];
  const latestInstagram = instagramInsights[instagramInsights.length - 1];
  const latestVk = vkInsights[vkInsights.length - 1];
  const latestYouTube = youtubeInsights[youtubeInsights.length - 1];
  const recentPublications = publications
    .filter((item) => item.status === "published" || item.status === "partial" || item.status === "failed")
    .slice(0, 20)
    .map((item) => ({
      date: (item.publishedAt || item.createdAt).slice(0, 10),
      text: item.text,
      status: item.status,
      platforms: item.platforms || ["telegram"],
    }));
  const radarItems = radar
    .filter((item) => item.status !== "skipped" && Math.round(item.score * 100) >= settings.radarMinScore)
    .slice(0, 16)
    .map((item) => ({
      id: item.id,
      title: item.title,
      score: Math.round(item.score * 100),
      url: item.url,
      snippet: item.snippet,
    }));

  const result = await createWeeklyStrategyWithAI({
    weekStart,
    dates,
    timezone: settings.timezone,
    preferredTimes: settings.preferredTimes,
    dailyLimit: settings.dailyLimit,
    allowWeekend: settings.allowWeekend,
    connectedPlatforms: [connection ? "telegram" : null, instagramConnection ? "instagram" : null, vkConnection ? "vk" : null, youtubeConnection ? "youtube" : null].filter(Boolean) as Array<"telegram" | "instagram" | "vk" | "youtube">,
    channelTitle: connection?.channelTitle,
    instagramUsername: instagramConnection?.username,
    vkGroupName: vkConnection?.groupName,
    youtubeChannelTitle: youtubeConnection?.channelTitle,
    audience: {
      currentMembers: lastAudience?.members,
      delta: firstAudience && lastAudience ? lastAudience.members - firstAudience.members : undefined,
    },
    detailedStats: latestDetailed ? {
      viewsPerPost: latestDetailed.viewsPerPost?.current,
      sharesPerPost: latestDetailed.sharesPerPost?.current,
      reactionsPerPost: latestDetailed.reactionsPerPost?.current,
      enabledNotificationsPercent: latestDetailed.enabledNotifications?.percent,
    } : undefined,
    instagramStats: latestInstagram ? {
      followers: latestInstagram.followers,
      reach: latestInstagram.metrics?.reach,
      views: latestInstagram.metrics?.views,
      accountsEngaged: latestInstagram.metrics?.accounts_engaged,
      totalInteractions: latestInstagram.metrics?.total_interactions,
    } : undefined,
    vkStats: latestVk ? { members: latestVk.members, viewsPerPost: latestVk.averages?.viewsPerPost, likesPerPost: latestVk.averages?.likesPerPost, commentsPerPost: latestVk.averages?.commentsPerPost, repostsPerPost: latestVk.averages?.repostsPerPost } : undefined,
    youtubeStats: latestYouTube ? { subscribers: latestYouTube.subscribers, views: latestYouTube.metrics?.views, watchMinutes: latestYouTube.metrics?.estimatedMinutesWatched, likes: latestYouTube.metrics?.likes, comments: latestYouTube.metrics?.comments, shares: latestYouTube.metrics?.shares, subscribersGained: latestYouTube.metrics?.subscribersGained, subscribersLost: latestYouTube.metrics?.subscribersLost } : undefined,
    recentPublications,
    radarItems,
  });

  const allowedDates = new Set(dates);
  const radarById = new Map<string, { id: string; url: string }>(radarItems.map((item) => [item.id, { id: item.id, url: item.url }]));
  const perDay = new Map<string, number>();
  const safePosts = result.posts
    .filter((post) => allowedDates.has(post.date))
    .filter((post) => /^([01]\d|2[0-3]):[0-5]\d$/.test(post.time))
    .filter((post) => {
      if (!settings.allowWeekend) {
        const day = weekdayInZone(new Date(`${post.date}T12:00:00Z`), settings.timezone);
        if (day === "Sat" || day === "Sun") return false;
      }
      const count = perDay.get(post.date) || 0;
      if (count >= settings.dailyLimit) return false;
      perDay.set(post.date, count + 1);
      return true;
    })
    .slice(0, 12)
    .map((post) => {
      const source = post.sourceRadarId ? radarById.get(post.sourceRadarId) : undefined;
      return {
        ...post,
        platforms: (post.platforms || ["telegram"]).filter((platform) => platform === "telegram" ? Boolean(connection) : platform === "instagram" ? Boolean(instagramConnection) : platform === "vk" ? Boolean(vkConnection) : platform === "youtube" ? Boolean(youtubeConnection) : false),
        sourceRadarId: source?.id || "",
        sourceUrl: source?.url || "",
        id: "",
        status: "planned" as const,
      };
    });

  if (safePosts.length < 4) throw new Error("ИИ-стратег вернул слишком мало корректных публикаций. Повторите генерацию.");

  return saveWeeklyStrategy({
    weekStart,
    summary: result.summary,
    focus: result.focus,
    actions: result.actions.slice(0, 6),
    posts: safePosts,
  }, workspaceId);
}
