import { createHash } from "node:crypto";
import { db } from "@/lib/db";

export type RateLimitResult = { allowed: true } | { allowed: false; retryAfter: number };

type Options = { scope: string; subject: string; limit: number; windowMs: number; blockMs?: number };

function key(scope: string, subject: string) {
  return createHash("sha256").update(`${scope}:${subject}`).digest("hex");
}

export function clientIp(request: Request) {
  const forwarded = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim();
  return forwarded || request.headers.get("x-real-ip")?.trim() || "unknown";
}

export async function hitRateLimit({ scope, subject, limit, windowMs, blockMs = windowMs }: Options): Promise<RateLimitResult> {
  const id = key(scope, subject);
  const now = new Date();
  const existing = await db.authRateLimit.findUnique({ where: { id } });

  if (existing?.blockedUntil && existing.blockedUntil > now) {
    return { allowed: false, retryAfter: Math.max(1, Math.ceil((existing.blockedUntil.getTime() - now.getTime()) / 1000)) };
  }

  if (!existing || now.getTime() - existing.windowStartedAt.getTime() >= windowMs) {
    await db.authRateLimit.upsert({
      where: { id },
      create: { id, scope, attempts: 1, windowStartedAt: now, blockedUntil: null },
      update: { scope, attempts: 1, windowStartedAt: now, blockedUntil: null },
    });
    return { allowed: true };
  }

  const attempts = existing.attempts + 1;
  if (attempts > limit) {
    const blockedUntil = new Date(now.getTime() + blockMs);
    await db.authRateLimit.update({ where: { id }, data: { attempts, blockedUntil } });
    return { allowed: false, retryAfter: Math.max(1, Math.ceil(blockMs / 1000)) };
  }

  await db.authRateLimit.update({ where: { id }, data: { attempts } });
  return { allowed: true };
}

export async function clearRateLimit(scope: string, subject: string) {
  await db.authRateLimit.delete({ where: { id: key(scope, subject) } }).catch(() => undefined);
}
