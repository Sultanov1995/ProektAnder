import { mkdir, readFile, rm, writeFile } from "fs/promises";
import path from "path";
import { randomUUID } from "crypto";
import { GetObjectCommand, PutObjectCommand, DeleteObjectCommand, S3Client } from "@aws-sdk/client-s3";
import type { MediaKind, StoredMedia } from "@/lib/publication-store";

const dataDir = process.env.KONTENTOR_DATA_DIR || path.join(process.cwd(), ".data");
const uploadsDir = path.join(dataDir, "uploads");
const imageTypes = new Set(["image/jpeg", "image/png", "image/webp"]);
const videoTypes = new Set(["video/mp4"]);

function mediaKind(mimeType: string): MediaKind {
  if (imageTypes.has(mimeType)) return "photo";
  if (videoTypes.has(mimeType)) return "video";
  throw new Error("Поддерживаются JPG, PNG, WEBP и MP4.");
}

function extension(name: string, mimeType: string) {
  const ext = path.extname(name).toLowerCase().replace(/[^.a-z0-9]/g, "");
  if (ext) return ext.slice(0, 8);
  if (mimeType === "image/jpeg") return ".jpg";
  if (mimeType === "image/png") return ".png";
  if (mimeType === "image/webp") return ".webp";
  if (mimeType === "video/mp4") return ".mp4";
  return "";
}

export function validateMediaFile(file: File) {
  const kind = mediaKind(file.type);
  const max = kind === "photo" ? 10 * 1024 * 1024 : 50 * 1024 * 1024;
  if (file.size <= 0) throw new Error("Медиафайл пустой.");
  if (file.size > max) throw new Error(kind === "photo" ? "Фото должно быть не больше 10 МБ." : "Видео должно быть не больше 50 МБ.");
  return kind;
}

function s3Enabled() {
  return Boolean(process.env.S3_BUCKET && process.env.S3_ENDPOINT && process.env.S3_ACCESS_KEY_ID && process.env.S3_SECRET_ACCESS_KEY);
}

function s3() {
  if (!s3Enabled()) throw new Error("S3-хранилище не настроено");
  return new S3Client({
    region: process.env.S3_REGION || "ru-1",
    endpoint: process.env.S3_ENDPOINT,
    forcePathStyle: process.env.S3_FORCE_PATH_STYLE === "1",
    credentials: { accessKeyId: process.env.S3_ACCESS_KEY_ID!, secretAccessKey: process.env.S3_SECRET_ACCESS_KEY! },
  });
}

function bucket() { return process.env.S3_BUCKET!; }

export async function saveMediaBuffer(input: { buffer: Buffer; name: string; mimeType: string; source?: string; persistent?: boolean }): Promise<StoredMedia> {
  const kind = mediaKind(input.mimeType);
  const max = kind === "photo" ? 10 * 1024 * 1024 : 50 * 1024 * 1024;
  if (!input.buffer.length || input.buffer.length > max) throw new Error(kind === "photo" ? "Фото должно быть не больше 10 МБ." : "Видео должно быть не больше 50 МБ.");
  const objectKey = `media/${new Date().toISOString().slice(0,10)}/${randomUUID()}${extension(input.name, input.mimeType)}`;
  if (s3Enabled()) {
    await s3().send(new PutObjectCommand({ Bucket: bucket(), Key: objectKey, Body: input.buffer, ContentType: input.mimeType, CacheControl: "private, max-age=31536000" }));
    return { path: objectKey, name: input.name, mimeType: input.mimeType, size: input.buffer.length, kind, storage: "s3", persistent: Boolean(input.persistent) };
  }
  await mkdir(uploadsDir, { recursive: true });
  const relative = path.join("uploads", path.basename(objectKey));
  await writeFile(path.join(dataDir, relative), input.buffer);
  return { path: relative, name: input.name, mimeType: input.mimeType, size: input.buffer.length, kind, storage: "local", persistent: Boolean(input.persistent) };
}

export async function saveMediaFile(file: File): Promise<StoredMedia> {
  validateMediaFile(file);
  return saveMediaBuffer({ buffer: Buffer.from(await file.arrayBuffer()), name: file.name || `media${extension("", file.type)}`, mimeType: file.type });
}

function safeAbsolute(relative: string) {
  const absolute = path.resolve(dataDir, relative);
  const root = path.resolve(dataDir) + path.sep;
  if (!absolute.startsWith(root)) throw new Error("Некорректный путь к медиафайлу.");
  return absolute;
}

async function bodyToBuffer(body: any) {
  if (!body) throw new Error("Пустой ответ S3");
  if (typeof body.transformToByteArray === "function") return Buffer.from(await body.transformToByteArray());
  const chunks: Buffer[] = [];
  for await (const chunk of body as AsyncIterable<Uint8Array>) chunks.push(Buffer.from(chunk));
  return Buffer.concat(chunks);
}

export async function readMediaFile(media: StoredMedia) {
  if (media.storage === "s3") {
    const result = await s3().send(new GetObjectCommand({ Bucket: bucket(), Key: media.path }));
    return bodyToBuffer(result.Body);
  }
  return readFile(safeAbsolute(media.path));
}

export async function deleteMediaFile(media?: StoredMedia) {
  if (!media || media.persistent) return;
  if (media.storage === "s3") {
    await s3().send(new DeleteObjectCommand({ Bucket: bucket(), Key: media.path }));
    return;
  }
  await rm(safeAbsolute(media.path), { force: true });
}

export function mediaStorageMode() { return s3Enabled() ? "s3" : "local"; }
