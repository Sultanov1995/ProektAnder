import { db } from "@/lib/db";
import { resolveWorkspaceId } from "@/lib/workspace-context";

export type AnalysisNetwork = "telegram" | "instagram" | "vk" | "youtube";
export type AnalysisMetric = { label: string; value: string; note?: string };
export type AnalysisTopItem = { title: string; metric: string; link?: string };
export type ChannelAnalysis = {
  id?: string;
  network: AnalysisNetwork;
  capturedAt: string;
  account: { id: string; title: string; username?: string };
  dataLevel: "Базовый" | "Расширенный";
  headline: string;
  summary: string;
  metrics: AnalysisMetric[];
  strengths: string[];
  risks: string[];
  recommendations: string[];
  topContent: AnalysisTopItem[];
  limitations: string[];
};

const networkEnum = (network: AnalysisNetwork) => network.toUpperCase() as "TELEGRAM" | "INSTAGRAM" | "VK" | "YOUTUBE";

export async function saveChannelAnalysis(input: ChannelAnalysis, workspaceId?: string) {
  const ws = await resolveWorkspaceId(workspaceId);
  const row = await db.analyticsEvent.create({
    data: {
      workspaceId: ws,
      network: networkEnum(input.network),
      accountRef: input.account.id,
      kind: "channel_analysis",
      capturedAt: new Date(input.capturedAt),
      payload: JSON.parse(JSON.stringify(input)),
    },
  });
  return { ...input, id: row.id };
}

export async function getLatestChannelAnalysis(network: AnalysisNetwork, accountRef?: string, workspaceId?: string): Promise<ChannelAnalysis | null> {
  const ws = await resolveWorkspaceId(workspaceId);
  const row = await db.analyticsEvent.findFirst({
    where: {
      workspaceId: ws,
      network: networkEnum(network),
      kind: "channel_analysis",
      ...(accountRef ? { accountRef } : {}),
    },
    orderBy: { capturedAt: "desc" },
  });
  if (!row) return null;
  return { ...(row.payload as unknown as ChannelAnalysis), id: row.id, capturedAt: row.capturedAt.toISOString() };
}

export function numberRu(value: number | undefined, digits = 0) {
  return value === undefined || !Number.isFinite(value) ? "—" : value.toLocaleString("ru-RU", { maximumFractionDigits: digits });
}

export function percentRu(value: number | undefined, digits = 1) {
  return value === undefined || !Number.isFinite(value) ? "—" : `${value.toLocaleString("ru-RU", { maximumFractionDigits: digits })}%`;
}
