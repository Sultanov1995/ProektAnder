import { randomUUID } from "crypto";
import { db } from "@/lib/db";
import { addAudienceSnapshot, listAudienceSnapshots } from "@/lib/analytics-store";
import { getAutomationSettings } from "@/lib/automation-store";
import { getInstagramConnection } from "@/lib/instagram-vault";
import { captureInstagramInsights, listInstagramInsights } from "@/lib/instagram-insights";
import { isMtprotoConfigured, fetchTelegramBroadcastStats } from "@/lib/mtproto";
import { listMtprotoSnapshots } from "@/lib/mtproto-store";
import { createChannelIntelligenceWithAI, type ChannelIntelligenceAIResult } from "@/lib/openai";
import { cancelPublication, createPublication, listPublications, type SocialPlatform } from "@/lib/publication-store";
import { listRadarItems } from "@/lib/radar-store";
import { getTelegramConnection } from "@/lib/telegram-vault";
import { getTelegramChatDetails, getTelegramMemberCount } from "@/lib/telegram";
import { dateKeyInZone, zonedLocalToUtc } from "@/lib/timezone";
import { getValidVkConnection } from "@/lib/vk-vault";
import { fetchVkAnalytics, listVkAnalytics, saveVkAnalytics } from "@/lib/vk-analytics";
import { getValidYouTubeConnection } from "@/lib/youtube-vault";
import { fetchYouTubeAnalytics, fetchYouTubeRecentVideos } from "@/lib/youtube";
import { listYouTubeInsights, saveYouTubeInsights } from "@/lib/youtube-insights";
import { resolveWorkspaceId } from "@/lib/workspace-context";
import { getChannelAnalysis, saveChannelAnalysis, type ChannelAnalysis, type ChannelAnalysisNetwork } from "@/lib/channel-analysis-store";

function nextDates(timezone: string, count = 5) {
  const baseKey = dateKeyInZone(new Date(), timezone);
  const base = new Date(`${baseKey}T12:00:00Z`);
  return Array.from({ length: count }, (_, index) => {
    const d = new Date(base);
    d.setUTCDate(d.getUTCDate() + index + 1);
    return d.toISOString().slice(0, 10);
  });
}

function metric(label: string, value: unknown) {
  if (value === undefined || value === null || value === "") return null;
  const shown = typeof value === "number" ? value.toLocaleString("ru-RU", { maximumFractionDigits: 1 }) : String(value);
  return { label, value: shown };
}

function platformsFor(network: ChannelAnalysisNetwork): SocialPlatform[] { return [network]; }

const RU_STOP = new Set("который которая которые чтобы этот эта это для как что или при уже ещё еще если только после перед очень есть быть были было будет ваш ваша ваши наш наша наши канал пост видео фото контент публикация публикации сегодня сейчас можно нужно надо через без про под над его ее их мы вы они он она оно где когда почему поэтому также такой такая такие здесь тогда более менее".split(/\s+/));
function keywordsFrom(samples: Array<{ text: string }>, extra = "") {
  const words = `${extra} ${samples.map((x) => x.text).join(" ")}`.toLowerCase().match(/[а-яёa-z0-9-]{5,}/gi) || [];
  const counts = new Map<string, number>();
  for (const raw of words) { const w = raw.replace(/^-+|-+$/g, ""); if (!w || RU_STOP.has(w) || /^https?/.test(w)) continue; counts.set(w, (counts.get(w) || 0) + 1); }
  return [...counts.entries()].sort((a,b)=>b[1]-a[1]).slice(0,6).map(([w])=>w);
}
function fallbackIntelligence(input:{network:ChannelAnalysisNetwork;accountLabel:string;niche?:string;dates:string[];times:string[];metrics:Record<string,unknown>;samples:Array<{text:string}>;notes:string[]}):ChannelIntelligenceAIResult {
  const extra = `${input.niche || ""} ${String((input.metrics as any).description || "")}`;
  const words = keywordsFrom(input.samples, extra);
  const niche = input.niche?.trim() || (words.length ? words.slice(0,3).join(" / ") : `тематика ${input.accountLabel}`);
  const theme = input.niche?.trim() || words[0] || "вашей тематике";
  const second = words[1] || "практике";
  const sampleCount = input.samples.length;
  const formats:Record<ChannelAnalysisNetwork,Array<{format:string;reason:string;frequency:string}>>={
    telegram:[{format:"Экспертный пост",reason:"Подходит для объяснений, чек-листов и разборов.",frequency:"3–4 раза в неделю"},{format:"Короткий вовлекающий пост",reason:"Помогает получать обратную связь и находить вопросы аудитории.",frequency:"1–2 раза в неделю"}],
    instagram:[{format:"Карусель",reason:"Удобна для пошаговых разборов и сохранений.",frequency:"2 раза в неделю"},{format:"Reel",reason:"Подходит для короткой демонстрации результата или совета.",frequency:"2–3 раза в неделю"}],
    vk:[{format:"Полезный разбор",reason:"Подходит для стены сообщества и обсуждений.",frequency:"3 раза в неделю"},{format:"Кейс / вопрос",reason:"Повышает вовлечение и комментарии.",frequency:"1–2 раза в неделю"}],
    youtube:[{format:"Short",reason:"Подходит для одной практической мысли или быстрого разбора.",frequency:"2–3 раза в неделю"},{format:"Разбор 5–10 минут",reason:"Помогает раскрывать экспертность глубже.",frequency:"1 раз в неделю"}],
  };
  const make=(i:number,topic:string,body:string,format:string,visualBrief:string)=>({date:input.dates[i],time:input.times[i%Math.max(1,input.times.length)]||"19:00",topic,angle:"Практично и без выдуманных фактов",objective:i===3?"Вовлечение":"Экспертность и польза",format,hook:body.split("\n")[0],material:body,visualBrief,cta:i===3?"Попросите аудиторию ответить в комментариях или реакциях.":"Предложите сохранить материал и следить за продолжением."});
  const platform = input.network;
  const items=[
    make(0,`Главные ошибки в теме «${theme}»`,`3 ошибки, которые чаще всего мешают получить хороший результат в теме «${theme}».\n\n1. Начинать без понятной цели.\n2. Копировать чужой подход без учёта своей ситуации.\n3. Оценивать результат слишком рано.\n\nСильнее работает простой цикл: цель → действие → измерение → корректировка. Начните с одного изменения и посмотрите, что оно даёт на практике.`,platform==="youtube"?"Short / короткий разбор":"Экспертный пост",`Чистый визуал: заголовок «3 ошибки», три крупных тезиса, фирменный стиль KONTENTOR.`),
    make(1,`Чек-лист по ${theme}`,`Мини-чек-лист перед тем, как двигаться дальше в теме «${theme}».\n\n— Что именно вы хотите получить?\n— Как поймёте, что результат стал лучше?\n— Какой один шаг можно сделать уже сегодня?\n— Что точно не нужно усложнять?\n— Какую обратную связь стоит собрать?\n\nТакой подход помогает не распыляться и быстрее понимать, что действительно работает.`,platform==="instagram"?"Карусель":"Чек-лист",`Карточки 1–6: обложка и по одному пункту чек-листа на слайд.`),
    make(2,`Практический разбор: ${second}`,`Практический принцип, который полезно проверить в своей работе: «сначала понятность — потом усложнение».\n\nЕсли процесс нельзя объяснить простыми словами, его трудно повторять и улучшать. Разбейте задачу на небольшие этапы, оставьте только необходимое и фиксируйте результат каждого шага.\n\nЭто особенно полезно там, где много инструментов, советов и вариантов действий.`,platform==="youtube"?"Short / кейс":"Разбор",`Минималистичная схема «сложно → просто → измеримый результат».`),
    make(3,`Вопрос аудитории о ${theme}`,`Хочу лучше понимать, что сейчас действительно важно аудитории.\n\nКакая задача в теме «${theme}» вызывает у вас больше всего вопросов или отнимает больше всего времени?\n\nНапишите один конкретный вопрос. Следующие материалы можно построить вокруг самых частых ответов.`,"Вовлекающий пост",`Один крупный вопрос на тёмном фоне, без лишних деталей.`),
    make(4,`План развития темы «${theme}»`,`Если собрать всё в простой план на ближайшую неделю, я бы сделал так:\n\n1. Выбрать одну ключевую тему.\n2. Дать аудитории понятный практический материал.\n3. Показать пример или разбор.\n4. Собрать вопросы и возражения.\n5. На их основе подготовить следующий цикл контента.\n\nТак контент превращается не в случайные публикации, а в последовательную систему.`,platform==="youtube"?"Видео-план":"Итоговый пост",`Схема из пяти последовательных шагов с акцентом на системность.`),
  ];
  return {dataQuality:sampleCount>=5?"medium":"low",detectedNiche:niche,summary:`Базовый анализ ${input.accountLabel} выполнен по доступным метрикам${sampleCount?` и ${sampleCount} примерам контента`:""}. Для более точного тематического разбора подключите OpenAI API — тогда KONTENTOR сможет глубже сравнивать темы и автоматически писать материалы под стиль канала.`,audienceProfile:"Точная демография аудитории этой площадкой в текущем наборе данных не передана. Рекомендации строятся по тематике, доступной статистике и контент-сигналам.",strengths:["Соцсеть подключена и метрики можно обновлять автоматически.",sampleCount?`Для анализа доступно примеров контента: ${sampleCount}.`:"KONTENTOR начнёт накапливать историю контента с этого момента.","Контент-план можно сразу переводить в календарь и согласование."],risks:[sampleCount<5?"Мало исторических материалов для уверенного сравнения тем.":"Истории всё ещё недостаточно для причинных выводов о росте.",...input.notes.slice(0,2),"Без AI API тематический анализ работает в базовом, шаблонном режиме."].slice(0,5),growthDirections:[`Развивать практические материалы вокруг темы «${theme}».`,`Собирать вопросы аудитории и превращать их в регулярную рубрику.`,`Чередовать полезные разборы, кейсы и вовлекающие публикации.`,`Через 2–3 недели повторить анализ и сравнить метрики.`],contentPillars:[{title:`Практика: ${theme}`,why:"Даёт аудитории конкретную пользу и формирует экспертность.",examples:[`Чек-лист по ${theme}`,`3 ошибки в ${theme}`,`Пошаговый разбор` ]},{title:"Кейсы и разборы",why:"Показывают подход на понятных ситуациях без абстрактных обещаний.",examples:["До/после","Разбор решения","Что сработало и почему"]},{title:"Вопросы аудитории",why:"Даёт темы для следующего контента и повышает обратную связь.",examples:["Вопрос недели","Разбор частого вопроса","Миф или факт"]}],recommendedFormats:formats[input.network],nextDays:items};
}

export async function runChannelAnalysis(network: ChannelAnalysisNetwork, workspaceId?: string): Promise<ChannelAnalysis> {
  const ws = await resolveWorkspaceId(workspaceId);
  const [workspace, settings, publications, radar] = await Promise.all([
    db.workspace.findUnique({ where: { id: ws }, select: { niche: true, brandVoice: true } }),
    getAutomationSettings(ws),
    listPublications(ws),
    listRadarItems(ws),
  ]);
  if (!workspace) throw new Error("Рабочее пространство не найдено.");

  let accountRef = "";
  let accountLabel = "";
  let metrics: Record<string, unknown> = {};
  let samples: Array<{ title?: string; text: string; metrics?: Record<string, number | undefined> }> = [];
  const dataNotes: string[] = [];

  if (network === "telegram") {
    const connection = await getTelegramConnection(ws);
    if (!connection) throw new Error("Сначала подключите Telegram-канал.");
    accountRef = connection.channelId;
    accountLabel = connection.channelUsername ? `@${connection.channelUsername}` : connection.channelTitle;
    const members = await getTelegramMemberCount(connection.token, connection.channelId);
    await addAudienceSnapshot(connection.channelId, members, ws);
    const details = await getTelegramChatDetails(connection.token, connection.channelId).catch(() => null);
    if (isMtprotoConfigured()) {
      const ref = connection.channelUsername ? `@${connection.channelUsername}` : connection.channelId;
      await fetchTelegramBroadcastStats(ref, ws).catch((e) => dataNotes.push(`Расширенная Telegram-статистика недоступна: ${e instanceof Error ? e.message : "ошибка"}`));
    } else {
      dataNotes.push("MTProto не настроен: анализ использует Bot API, данные KONTENTOR и описание канала, без полной истории Telegram-постов.");
    }
    const [audience, mt] = await Promise.all([listAudienceSnapshots(connection.channelId, ws), listMtprotoSnapshots(connection.channelUsername ? `@${connection.channelUsername}` : connection.channelId, ws)]);
    const latestMt = mt.at(-1);
    metrics = { members, description: details?.description, viewsPerPost: latestMt?.viewsPerPost?.current, sharesPerPost: latestMt?.sharesPerPost?.current, reactionsPerPost: latestMt?.reactionsPerPost?.current, audienceSnapshots: audience.slice(-14) };
    samples = publications.filter((p) => (p.platforms || ["telegram"]).includes("telegram") && ["published", "partial"].includes(p.status)).slice(0, 12).map((p) => ({ text: p.variants?.telegram || p.text }));
  } else if (network === "instagram") {
    const connection = await getInstagramConnection(ws);
    if (!connection) throw new Error("Сначала подключите Instagram.");
    accountRef = connection.userId; accountLabel = `@${connection.username}`;
    const fresh = await captureInstagramInsights(14, ws);
    const history = await listInstagramInsights(connection.userId, ws);
    metrics = { followers: fresh.followers, mediaCount: fresh.mediaCount, period: fresh.period, ...fresh.metrics, history: history.slice(-8).map((x) => ({ capturedAt: x.capturedAt, followers: x.followers, metrics: x.metrics })) };
    samples = fresh.recentMedia.map((m) => ({ title: m.productType || m.mediaType, text: m.caption || "Публикация без подписи", metrics: { views: m.views, reach: m.reach, likes: m.likes, comments: m.comments, saved: m.saved, shares: m.shares, interactions: m.totalInteractions } }));
  } else if (network === "vk") {
    const connection = await getValidVkConnection(ws);
    if (!connection) throw new Error("Сначала подключите VK.");
    accountRef = connection.groupId; accountLabel = connection.groupName;
    const fresh = await fetchVkAnalytics(connection, 50); await saveVkAnalytics(connection.groupId, fresh, ws);
    const history = await listVkAnalytics(connection.groupId, 20, ws);
    metrics = { members: fresh.members, postsAnalyzed: fresh.postsAnalyzed, totals: fresh.totals, averages: fresh.averages, history: history.slice(-10).map((x) => ({ capturedAt: x.capturedAt, members: x.members, averages: x.averages })) };
    samples = fresh.topPosts.map((p) => ({ title: `VK post ${p.id}`, text: p.text || "Пост без текста", metrics: { views: p.views, likes: p.likes, comments: p.comments, reposts: p.reposts } }));
  } else {
    const connection = await getValidYouTubeConnection(ws);
    if (!connection) throw new Error("Сначала подключите YouTube.");
    accountRef = connection.channelId; accountLabel = connection.channelTitle;
    const fresh = await fetchYouTubeAnalytics(connection, 28); await saveYouTubeInsights(connection.channelId, fresh, ws);
    const [history, videos] = await Promise.all([listYouTubeInsights(connection.channelId, 20, ws), fetchYouTubeRecentVideos(connection, 10).catch(() => [])]);
    metrics = { subscribers: fresh.subscribers, videoCount: fresh.videoCount, channelViewCount: fresh.channelViewCount, period: fresh.period, ...fresh.metrics, history: history.slice(-10) };
    samples = videos.map((v) => ({ title: v.title, text: v.description || v.title, metrics: v.metrics }));
    if (!videos.length) dataNotes.push("YouTube не вернул список последних видео; стратегия опирается на Analytics и тематику рабочего пространства.");
  }

  const previous = await getChannelAnalysis(network, ws);
  if (previous?.nextDays?.length) {
    const currentById = new Map(publications.map((p) => [p.id, p]));
    for (const item of previous.nextDays) {
      if (item.publicationId && currentById.get(item.publicationId)?.status === "review") {
        await cancelPublication(item.publicationId, ws);
      }
    }
  }

  const recentPublications = publications
    .filter((p) => (p.platforms || ["telegram"]).includes(network))
    .slice(0, 20)
    .map((p) => ({ date: p.publishedAt || p.scheduledFor || p.createdAt, text: p.variants?.[network] || p.text, status: p.status }));
  const radarItems = radar.filter((r) => r.status === "new").sort((a, b) => b.score - a.score).slice(0, 10).map((r) => ({ title: r.title, score: Math.round(r.score * 100), snippet: r.snippet, url: r.url }));
  const dates = nextDates(settings.timezone, 5);

  const ai = process.env.OPENAI_API_KEY
    ? await createChannelIntelligenceWithAI({
        network, accountLabel, workspaceNiche: workspace.niche || undefined, brandVoice: workspace.brandVoice,
        timezone: settings.timezone, allowedDates: dates, preferredTimes: settings.preferredTimes,
        metrics, contentSamples: samples, recentPublications, radarItems, dataNotes,
      })
    : fallbackIntelligence({ network, accountLabel, niche: workspace.niche || undefined, dates, times: settings.preferredTimes, metrics, samples, notes: [...dataNotes, "OPENAI_API_KEY не подключён: используется базовый автономный режим анализа."] });
  if (!process.env.OPENAI_API_KEY) dataNotes.push("OPENAI_API_KEY не подключён: используется базовый автономный режим. После подключения ключа нажмите «Обновить анализ» для глубокого ИИ-разбора.");

  const nextDays = [] as ChannelAnalysis["nextDays"];
  for (const item of ai.nextDays) {
    const safeDate = dates.includes(item.date) ? item.date : dates[nextDays.length] || dates.at(-1)!;
    const safeTime = settings.preferredTimes.includes(item.time) ? item.time : settings.preferredTimes[nextDays.length % settings.preferredTimes.length] || "19:00";
    const scheduled = zonedLocalToUtc(safeDate, safeTime, settings.timezone);
    const base: any = {
      text: item.material,
      variants: { [network]: item.material },
      platforms: platformsFor(network),
      status: "review",
      scheduledFor: scheduled.toISOString(),
      source: "ai",
    };
    if (network === "telegram") {
      const c = await getTelegramConnection(ws); if (c) Object.assign(base, { channelId: c.channelId, channelTitle: c.channelTitle, channelUsername: c.channelUsername });
    } else if (network === "instagram") {
      const c = await getInstagramConnection(ws); if (c) Object.assign(base, { instagramUserId: c.userId, instagramUsername: c.username });
    } else if (network === "vk") {
      const c = await getValidVkConnection(ws); if (c) Object.assign(base, { vkGroupId: c.groupId, vkGroupName: c.groupName });
    } else {
      const c = await getValidYouTubeConnection(ws); if (c) Object.assign(base, { youtubeChannelId: c.channelId, youtubeChannelTitle: c.channelTitle, youtubeTitle: item.topic.slice(0, 100), youtubePrivacyStatus: "private" });
    }
    const pub = await createPublication(base, ws);
    nextDays.push({ ...item, date: safeDate, time: safeTime, publicationId: pub.id });
  }

  const metricsSummary = [
    metric("Подписчики / участники", (metrics as any).members ?? (metrics as any).followers ?? (metrics as any).subscribers),
    metric("Охват", (metrics as any).reach), metric("Просмотры", (metrics as any).views ?? (metrics as any).channelViewCount),
    metric("Просмотры / пост", (metrics as any).viewsPerPost ?? (metrics as any).averages?.viewsPerPost),
    metric("Взаимодействия", (metrics as any).total_interactions), metric("Публикаций в выборке", (metrics as any).postsAnalyzed ?? samples.length),
  ].filter(Boolean) as Array<{ label: string; value: string }>;

  const analysis: ChannelAnalysis = {
    id: randomUUID(), network, accountRef, accountLabel, generatedAt: new Date().toISOString(),
    dataQuality: ai.dataQuality, detectedNiche: ai.detectedNiche, summary: ai.summary, audienceProfile: ai.audienceProfile,
    strengths: ai.strengths, risks: ai.risks, growthDirections: ai.growthDirections, contentPillars: ai.contentPillars,
    recommendedFormats: ai.recommendedFormats, metricsSummary, dataNotes, nextDays,
  };
  return saveChannelAnalysis(analysis, ws);
}
