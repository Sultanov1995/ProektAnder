import { randomUUID } from "crypto";
import { db } from "@/lib/db";
import { addAudienceSnapshot, listAudienceSnapshots } from "@/lib/analytics-store";
import { getAutomationSettings } from "@/lib/automation-store";
import { getInstagramConnection } from "@/lib/instagram-vault";
import { captureInstagramInsights, listInstagramInsights } from "@/lib/instagram-insights";
import { isMtprotoConfigured, fetchTelegramBroadcastStats } from "@/lib/mtproto";
import { listMtprotoSnapshots } from "@/lib/mtproto-store";
import { createChannelIntelligenceWithAI } from "@/lib/openai";
import { cancelPublication, createPublication, listPublications, type SocialPlatform } from "@/lib/publication-store";
import { listRadarItems } from "@/lib/radar-store";
import { getTelegramConnection } from "@/lib/telegram-vault";
import { getTelegramChatDetails, getTelegramMemberCount } from "@/lib/telegram";
import { dateKeyInZone, zonedLocalToUtc } from "@/lib/timezone";
import { getValidVkConnection } from "@/lib/vk-vault";
import { fetchVkAnalytics, listVkAnalytics, saveVkAnalytics } from "@/lib/vk-analytics";
import { getValidYouTubeConnection } from "@/lib/youtube-vault";
import { fetchYouTubeAnalytics, fetchYouTubeRecentVideos } from "@/lib/youtube";
import { listYouTubeInsights, saveYouTubeInsights } from "@/lib/youtube-insights";
import { resolveWorkspaceId } from "@/lib/workspace-context";
import { getChannelAnalysis, saveChannelAnalysis, type ChannelAnalysis, type ChannelAnalysisNetwork } from "@/lib/channel-analysis-store";

function nextDates(timezone: string, count = 5) {
  const baseKey = dateKeyInZone(new Date(), timezone);
  const base = new Date(`${baseKey}T12:00:00Z`);
  return Array.from({ length: count }, (_, index) => {
    const d = new Date(base);
    d.setUTCDate(d.getUTCDate() + index + 1);
    return d.toISOString().slice(0, 10);
  });
}

function metric(label: string, value: unknown) {
  if (value === undefined || value === null || value === "") return null;
  const shown = typeof value === "number" ? value.toLocaleString("ru-RU", { maximumFractionDigits: 1 }) : String(value);
  return { label, value: shown };
}

function platformsFor(network: ChannelAnalysisNetwork): SocialPlatform[] { return [network]; }

export async function runChannelAnalysis(network: ChannelAnalysisNetwork, workspaceId?: string): Promise<ChannelAnalysis> {
  const ws = await resolveWorkspaceId(workspaceId);
  const [workspace, settings, publications, radar] = await Promise.all([
    db.workspace.findUnique({ where: { id: ws }, select: { niche: true, brandVoice: true } }),
    getAutomationSettings(ws),
    listPublications(ws),
    listRadarItems(ws),
  ]);
  if (!workspace) throw new Error("Рабочее пространство не найдено.");

  let accountRef = "";
  let accountLabel = "";
  let metrics: Record<string, unknown> = {};
  let samples: Array<{ title?: string; text: string; metrics?: Record<string, number | undefined> }> = [];
  const dataNotes: string[] = [];

  if (network === "telegram") {
    const connection = await getTelegramConnection(ws);
    if (!connection) throw new Error("Сначала подключите Telegram-канал.");
    accountRef = connection.channelId;
    accountLabel = connection.channelUsername ? `@${connection.channelUsername}` : connection.channelTitle;
    const members = await getTelegramMemberCount(connection.token, connection.channelId);
    await addAudienceSnapshot(connection.channelId, members, ws);
    const details = await getTelegramChatDetails(connection.token, connection.channelId).catch(() => null);
    if (isMtprotoConfigured()) {
      const ref = connection.channelUsername ? `@${connection.channelUsername}` : connection.channelId;
      await fetchTelegramBroadcastStats(ref, ws).catch((e) => dataNotes.push(`Расширенная Telegram-статистика недоступна: ${e instanceof Error ? e.message : "ошибка"}`));
    } else {
      dataNotes.push("MTProto не настроен: анализ использует Bot API, данные KONTENTOR и описание канала, без полной истории Telegram-постов.");
    }
    const [audience, mt] = await Promise.all([listAudienceSnapshots(connection.channelId, ws), listMtprotoSnapshots(connection.channelUsername ? `@${connection.channelUsername}` : connection.channelId, ws)]);
    const latestMt = mt.at(-1);
    metrics = { members, description: details?.description, viewsPerPost: latestMt?.viewsPerPost?.current, sharesPerPost: latestMt?.sharesPerPost?.current, reactionsPerPost: latestMt?.reactionsPerPost?.current, audienceSnapshots: audience.slice(-14) };
    samples = publications.filter((p) => (p.platforms || ["telegram"]).includes("telegram") && ["published", "partial"].includes(p.status)).slice(0, 12).map((p) => ({ text: p.variants?.telegram || p.text }));
  } else if (network === "instagram") {
    const connection = await getInstagramConnection(ws);
    if (!connection) throw new Error("Сначала подключите Instagram.");
    accountRef = connection.userId; accountLabel = `@${connection.username}`;
    const fresh = await captureInstagramInsights(14, ws);
    const history = await listInstagramInsights(connection.userId, ws);
    metrics = { followers: fresh.followers, mediaCount: fresh.mediaCount, period: fresh.period, ...fresh.metrics, history: history.slice(-8).map((x) => ({ capturedAt: x.capturedAt, followers: x.followers, metrics: x.metrics })) };
    samples = fresh.recentMedia.map((m) => ({ title: m.productType || m.mediaType, text: m.caption || "Публикация без подписи", metrics: { views: m.views, reach: m.reach, likes: m.likes, comments: m.comments, saved: m.saved, shares: m.shares, interactions: m.totalInteractions } }));
  } else if (network === "vk") {
    const connection = await getValidVkConnection(ws);
    if (!connection) throw new Error("Сначала подключите VK.");
    accountRef = connection.groupId; accountLabel = connection.groupName;
    const fresh = await fetchVkAnalytics(connection, 50); await saveVkAnalytics(connection.groupId, fresh, ws);
    const history = await listVkAnalytics(connection.groupId, 20, ws);
    metrics = { members: fresh.members, postsAnalyzed: fresh.postsAnalyzed, totals: fresh.totals, averages: fresh.averages, history: history.slice(-10).map((x) => ({ capturedAt: x.capturedAt, members: x.members, averages: x.averages })) };
    samples = fresh.topPosts.map((p) => ({ title: `VK post ${p.id}`, text: p.text || "Пост без текста", metrics: { views: p.views, likes: p.likes, comments: p.comments, reposts: p.reposts } }));
  } else {
    const connection = await getValidYouTubeConnection(ws);
    if (!connection) throw new Error("Сначала подключите YouTube.");
    accountRef = connection.channelId; accountLabel = connection.channelTitle;
    const fresh = await fetchYouTubeAnalytics(connection, 28); await saveYouTubeInsights(connection.channelId, fresh, ws);
    const [history, videos] = await Promise.all([listYouTubeInsights(connection.channelId, 20, ws), fetchYouTubeRecentVideos(connection, 10).catch(() => [])]);
    metrics = { subscribers: fresh.subscribers, videoCount: fresh.videoCount, channelViewCount: fresh.channelViewCount, period: fresh.period, ...fresh.metrics, history: history.slice(-10) };
    samples = videos.map((v) => ({ title: v.title, text: v.description || v.title, metrics: v.metrics }));
    if (!videos.length) dataNotes.push("YouTube не вернул список последних видео; стратегия опирается на Analytics и тематику рабочего пространства.");
  }

  const previous = await getChannelAnalysis(network, ws);
  if (previous?.nextDays?.length) {
    const currentById = new Map(publications.map((p) => [p.id, p]));
    for (const item of previous.nextDays) {
      if (item.publicationId && currentById.get(item.publicationId)?.status === "review") {
        await cancelPublication(item.publicationId, ws);
      }
    }
  }

  const recentPublications = publications
    .filter((p) => (p.platforms || ["telegram"]).includes(network))
    .slice(0, 20)
    .map((p) => ({ date: p.publishedAt || p.scheduledFor || p.createdAt, text: p.variants?.[network] || p.text, status: p.status }));
  const radarItems = radar.filter((r) => r.status === "new").sort((a, b) => b.score - a.score).slice(0, 10).map((r) => ({ title: r.title, score: Math.round(r.score * 100), snippet: r.snippet, url: r.url }));
  const dates = nextDates(settings.timezone, 5);

  const ai = await createChannelIntelligenceWithAI({
    network, accountLabel, workspaceNiche: workspace.niche || undefined, brandVoice: workspace.brandVoice,
    timezone: settings.timezone, allowedDates: dates, preferredTimes: settings.preferredTimes,
    metrics, contentSamples: samples, recentPublications, radarItems, dataNotes,
  });

  const nextDays = [] as ChannelAnalysis["nextDays"];
  for (const item of ai.nextDays) {
    const safeDate = dates.includes(item.date) ? item.date : dates[nextDays.length] || dates.at(-1)!;
    const safeTime = settings.preferredTimes.includes(item.time) ? item.time : settings.preferredTimes[nextDays.length % settings.preferredTimes.length] || "19:00";
    const scheduled = zonedLocalToUtc(safeDate, safeTime, settings.timezone);
    const base: any = {
      text: item.material,
      variants: { [network]: item.material },
      platforms: platformsFor(network),
      status: "review",
      scheduledFor: scheduled.toISOString(),
      source: "ai",
    };
    if (network === "telegram") {
      const c = await getTelegramConnection(ws); if (c) Object.assign(base, { channelId: c.channelId, channelTitle: c.channelTitle, channelUsername: c.channelUsername });
    } else if (network === "instagram") {
      const c = await getInstagramConnection(ws); if (c) Object.assign(base, { instagramUserId: c.userId, instagramUsername: c.username });
    } else if (network === "vk") {
      const c = await getValidVkConnection(ws); if (c) Object.assign(base, { vkGroupId: c.groupId, vkGroupName: c.groupName });
    } else {
      const c = await getValidYouTubeConnection(ws); if (c) Object.assign(base, { youtubeChannelId: c.channelId, youtubeChannelTitle: c.channelTitle, youtubeTitle: item.topic.slice(0, 100), youtubePrivacyStatus: "private" });
    }
    const pub = await createPublication(base, ws);
    nextDays.push({ ...item, date: safeDate, time: safeTime, publicationId: pub.id });
  }

  const metricsSummary = [
    metric("Подписчики / участники", (metrics as any).members ?? (metrics as any).followers ?? (metrics as any).subscribers),
    metric("Охват", (metrics as any).reach), metric("Просмотры", (metrics as any).views ?? (metrics as any).channelViewCount),
    metric("Просмотры / пост", (metrics as any).viewsPerPost ?? (metrics as any).averages?.viewsPerPost),
    metric("Взаимодействия", (metrics as any).total_interactions), metric("Публикаций в выборке", (metrics as any).postsAnalyzed ?? samples.length),
  ].filter(Boolean) as Array<{ label: string; value: string }>;

  const analysis: ChannelAnalysis = {
    id: randomUUID(), network, accountRef, accountLabel, generatedAt: new Date().toISOString(),
    dataQuality: ai.dataQuality, detectedNiche: ai.detectedNiche, summary: ai.summary, audienceProfile: ai.audienceProfile,
    strengths: ai.strengths, risks: ai.risks, growthDirections: ai.growthDirections, contentPillars: ai.contentPillars,
    recommendedFormats: ai.recommendedFormats, metricsSummary, dataNotes, nextDays,
  };
  return saveChannelAnalysis(analysis, ws);
}
