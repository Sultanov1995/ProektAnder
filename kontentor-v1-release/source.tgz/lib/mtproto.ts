import { addMtprotoSnapshot, type MtprotoSnapshot } from "@/lib/mtproto-store";

function numberValue(value: unknown): number {
  if (typeof value === "number") return Number.isFinite(value) ? value : 0;
  if (typeof value === "bigint") return Number(value);
  if (value && typeof value === "object") {
    const candidate = value as { toJSNumber?: () => number; toString?: () => string };
    if (typeof candidate.toJSNumber === "function") return candidate.toJSNumber();
    if (typeof candidate.toString === "function") {
      const parsed = Number(candidate.toString());
      return Number.isFinite(parsed) ? parsed : 0;
    }
  }
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : 0;
}

function pair(value: unknown) {
  if (!value || typeof value !== "object") return undefined;
  const item = value as Record<string, unknown>;
  return {
    current: numberValue(item.current),
    previous: numberValue(item.previous),
  };
}

function percent(value: unknown) {
  if (!value || typeof value !== "object") return undefined;
  const item = value as Record<string, unknown>;
  const part = numberValue(item.part);
  const total = numberValue(item.total);
  return { part, total, percent: total > 0 ? (part / total) * 100 : undefined };
}

function graphData(value: unknown): unknown {
  if (!value || typeof value !== "object") return undefined;
  const graph = value as Record<string, unknown>;
  const json = graph.json;
  if (!json || typeof json !== "object") return undefined;
  const data = (json as Record<string, unknown>).data;
  if (typeof data !== "string") return undefined;
  try {
    const parsed = JSON.parse(data);
    return parsed;
  } catch {
    return undefined;
  }
}

function mtprotoConfig() {
  const apiId = Number(process.env.TELEGRAM_API_ID || 0);
  const apiHash = process.env.TELEGRAM_API_HASH || "";
  const session = process.env.TELEGRAM_MT_SESSION || "";
  if (!apiId || !apiHash || !session) {
    throw new Error("MTProto не настроен. Укажите TELEGRAM_API_ID, TELEGRAM_API_HASH и TELEGRAM_MT_SESSION.");
  }
  return { apiId, apiHash, session };
}

export function isMtprotoConfigured() {
  try {
    mtprotoConfig();
    return true;
  } catch {
    return false;
  }
}

export async function fetchTelegramBroadcastStats(channelRef: string, workspaceId?: string): Promise<MtprotoSnapshot> {
  const { apiId, apiHash, session } = mtprotoConfig();
  const [{ TelegramClient, Api }, { StringSession }] = await Promise.all([
    import("teleproto"),
    import("teleproto/sessions"),
  ]);

  const client = new TelegramClient(new StringSession(session), apiId, apiHash, {
    connectionRetries: 5,
  });

  try {
    await client.connect();
    const target = /^-?\d+$/.test(channelRef) ? Number(channelRef) : channelRef;
    const peer = await client.getInputEntity(target);
    if (!(peer instanceof Api.InputPeerChannel)) {
      throw new Error("MTProto-сессия не смогла определить подключённый объект как Telegram-канал.");
    }

    const channel = new Api.InputChannel({
      channelId: peer.channelId,
      accessHash: peer.accessHash,
    });

    const full = await client.invoke(new Api.channels.GetFullChannel({ channel }));
    const fullChat = (full as unknown as { fullChat?: Record<string, unknown> }).fullChat;
    if (!fullChat) throw new Error("Telegram не вернул расширенные данные канала.");
    if (fullChat.canViewStats === false) {
      throw new Error("Для этого канала Telegram не разрешает просмотр расширенной статистики текущему аккаунту.");
    }

    let stats: Record<string, unknown>;
    try {
      stats = await client.invoke(new Api.stats.GetBroadcastStats({ channel, dark: true })) as unknown as Record<string, unknown>;
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      if (/STATS_MIGRATE|stats_dc/i.test(message)) {
        throw new Error(`Telegram требует отдельный stats DC${fullChat.statsDc ? ` (${numberValue(fullChat.statsDc)})` : ""}. Обновите teleproto до актуальной версии или повторите запрос после переподключения.`);
      }
      throw error;
    }

    const periodRaw = stats.period as Record<string, unknown> | undefined;
    const recentRaw = Array.isArray(stats.recentPostsInteractions) ? stats.recentPostsInteractions : [];
    const snapshotInput: Omit<MtprotoSnapshot, "id" | "capturedAt"> = {
      channelRef,
      period: periodRaw ? {
        minDate: numberValue(periodRaw.minDate),
        maxDate: numberValue(periodRaw.maxDate),
      } : undefined,
      followers: pair(stats.followers),
      viewsPerPost: pair(stats.viewsPerPost),
      sharesPerPost: pair(stats.sharesPerPost),
      reactionsPerPost: pair(stats.reactionsPerPost),
      enabledNotifications: percent(stats.enabledNotifications),
      recentPosts: recentRaw.slice(0, 50).map((row) => {
        const item = row as Record<string, unknown>;
        return {
          messageId: numberValue(item.msgId),
          views: numberValue(item.views),
          forwards: numberValue(item.forwards),
          reactions: numberValue(item.reactions),
        };
      }),
      graphs: {
        growth: graphData(stats.growthGraph),
        followers: graphData(stats.followersGraph),
        topHours: graphData(stats.topHoursGraph),
        interactions: graphData(stats.interactionsGraph),
        viewsBySource: graphData(stats.viewsBySourceGraph),
        newFollowersBySource: graphData(stats.newFollowersBySourceGraph),
        languages: graphData(stats.languagesGraph),
        reactionsByEmotion: graphData(stats.reactionsByEmotionGraph),
      },
    };

    return await addMtprotoSnapshot(snapshotInput, workspaceId);
  } finally {
    await client.disconnect().catch(() => undefined);
  }
}
