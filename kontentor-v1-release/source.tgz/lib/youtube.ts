import type { StoredMedia } from "@/lib/publication-store";
import { readMediaFile } from "@/lib/media-store";
import type { YouTubeConnection } from "@/lib/youtube-vault";

async function googleJson(url: string, token: string) {
  const response = await fetch(url, { headers: { authorization: `Bearer ${token}` }, cache: "no-store" });
  const data = await response.json() as any;
  if (!response.ok) throw new Error(data?.error?.message || `Google API: ${response.status}`);
  return data;
}

export async function inspectYouTubeChannel(accessToken: string) {
  const data = await googleJson("https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics&mine=true", accessToken);
  const channel = data.items?.[0];
  if (!channel?.id) throw new Error("В Google-аккаунте не найден доступный YouTube-канал.");
  return {
    channelId: String(channel.id),
    channelTitle: String(channel.snippet?.title || "YouTube"),
    channelHandle: channel.snippet?.customUrl ? String(channel.snippet.customUrl) : undefined,
    subscribers: channel.statistics?.subscriberCount ? Number(channel.statistics.subscriberCount) : undefined,
  };
}

function safeTitle(text: string) {
  const first = text.split(/\n+/).map(x => x.trim()).find(Boolean) || "Публикация KONTENTOR";
  return first.replace(/^#+\s*/, "").slice(0, 100);
}

export async function publishYouTubeVideo(input: {
  text: string;
  title?: string;
  privacyStatus?: "private" | "unlisted" | "public";
  media: StoredMedia;
  connection: YouTubeConnection;
}) {
  if (input.media.kind !== "video" || input.media.mimeType !== "video/mp4") throw new Error("Для YouTube в v0.9 нужен MP4-видеофайл.");
  const buffer = await readMediaFile(input.media);
  const metadata = {
    snippet: { title: (input.title?.trim() || safeTitle(input.text)).slice(0, 100), description: input.text.slice(0, 5000) },
    status: { privacyStatus: input.privacyStatus || (process.env.YOUTUBE_DEFAULT_PRIVACY as any) || "private", selfDeclaredMadeForKids: false },
  };
  const init = await fetch("https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status", {
    method: "POST",
    headers: {
      authorization: `Bearer ${input.connection.accessToken}`,
      "content-type": "application/json; charset=UTF-8",
      "x-upload-content-length": String(buffer.length),
      "x-upload-content-type": input.media.mimeType,
    },
    body: JSON.stringify(metadata),
  });
  if (!init.ok) {
    const err = await init.text();
    throw new Error(`YouTube upload init ${init.status}: ${err.slice(0, 400)}`);
  }
  const uploadUrl = init.headers.get("location");
  if (!uploadUrl) throw new Error("YouTube не вернул resumable upload URL.");
  const upload = await fetch(uploadUrl, { method: "PUT", headers: { "content-type": input.media.mimeType, "content-length": String(buffer.length) }, body: new Uint8Array(buffer) });
  const data = await upload.json().catch(() => ({})) as any;
  if (!upload.ok || !data.id) throw new Error(data?.error?.message || `YouTube upload ${upload.status}`);
  return { videoId: String(data.id), publicLink: `https://youtu.be/${data.id}`, privacyStatus: String(data.status?.privacyStatus || metadata.status.privacyStatus) };
}

export async function fetchYouTubeAnalytics(connection: YouTubeConnection, days = 28) {
  const end = new Date();
  const start = new Date(end.getTime() - Math.max(1, days - 1) * 86400000);
  const date = (d: Date) => d.toISOString().slice(0, 10);
  const metrics = "views,estimatedMinutesWatched,averageViewDuration,likes,comments,shares,subscribersGained,subscribersLost";
  const params = new URLSearchParams({ ids: "channel==MINE", startDate: date(start), endDate: date(end), metrics });
  const [reports, channel] = await Promise.all([
    googleJson(`https://youtubeanalytics.googleapis.com/v2/reports?${params.toString()}`, connection.accessToken),
    googleJson("https://www.googleapis.com/youtube/v3/channels?part=statistics&mine=true", connection.accessToken),
  ]);
  const headers: string[] = reports.columnHeaders?.map((x: any) => x.name) || [];
  const row: any[] = reports.rows?.[0] || [];
  const mapped: Record<string, number> = {};
  headers.forEach((name, index) => { const n = Number(row[index]); if (Number.isFinite(n)) mapped[name] = n; });
  const stats = channel.items?.[0]?.statistics || {};
  return {
    capturedAt: new Date().toISOString(),
    period: { startDate: date(start), endDate: date(end), days },
    subscribers: stats.subscriberCount ? Number(stats.subscriberCount) : undefined,
    videoCount: stats.videoCount ? Number(stats.videoCount) : undefined,
    channelViewCount: stats.viewCount ? Number(stats.viewCount) : undefined,
    metrics: mapped,
  };
}
