import { getAutomationSettings } from "@/lib/automation-store";
import { createStrategyPostDraft } from "@/lib/openai";
import { createPublication, listPublications } from "@/lib/publication-store";
import { getRadarItem } from "@/lib/radar-store";
import { generateWeeklyStrategy } from "@/lib/strategy";
import { getWeeklyStrategy, updateStrategyPost } from "@/lib/strategy-store";
import { getTelegramConnection } from "@/lib/telegram-vault";
import { getValidVkConnection } from "@/lib/vk-vault";
import { getValidYouTubeConnection } from "@/lib/youtube-vault";
import { getInstagramConnection } from "@/lib/instagram-vault";
import { dateKeyInZone, weekStartInZone, zonedLocalToUtc } from "@/lib/timezone";

export type AutopilotRunResult = {
  mode: "review" | "autopilot";
  strategyGenerated: boolean;
  created: Array<{ postId: string; publicationId: string; status: "review" | "scheduled"; scheduledFor: string }>;
  skipped: Array<{ postId?: string; reason: string }>;
};

export async function runAutopilot(workspaceId?: string): Promise<AutopilotRunResult> {
  const settings = await getAutomationSettings(workspaceId);
  const connection = await getTelegramConnection(workspaceId);
  const vkConnection = await getValidVkConnection(workspaceId);
  const instagramConnection = await getInstagramConnection(workspaceId);
  const youtubeConnection = await getValidYouTubeConnection(workspaceId);
  if (!connection && !vkConnection && !instagramConnection && !youtubeConnection) throw new Error("Сначала подключите хотя бы одну соцсеть.");
  if (!process.env.OPENAI_API_KEY) throw new Error("Для AI-стратега и автопилота нужен OPENAI_API_KEY.");

  let strategy = await getWeeklyStrategy(workspaceId);
  let strategyGenerated = false;
  const currentWeek = weekStartInZone(new Date(), settings.timezone);
  if ((!strategy || strategy.weekStart !== currentWeek) && settings.autoGenerateWeeklyPlan) {
    strategy = await generateWeeklyStrategy(workspaceId);
    strategyGenerated = true;
  }
  if (!strategy) throw new Error("Недельный план ещё не создан. Сформируйте его в ИИ-ассистенте.");
  if (strategy.weekStart !== currentWeek) {
    throw new Error("Недельный план устарел, а автоматическое создание нового плана выключено в настройках.");
  }

  const result: AutopilotRunResult = { mode: settings.mode, strategyGenerated, created: [], skipped: [] };
  if (!settings.autoCreateDrafts) {
    result.skipped.push({ reason: "Автоматическое создание черновиков выключено в настройках." });
    return result;
  }

  const existing = await listPublications(workspaceId);
  const now = Date.now();
  let generatedThisRun = 0;

  for (const post of strategy.posts) {
    if (generatedThisRun >= 3) break;
    if (post.publicationId || post.status !== "planned") continue;
    const targetPlatforms = (post.platforms?.length ? post.platforms : ["telegram"]).filter((platform) =>
      platform === "telegram" ? Boolean(connection) : platform === "vk" ? Boolean(vkConnection) : platform === "instagram" ? Boolean(instagramConnection) : platform === "youtube" ? Boolean(youtubeConnection) : false
    );
    if (!targetPlatforms.length) {
      result.skipped.push({ postId: post.id, reason: "Для пункта плана нет подключённой площадки." });
      continue;
    }
    if (targetPlatforms.includes("instagram") || targetPlatforms.includes("youtube")) {
      const mediaNetworks = [targetPlatforms.includes("instagram") ? "Instagram" : "", targetPlatforms.includes("youtube") ? "YouTube" : ""].filter(Boolean).join(" + ");
      result.skipped.push({ postId: post.id, reason: `${mediaNetworks}: пункт оставлен на согласование, потому что требуется готовое медиа из KONTENTOR.` });
      continue;
    }
    let scheduled: Date;
    try {
      scheduled = zonedLocalToUtc(post.date, post.time, settings.timezone);
    } catch {
      result.skipped.push({ postId: post.id, reason: "Некорректные дата или время в контент-плане." });
      continue;
    }
    if (scheduled.getTime() < now + 5 * 60 * 1000) {
      await updateStrategyPost(post.id, { status: "skipped" }, workspaceId);
      result.skipped.push({ postId: post.id, reason: "Время публикации уже прошло или наступит менее чем через 5 минут." });
      continue;
    }

    const sameDayCount = existing.filter((item) => item.scheduledFor && dateKeyInZone(new Date(item.scheduledFor), settings.timezone) === post.date && ["review", "scheduled", "publishing", "published"].includes(item.status)).length;
    if (sameDayCount >= settings.dailyLimit) {
      result.skipped.push({ postId: post.id, reason: "Достигнут дневной лимит публикаций." });
      continue;
    }

    const radar = post.sourceRadarId ? await getRadarItem(post.sourceRadarId, workspaceId) : null;
    if (radar && Math.round(radar.score * 100) < settings.radarMinScore) {
      result.skipped.push({ postId: post.id, reason: `Radar Score ниже порога ${settings.radarMinScore}.` });
      continue;
    }

    const text = await createStrategyPostDraft({
      topic: post.topic,
      angle: post.angle,
      objective: post.objective,
      format: post.format,
      sourceTitle: radar?.title,
      sourceSnippet: radar?.snippet,
      sourceUrl: radar?.url || post.sourceUrl || undefined,
    });

    const status = settings.mode === "autopilot" ? "scheduled" : "review";
    const publication = await createPublication({
      text,
      source: "autopilot",
      status,
      scheduledFor: scheduled.toISOString(),
      channelId: connection?.channelId,
      channelTitle: connection?.channelTitle,
      channelUsername: connection?.channelUsername,
      vkGroupId: vkConnection?.groupId,
      vkGroupName: vkConnection?.groupName,
      platforms: targetPlatforms as Array<"telegram" | "vk">,
      variants: { telegram: text, vk: text },
    }, workspaceId);
    existing.push(publication);
    await updateStrategyPost(post.id, { publicationId: publication.id, status }, workspaceId);
    result.created.push({ postId: post.id, publicationId: publication.id, status, scheduledFor: scheduled.toISOString() });
    generatedThisRun += 1;
  }

  return result;
}
