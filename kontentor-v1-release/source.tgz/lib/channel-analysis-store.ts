import { db } from "@/lib/db";
import { resolveWorkspaceId } from "@/lib/workspace-context";
import type { SocialPlatform } from "@/lib/publication-store";

export type ChannelAnalysisNetwork = SocialPlatform;
export type AnalysisQuality = "low" | "medium" | "high";

export type ChannelContentItem = {
  date: string;
  time: string;
  topic: string;
  angle: string;
  objective: string;
  format: string;
  hook: string;
  material: string;
  visualBrief: string;
  cta: string;
  publicationId?: string;
};

export type ChannelAnalysis = {
  id: string;
  network: ChannelAnalysisNetwork;
  accountRef: string;
  accountLabel: string;
  generatedAt: string;
  dataQuality: AnalysisQuality;
  detectedNiche: string;
  summary: string;
  audienceProfile: string;
  strengths: string[];
  risks: string[];
  growthDirections: string[];
  contentPillars: Array<{ title: string; why: string; examples: string[] }>;
  recommendedFormats: Array<{ format: string; reason: string; frequency: string }>;
  metricsSummary: Array<{ label: string; value: string }>;
  dataNotes: string[];
  nextDays: ChannelContentItem[];
};

function key(network: ChannelAnalysisNetwork) {
  return `channel.analysis.${network}`;
}

export async function getChannelAnalysis(network: ChannelAnalysisNetwork, workspaceId?: string) {
  const ws = await resolveWorkspaceId(workspaceId);
  const row = await db.appSetting.findUnique({ where: { workspaceId_key: { workspaceId: ws, key: key(network) } } });
  return row?.value ? row.value as unknown as ChannelAnalysis : null;
}

export async function saveChannelAnalysis(analysis: ChannelAnalysis, workspaceId?: string) {
  const ws = await resolveWorkspaceId(workspaceId);
  const value = JSON.parse(JSON.stringify(analysis));
  await db.appSetting.upsert({
    where: { workspaceId_key: { workspaceId: ws, key: key(analysis.network) } },
    create: { workspaceId: ws, key: key(analysis.network), value },
    update: { value },
  });
  return analysis;
}
