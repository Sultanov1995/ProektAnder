import { cookies } from "next/headers";
import { db } from "@/lib/db";
import { SESSION_COOKIE, verifySessionToken } from "@/lib/session-token";

export async function getSessionPayload() {
  const store = await cookies();
  return verifySessionToken(store.get(SESSION_COOKIE)?.value);
}

export async function requireSession() {
  const session = await getSessionPayload();
  if (!session) throw new Error("UNAUTHORIZED");
  return session;
}

export async function getCurrentUser() {
  const session = await getSessionPayload();
  if (!session) return null;
  const membership = await db.workspaceMember.findUnique({
    where: { userId_workspaceId: { userId: session.userId, workspaceId: session.workspaceId } },
    include: { user: true, workspace: true },
  });
  if (!membership) return null;
  return { user: membership.user, workspace: membership.workspace, role: membership.role };
}
