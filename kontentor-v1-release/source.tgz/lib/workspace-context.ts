import { requireSession } from "@/lib/auth";

/**
 * Resolve the active workspace for an interactive user request.
 *
 * The optional explicit id is reserved for trusted server-side jobs (cron/autopilot)
 * that already authenticate with CRON_SECRET and iterate known workspace ids from DB.
 * User-facing routes should never pass a workspace id from request input here.
 */
export async function resolveWorkspaceId(explicit?: string) {
  if (explicit) return explicit;
  const session = await requireSession();
  return session.workspaceId;
}
