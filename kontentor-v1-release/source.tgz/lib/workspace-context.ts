import { cookies } from "next/headers";
import { db } from "@/lib/db";
import { SESSION_COOKIE, verifySessionToken } from "@/lib/session-token";

export async function resolveWorkspaceId(explicit?: string) {
  if (explicit) return explicit;
  try {
    const store = await cookies();
    const session = verifySessionToken(store.get(SESSION_COOKIE)?.value);
    if (session?.workspaceId) return session.workspaceId;
  } catch {}
  if (process.env.KONTENTOR_WORKSPACE_ID) return process.env.KONTENTOR_WORKSPACE_ID;
  const workspace = await db.workspace.findFirst({ orderBy: { createdAt: "asc" }, select: { id: true } });
  if (!workspace) throw new Error("WORKSPACE_NOT_CONFIGURED");
  return workspace.id;
}
