export type AiAction = "generate" | "improve" | "shorten" | "cta";

type OpenAIResponse = {
  output_text?: string;
  output?: Array<{ content?: Array<{ type?: string; text?: string }> }>;
  error?: { message?: string };
};

function promptFor(action: AiAction, text: string) {
  const rules = [
    "Пиши на русском языке.",
    "Верни только готовый текст публикации без пояснений и служебных комментариев.",
    "Не выдумывай факты, цифры, источники или цитаты, которых нет во входных данных.",
    "Сохраняй фактический смысл и ссылки, если они есть.",
    "Текст должен подходить для Telegram и быть не длиннее 4096 символов.",
    "Избегай дешёвого кликбейта, чрезмерных эмодзи и канцелярита.",
  ].join(" ");

  const tasks: Record<AiAction, string> = {
    generate: "На основе темы или черновых тезисов создай самостоятельный сильный Telegram-пост: цепляющее начало, ясная структура, практическая ценность и аккуратный финал.",
    improve: "Отредактируй текст: сделай его яснее, сильнее, естественнее и лучше структурированным. Удали повторы и слабые формулировки.",
    shorten: "Сократи текст примерно на 30–40%, сохранив главную мысль, факты и естественный стиль.",
    cta: "Сохрани основной текст и добавь в конце один уместный, ненавязчивый призыв к действию, соответствующий содержанию.",
  };

  return `${rules}\n\nЗадача: ${tasks[action]}\n\nВходной текст:\n${text}`;
}

function extractText(data: OpenAIResponse) {
  if (data.output_text?.trim()) return data.output_text.trim();
  const parts = data.output?.flatMap((item) => item.content || [])
    .filter((item) => item.type === "output_text" && typeof item.text === "string")
    .map((item) => item.text!.trim())
    .filter(Boolean) || [];
  return parts.join("\n").trim();
}

export async function runContentAI(action: AiAction, text: string) {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) throw new Error("OPENAI_API_KEY не настроен на сервере.");

  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      authorization: `Bearer ${apiKey}`,
      "content-type": "application/json",
    },
    body: JSON.stringify({
      model: process.env.OPENAI_MODEL || "gpt-5.6-luna",
      store: false,
      instructions: "Ты редактор KONTENTOR — ИИ-платформы для управления соцсетями. Создавай качественный, естественный и полезный контент без выдуманных фактов.",
      input: promptFor(action, text),
      max_output_tokens: 1800,
    }),
    cache: "no-store",
  });

  const data = (await response.json()) as OpenAIResponse;
  if (!response.ok) throw new Error(data.error?.message || `OpenAI API: ${response.status}`);
  const output = extractText(data);
  if (!output) throw new Error("ИИ не вернул текст. Попробуйте ещё раз.");
  return output.slice(0, 4096);
}

export async function createRadarDraft(input: { title: string; snippet?: string; sourceName: string; url: string; publishedAt?: string }) {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) throw new Error("OPENAI_API_KEY не настроен на сервере.");
  const sourceBlock = [
    `Заголовок источника: ${input.title}`,
    input.snippet ? `Фрагмент материала: ${input.snippet}` : "",
    `Источник: ${input.sourceName}`,
    input.publishedAt ? `Дата материала: ${input.publishedAt}` : "",
    `Ссылка: ${input.url}`,
  ].filter(Boolean).join("\n");

  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: { authorization: `Bearer ${apiKey}`, "content-type": "application/json" },
    body: JSON.stringify({
      model: process.env.OPENAI_MODEL || "gpt-5.6-luna",
      store: false,
      instructions: "Ты редактор KONTENTOR. Превращай найденные материалы в самостоятельные русскоязычные Telegram-посты. Не копируй исходник длинными фрагментами и не выдумывай факты.",
      input: `Создай оригинальный Telegram-пост на основе данных ниже.\n\nПравила:\n- Верни только готовый текст.\n- Не приписывай источнику факты, которых нет во входных данных.\n- Если данных мало, сформулируй аккуратно и не додумывай детали.\n- Сделай сильное, но не кликбейтное начало.\n- Объясни, почему тема полезна читателю.\n- Объём желательно 900–2200 знаков, максимум 3800.\n- В конце отдельной строкой обязательно укажи: «Источник: ${input.url}».\n- Не копируй исходный заголовок дословно, если можно сформулировать естественнее.\n\n${sourceBlock}`,
      max_output_tokens: 1800,
    }),
    cache: "no-store",
  });
  const data = (await response.json()) as OpenAIResponse;
  if (!response.ok) throw new Error(data.error?.message || `OpenAI API: ${response.status}`);
  const output = extractText(data);
  if (!output) throw new Error("ИИ не вернул текст. Попробуйте ещё раз.");
  return output.slice(0, 4096);
}

export type WeeklyStrategyAIInput = {
  weekStart: string;
  dates: string[];
  timezone: string;
  preferredTimes: string[];
  dailyLimit: number;
  allowWeekend: boolean;
  connectedPlatforms: Array<"telegram" | "instagram" | "vk" | "youtube">;
  channelTitle?: string;
  instagramUsername?: string;
  vkGroupName?: string;
  youtubeChannelTitle?: string;
  audience?: { currentMembers?: number; delta?: number };
  detailedStats?: { viewsPerPost?: number; sharesPerPost?: number; reactionsPerPost?: number; enabledNotificationsPercent?: number };
  instagramStats?: { followers?: number; reach?: number; views?: number; accountsEngaged?: number; totalInteractions?: number };
  vkStats?: { members?: number; viewsPerPost?: number; likesPerPost?: number; commentsPerPost?: number; repostsPerPost?: number };
  youtubeStats?: { subscribers?: number; views?: number; watchMinutes?: number; likes?: number; comments?: number; shares?: number; subscribersGained?: number; subscribersLost?: number };
  recentPublications: Array<{ date: string; text: string; status: string; platforms?: string[] }>;
  radarItems: Array<{ id: string; title: string; score: number; url: string; snippet?: string }>;
};

export type WeeklyStrategyAIResult = {
  summary: string;
  focus: string;
  actions: string[];
  posts: Array<{
    date: string;
    time: string;
    topic: string;
    angle: string;
    objective: string;
    format: string;
    platforms: Array<"telegram" | "instagram" | "vk" | "youtube">;
    sourceRadarId: string;
    sourceUrl: string;
  }>;
};

const weeklyStrategySchema = {
  type: "object",
  additionalProperties: false,
  properties: {
    summary: { type: "string" },
    focus: { type: "string" },
    actions: { type: "array", items: { type: "string" }, minItems: 3, maxItems: 6 },
    posts: {
      type: "array",
      minItems: 4,
      maxItems: 10,
      items: {
        type: "object",
        additionalProperties: false,
        properties: {
          date: { type: "string" },
          time: { type: "string" },
          topic: { type: "string" },
          angle: { type: "string" },
          objective: { type: "string" },
          format: { type: "string" },
          platforms: { type: "array", minItems: 1, maxItems: 4, items: { type: "string", enum: ["telegram", "instagram", "vk", "youtube"] } },
          sourceRadarId: { type: "string" },
          sourceUrl: { type: "string" },
        },
        required: ["date", "time", "topic", "angle", "objective", "format", "platforms", "sourceRadarId", "sourceUrl"],
      },
    },
  },
  required: ["summary", "focus", "actions", "posts"],
} as const;

export async function createWeeklyStrategyWithAI(input: WeeklyStrategyAIInput): Promise<WeeklyStrategyAIResult> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) throw new Error("OPENAI_API_KEY не настроен на сервере.");

  const radarText = input.radarItems.length
    ? input.radarItems.map((item) => `- ID=${item.id}; score=${item.score}/100; ${item.title}; ${item.url}; ${item.snippet || "без фрагмента"}`).join("\n")
    : "Radar пока не нашёл материалов.";
  const recentText = input.recentPublications.length
    ? input.recentPublications.map((item) => `- ${item.date}: [${item.status}] ${item.text.slice(0, 280)}`).join("\n")
    : "История публикаций пока пустая.";

  const body = {
    model: process.env.OPENAI_MODEL || "gpt-5.6-luna",
    store: false,
    instructions: "Ты мультиплатформенный AI-стратег KONTENTOR. Планируй контент для подключённых Telegram, Instagram, VK и YouTube на русском языке. Учитывай различия площадок, но не выдумывай факты или метрики. Опирайся только на переданные данные. Если Radar-источник используется, укажи его ID и URL без изменений. Делай план практичным, разнообразным и реалистичным.",
    input: `Составь недельный контент-план.\n\nНеделя начинается: ${input.weekStart}\nРазрешённые даты: ${input.dates.join(", ")}\nЧасовой пояс: ${input.timezone}\nПредпочтительные часы: ${input.preferredTimes.join(", ")}\nМаксимум публикаций в день: ${input.dailyLimit}\nВыходные разрешены: ${input.allowWeekend ? "да" : "нет"}\nПодключённые площадки: ${input.connectedPlatforms.join(", ") || "нет"}\nTelegram: ${input.channelTitle || "не подключён"}\nTelegram аудитория: ${input.audience?.currentMembers ?? "нет данных"}; изменение: ${input.audience?.delta ?? "нет данных"}\nTelegram просмотры / пост: ${input.detailedStats?.viewsPerPost ?? "нет данных"}\nTelegram пересылки / пост: ${input.detailedStats?.sharesPerPost ?? "нет данных"}\nTelegram реакции / пост: ${input.detailedStats?.reactionsPerPost ?? "нет данных"}\nInstagram: ${input.instagramUsername ? "@" + input.instagramUsername : "не подключён"}\nInstagram подписчики: ${input.instagramStats?.followers ?? "нет данных"}\nInstagram охват: ${input.instagramStats?.reach ?? "нет данных"}\nInstagram просмотры: ${input.instagramStats?.views ?? "нет данных"}\nInstagram вовлечённые аккаунты: ${input.instagramStats?.accountsEngaged ?? "нет данных"}\nInstagram взаимодействия: ${input.instagramStats?.totalInteractions ?? "нет данных"}\nVK: ${input.vkGroupName || "не подключён"}\nVK участники: ${input.vkStats?.members ?? "нет данных"}; просмотры / пост: ${input.vkStats?.viewsPerPost ?? "нет данных"}; лайки / пост: ${input.vkStats?.likesPerPost ?? "нет данных"}; комментарии / пост: ${input.vkStats?.commentsPerPost ?? "нет данных"}; репосты / пост: ${input.vkStats?.repostsPerPost ?? "нет данных"}\nYouTube: ${input.youtubeChannelTitle || "не подключён"}\nYouTube подписчики: ${input.youtubeStats?.subscribers ?? "нет данных"}; просмотры: ${input.youtubeStats?.views ?? "нет данных"}; минуты просмотра: ${input.youtubeStats?.watchMinutes ?? "нет данных"}; лайки: ${input.youtubeStats?.likes ?? "нет данных"}; комментарии: ${input.youtubeStats?.comments ?? "нет данных"}; shares: ${input.youtubeStats?.shares ?? "нет данных"}; +подписчики: ${input.youtubeStats?.subscribersGained ?? "нет данных"}; -подписчики: ${input.youtubeStats?.subscribersLost ?? "нет данных"}\n\nПоследние публикации:\n${recentText}\n\nСильные находки Radar:\n${radarText}\n\nПравила:\n- Используй только даты из списка.\n- Используй время из предпочтительных часов, если нет сильной причины выбрать другое.\n- Не превышай дневной лимит.\n- Если выходные запрещены, не ставь публикации на субботу и воскресенье.\n- Сделай минимум 4 публикации на неделю.\n- Сбалансируй полезный, экспертный, вовлекающий и новостной контент.\n- Для каждого пункта укажи platforms: только реально подключённые площадки.\n- Если тема полезна нескольким площадкам, укажи несколько значений в platforms.\n- Для VK выбирай публикации, которые хорошо работают в сообществе: полезные разборы, новости, кейсы и вовлекающие посты.\n- Instagram-публикации требуют визуального медиа; в format явно укажи, что лучше использовать: фото, карусель или Reel.\n- YouTube-пункты планируй как идеи для видео/Shorts; в format укажи тип видео. KONTENTOR не публикует YouTube автоматически без готового MP4.\n- Если используешь Radar-находку, sourceRadarId и sourceUrl должны быть заполнены; иначе оба поля должны быть пустыми строками.\n- В summary кратко объясни логику недели, focus — главный фокус роста, actions — конкретные действия помимо публикаций.`,
    text: {
      format: {
        type: "json_schema",
        name: "kontentor_weekly_strategy",
        strict: true,
        schema: weeklyStrategySchema,
      },
    },
    max_output_tokens: 3500,
  };

  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: { authorization: `Bearer ${apiKey}`, "content-type": "application/json" },
    body: JSON.stringify(body),
    cache: "no-store",
  });
  const data = (await response.json()) as OpenAIResponse;
  if (!response.ok) throw new Error(data.error?.message || `OpenAI API: ${response.status}`);
  const output = extractText(data);
  if (!output) throw new Error("ИИ-стратег не вернул план.");
  try {
    const parsed = JSON.parse(output) as WeeklyStrategyAIResult;
    if (!parsed.summary || !parsed.focus || !Array.isArray(parsed.posts) || !Array.isArray(parsed.actions)) {
      throw new Error("Неполная структура");
    }
    return parsed;
  } catch {
    throw new Error("ИИ вернул некорректную структуру недельного плана. Повторите генерацию.");
  }
}

export async function createStrategyPostDraft(input: {
  topic: string;
  angle: string;
  objective: string;
  format: string;
  sourceTitle?: string;
  sourceSnippet?: string;
  sourceUrl?: string;
}) {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) throw new Error("OPENAI_API_KEY не настроен на сервере.");
  const source = input.sourceUrl
    ? `\nИсточник для фактов:\n${input.sourceTitle || "Материал"}\n${input.sourceSnippet || ""}\n${input.sourceUrl}`
    : "\nВнешний источник не задан. Не придумывай конкретные новости, цифры, цитаты или события.";

  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: { authorization: `Bearer ${apiKey}`, "content-type": "application/json" },
    body: JSON.stringify({
      model: process.env.OPENAI_MODEL || "gpt-5.6-luna",
      store: false,
      instructions: "Ты редактор KONTENTOR. Пиши естественные, полезные Telegram-посты на русском языке. Не выдумывай факты. Верни только готовый текст публикации.",
      input: `Подготовь Telegram-пост для контент-плана.\nТема: ${input.topic}\nПодача: ${input.angle}\nЦель: ${input.objective}\nФормат: ${input.format}${source}\n\nТребования:\n- до 3800 символов;\n- сильное, но не кликбейтное начало;\n- понятная структура;\n- один уместный CTA в финале;\n- если есть URL источника, добавь в конце отдельной строкой «Источник: URL»;\n- если источника нет, не добавляй фиктивные ссылки.`,
      max_output_tokens: 1800,
    }),
    cache: "no-store",
  });
  const data = (await response.json()) as OpenAIResponse;
  if (!response.ok) throw new Error(data.error?.message || `OpenAI API: ${response.status}`);
  const output = extractText(data);
  if (!output) throw new Error("ИИ не вернул текст публикации.");
  return output.slice(0, 4096);
}

export type CrossPlatformVariants = { telegram: string; instagram: string; vk: string; youtube: string };

const crossPlatformSchema = {
  type: "object",
  additionalProperties: false,
  properties: {
    telegram: { type: "string" },
    instagram: { type: "string" },
    vk: { type: "string" },
    youtube: { type: "string" },
  },
  required: ["telegram", "instagram", "vk", "youtube"],
} as const;

export async function createCrossPlatformVariants(text: string): Promise<CrossPlatformVariants> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) throw new Error("OPENAI_API_KEY не настроен на сервере.");
  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: { authorization: `Bearer ${apiKey}`, "content-type": "application/json" },
    body: JSON.stringify({
      model: process.env.OPENAI_MODEL || "gpt-5.6-luna",
      store: false,
      instructions: "Ты редактор KONTENTOR. Адаптируй один исходный материал под Telegram, Instagram, VK и YouTube на русском языке. Не выдумывай факты и не меняй ссылки. Верни строго JSON по схеме.",
      input: `Исходный текст:\n${text}\n\nСделай четыре самостоятельные версии:\n- telegram: до 3800 символов, можно подробнее и структурнее;\n- instagram: до 2100 символов, сильный первый абзац, компактно, без бессмысленных хэштегов;\n- vk: до 5000 символов, естественная подача для сообщества VK, понятный заголовок/лид и один CTA.\n- youtube: до 5000 символов, описание видео YouTube с сильными первыми строками, кратким контекстом, CTA и сохранёнными ссылками.\nСохрани факты и ссылки из исходника.`,
      text: { format: { type: "json_schema", name: "kontentor_cross_platform", strict: true, schema: crossPlatformSchema } },
      max_output_tokens: 4200,
    }),
    cache: "no-store",
  });
  const data = (await response.json()) as OpenAIResponse;
  if (!response.ok) throw new Error(data.error?.message || `OpenAI API: ${response.status}`);
  const output = extractText(data);
  if (!output) throw new Error("ИИ не вернул версии публикации.");
  try {
    const parsed = JSON.parse(output) as CrossPlatformVariants;
    if (!parsed.telegram?.trim() || !parsed.instagram?.trim() || !parsed.vk?.trim() || !parsed.youtube?.trim()) throw new Error("Неполный ответ");
    return { telegram: parsed.telegram.slice(0, 4096), instagram: parsed.instagram.slice(0, 2200), vk: parsed.vk.slice(0, 5000), youtube: parsed.youtube.slice(0, 5000) };
  } catch {
    throw new Error("ИИ вернул некорректные версии публикации. Повторите адаптацию.");
  }
}

export type MediaStudioFormat = "square" | "portrait" | "story" | "landscape";
const mediaSizes: Record<MediaStudioFormat,string> = { square:"1024x1024", portrait:"1088x1360", story:"1088x1920", landscape:"1536x1024" };
export async function generateMediaImage(input:{prompt:string;format:MediaStudioFormat;quality?:"low"|"medium"|"high"}){
  const apiKey=process.env.OPENAI_API_KEY; if(!apiKey) throw new Error("OPENAI_API_KEY не настроен на сервере.");
  const response=await fetch("https://api.openai.com/v1/images/generations",{method:"POST",headers:{authorization:`Bearer ${apiKey}`,"content-type":"application/json"},body:JSON.stringify({model:process.env.OPENAI_IMAGE_MODEL||"gpt-image-2.5-flare",prompt:`Создай профессиональный визуал для публикации в соцсетях. Без логотипов сторонних брендов и без мелкого нечитаемого текста. Стиль KONTENTOR: современный, чистый, коммерческий. Задача пользователя: ${input.prompt}`,size:mediaSizes[input.format],quality:input.quality||"medium",output_format:"jpeg",output_compression:90,n:1}) ,cache:"no-store"});
  const data=await response.json() as {data?:Array<{b64_json?:string}>;error?:{message?:string}};
  if(!response.ok) throw new Error(data.error?.message||`OpenAI Images API: ${response.status}`);
  const b64=data.data?.[0]?.b64_json; if(!b64) throw new Error("ИИ не вернул изображение.");
  return {buffer:Buffer.from(b64,"base64"),mimeType:"image/jpeg",size:mediaSizes[input.format],model:process.env.OPENAI_IMAGE_MODEL||"gpt-image-2.5-flare"};
}


export async function editMediaImage(input:{buffer:Buffer;mimeType:string;prompt:string;format:MediaStudioFormat;quality?:"low"|"medium"|"high"}){
  const apiKey=process.env.OPENAI_API_KEY; if(!apiKey) throw new Error("OPENAI_API_KEY не настроен на сервере.");
  if(!["image/jpeg","image/png","image/webp"].includes(input.mimeType)) throw new Error("Редактирование поддерживает JPG, PNG и WEBP.");
  const form=new FormData();
  const bytes=new Uint8Array(input.buffer);
  form.set("model",process.env.OPENAI_IMAGE_EDIT_MODEL||"gpt-image-2.5-sunburst");
  form.set("prompt",`Отредактируй исходное изображение согласно инструкции. Сохрани полезные элементы исходника, не добавляй логотипы сторонних брендов и мелкий нечитаемый текст. Стиль результата: современный, чистый, коммерческий. Инструкция пользователя: ${input.prompt}`);
  form.set("image",new Blob([bytes],{type:input.mimeType}),input.mimeType==="image/png"?"source.png":input.mimeType==="image/webp"?"source.webp":"source.jpg");
  form.set("size",mediaSizes[input.format]);
  form.set("quality",input.quality||"medium");
  form.set("output_format","jpeg");
  form.set("output_compression","90");
  const response=await fetch("https://api.openai.com/v1/images/edits",{method:"POST",headers:{authorization:`Bearer ${apiKey}`},body:form,cache:"no-store"});
  const data=await response.json() as {data?:Array<{b64_json?:string}>;error?:{message?:string}};
  if(!response.ok) throw new Error(data.error?.message||`OpenAI Images Edit API: ${response.status}`);
  const b64=data.data?.[0]?.b64_json; if(!b64) throw new Error("ИИ не вернул отредактированное изображение.");
  return {buffer:Buffer.from(b64,"base64"),mimeType:"image/jpeg",size:mediaSizes[input.format],model:process.env.OPENAI_IMAGE_EDIT_MODEL||"gpt-image-2.5-sunburst"};
}

export type ChannelIntelligenceAIInput = {
  network: "telegram" | "instagram" | "vk" | "youtube";
  accountLabel: string;
  workspaceNiche?: string;
  brandVoice?: unknown;
  timezone: string;
  allowedDates: string[];
  preferredTimes: string[];
  metrics: Record<string, unknown>;
  contentSamples: Array<{ title?: string; text: string; metrics?: Record<string, number | undefined> }>;
  recentPublications: Array<{ date: string; text: string; status: string }>;
  radarItems: Array<{ title: string; score: number; snippet?: string; url: string }>;
  dataNotes: string[];
};

export type ChannelIntelligenceAIResult = {
  dataQuality: "low" | "medium" | "high";
  detectedNiche: string;
  summary: string;
  audienceProfile: string;
  strengths: string[];
  risks: string[];
  growthDirections: string[];
  contentPillars: Array<{ title: string; why: string; examples: string[] }>;
  recommendedFormats: Array<{ format: string; reason: string; frequency: string }>;
  nextDays: Array<{
    date: string;
    time: string;
    topic: string;
    angle: string;
    objective: string;
    format: string;
    hook: string;
    material: string;
    visualBrief: string;
    cta: string;
  }>;
};

const channelIntelligenceSchema = {
  type: "object",
  additionalProperties: false,
  properties: {
    dataQuality: { type: "string", enum: ["low", "medium", "high"] },
    detectedNiche: { type: "string" },
    summary: { type: "string" },
    audienceProfile: { type: "string" },
    strengths: { type: "array", minItems: 2, maxItems: 6, items: { type: "string" } },
    risks: { type: "array", minItems: 2, maxItems: 6, items: { type: "string" } },
    growthDirections: { type: "array", minItems: 3, maxItems: 6, items: { type: "string" } },
    contentPillars: {
      type: "array", minItems: 3, maxItems: 5,
      items: {
        type: "object", additionalProperties: false,
        properties: {
          title: { type: "string" }, why: { type: "string" },
          examples: { type: "array", minItems: 2, maxItems: 4, items: { type: "string" } },
        },
        required: ["title", "why", "examples"],
      },
    },
    recommendedFormats: {
      type: "array", minItems: 2, maxItems: 5,
      items: {
        type: "object", additionalProperties: false,
        properties: { format: { type: "string" }, reason: { type: "string" }, frequency: { type: "string" } },
        required: ["format", "reason", "frequency"],
      },
    },
    nextDays: {
      type: "array", minItems: 5, maxItems: 5,
      items: {
        type: "object", additionalProperties: false,
        properties: {
          date: { type: "string" }, time: { type: "string" }, topic: { type: "string" }, angle: { type: "string" },
          objective: { type: "string" }, format: { type: "string" }, hook: { type: "string" }, material: { type: "string" },
          visualBrief: { type: "string" }, cta: { type: "string" },
        },
        required: ["date", "time", "topic", "angle", "objective", "format", "hook", "material", "visualBrief", "cta"],
      },
    },
  },
  required: ["dataQuality", "detectedNiche", "summary", "audienceProfile", "strengths", "risks", "growthDirections", "contentPillars", "recommendedFormats", "nextDays"],
} as const;

export async function createChannelIntelligenceWithAI(input: ChannelIntelligenceAIInput): Promise<ChannelIntelligenceAIResult> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) throw new Error("Для глубокого анализа и автоконтента нужен OPENAI_API_KEY на сервере KONTENTOR.");

  const sampleText = input.contentSamples.length
    ? input.contentSamples.slice(0, 12).map((item, index) => `#${index + 1} ${item.title || "Материал"}\n${item.text.slice(0, 1000)}\nМетрики: ${JSON.stringify(item.metrics || {})}`).join("\n\n")
    : "Доступных исходных публикаций площадка не предоставила.";
  const recentText = input.recentPublications.length
    ? input.recentPublications.slice(0, 15).map((item) => `- ${item.date} [${item.status}]: ${item.text.slice(0, 600)}`).join("\n")
    : "История публикаций KONTENTOR пока пустая.";
  const radarText = input.radarItems.length
    ? input.radarItems.slice(0, 10).map((item) => `- ${item.score}/100 ${item.title}: ${item.snippet || ""} ${item.url}`).join("\n")
    : "Radar пока не дал релевантных тем.";

  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: { authorization: `Bearer ${apiKey}`, "content-type": "application/json" },
    body: JSON.stringify({
      model: process.env.OPENAI_MODEL || "gpt-5.6-luna",
      store: false,
      instructions: "Ты аналитик и контент-стратег KONTENTOR. Анализируй только переданные данные. Не выдумывай статистику, аудиторию, факты или прошлые результаты. Если данных мало — прямо снижай dataQuality и объясняй ограничения. Пиши по-русски. Для контент-плана создавай готовые к согласованию материалы, а не абстрактные советы.",
      input: `Проведи глубокий анализ подключённой площадки и подготовь готовый контент на 5 ближайших дней.\n\nПлощадка: ${input.network}\nАккаунт: ${input.accountLabel}\nТематика рабочего пространства: ${input.workspaceNiche || "не указана"}\nTone of voice: ${JSON.stringify(input.brandVoice || {})}\nЧасовой пояс: ${input.timezone}\nРазрешённые даты: ${input.allowedDates.join(", ")}\nПредпочтительное время: ${input.preferredTimes.join(", ")}\n\nСырые метрики:\n${JSON.stringify(input.metrics)}\n\nДоступные примеры контента:\n${sampleText}\n\nИстория материалов KONTENTOR:\n${recentText}\n\nRadar:\n${radarText}\n\nОграничения данных:\n${input.dataNotes.join("\n") || "нет"}\n\nЗадача:\n1. Определи реальную/вероятную тематику канала, но не выдавай предположение за факт.\n2. Объясни, что уже выглядит сильным и что тормозит рост.\n3. Дай 3–6 направлений, которые стоит развивать дальше.\n4. Сформируй 3–5 постоянных контент-рубрик с примерами тем.\n5. Предложи форматы и частоту именно для этой площадки.\n6. Создай ровно 5 материалов на ближайшие даты. Каждый material должен быть содержательным и пригодным для согласования прямо сейчас.\n7. Telegram/VK: material = готовый пост. Instagram: material = готовая подпись, visualBrief = идея фото/карусели/Reel. YouTube: material = готовый сценарный план/описание, visualBrief = идея видео/Short.\n8. Не используй конкретные цифры или новости, если их нет во входных данных.\n9. Используй только даты из списка и время из предпочтительных часов.`,
      text: { format: { type: "json_schema", name: "kontentor_channel_intelligence", strict: true, schema: channelIntelligenceSchema } },
      max_output_tokens: 9000,
    }),
    cache: "no-store",
  });
  const data = (await response.json()) as OpenAIResponse;
  if (!response.ok) throw new Error(data.error?.message || `OpenAI API: ${response.status}`);
  const output = extractText(data);
  if (!output) throw new Error("ИИ не вернул анализ канала.");
  try {
    const parsed = JSON.parse(output) as ChannelIntelligenceAIResult;
    if (!parsed.summary || !parsed.detectedNiche || parsed.nextDays?.length !== 5) throw new Error("Неполная структура");
    return parsed;
  } catch {
    throw new Error("ИИ вернул некорректную структуру анализа. Повторите запуск.");
  }
}
