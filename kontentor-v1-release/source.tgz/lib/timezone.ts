export function dateKeyInZone(date: Date, timeZone: string) {
  return new Intl.DateTimeFormat("en-CA", { timeZone, year: "numeric", month: "2-digit", day: "2-digit" }).format(date);
}

export function weekdayInZone(date: Date, timeZone: string) {
  const value = new Intl.DateTimeFormat("en-US", { timeZone, weekday: "short" }).format(date);
  return value;
}

export function weekStartInZone(date: Date, timeZone: string) {
  const localDate = dateKeyInZone(date, timeZone);
  const noonUtc = new Date(`${localDate}T12:00:00Z`);
  const names = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  const idx = names.indexOf(weekdayInZone(noonUtc, timeZone));
  const copy = new Date(noonUtc);
  copy.setUTCDate(copy.getUTCDate() - Math.max(0, idx));
  return dateKeyInZone(copy, timeZone);
}

function offsetMsAt(date: Date, timeZone: string) {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone,
    year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23",
  }).formatToParts(date);
  const values: Record<string, number> = {};
  for (const part of parts) if (part.type !== "literal") values[part.type] = Number(part.value);
  const asUtc = Date.UTC(values.year, values.month - 1, values.day, values.hour, values.minute, values.second);
  return asUtc - date.getTime();
}

export function zonedLocalToUtc(date: string, time: string, timeZone: string) {
  const [y, m, d] = date.split("-").map(Number);
  const [hh, mm] = time.split(":").map(Number);
  if (![y,m,d,hh,mm].every(Number.isFinite)) throw new Error("Некорректные дата или время контент-плана.");
  const naive = new Date(Date.UTC(y, m - 1, d, hh, mm, 0));
  let utc = new Date(naive.getTime() - offsetMsAt(naive, timeZone));
  const correctedOffset = offsetMsAt(utc, timeZone);
  utc = new Date(naive.getTime() - correctedOffset);
  return utc;
}

export function nextSevenDates(weekStart: string) {
  const start = new Date(`${weekStart}T12:00:00Z`);
  return Array.from({ length: 7 }, (_, index) => {
    const copy = new Date(start);
    copy.setUTCDate(copy.getUTCDate() + index);
    return copy.toISOString().slice(0, 10);
  });
}
