import type { PublishRequest, PublishResult, SocialConnector } from "@/types/social";

export type TelegramBot = {
  id: number;
  is_bot: boolean;
  first_name: string;
  username?: string;
};

export type TelegramChat = {
  id: number;
  type: "channel" | "group" | "supergroup" | "private";
  title?: string;
  username?: string;
};

type TelegramApiResponse<T> = {
  ok: boolean;
  result?: T;
  description?: string;
};

type TelegramSendResult = {
  messageId: number;
  mediaMessageId?: number;
};

async function telegramApi<T>(botToken: string, method: string, body?: Record<string, unknown>): Promise<T> {
  const res = await fetch(`https://api.telegram.org/bot${botToken}/${method}`, {
    method: body ? "POST" : "GET",
    headers: body ? { "content-type": "application/json" } : undefined,
    body: body ? JSON.stringify(body) : undefined,
    cache: "no-store",
  });
  const data = (await res.json()) as TelegramApiResponse<T>;
  if (!res.ok || !data.ok || data.result === undefined) {
    throw new Error(data.description || `Telegram API error: ${res.status}`);
  }
  return data.result;
}

async function telegramMultipart<T>(botToken: string, method: string, form: FormData): Promise<T> {
  const res = await fetch(`https://api.telegram.org/bot${botToken}/${method}`, {
    method: "POST",
    body: form,
    cache: "no-store",
  });
  const data = (await res.json()) as TelegramApiResponse<T>;
  if (!res.ok || !data.ok || data.result === undefined) {
    throw new Error(data.description || `Telegram API error: ${res.status}`);
  }
  return data.result;
}

export async function validateTelegramConnection(botToken: string, channelRef: string) {
  const bot = await telegramApi<TelegramBot>(botToken, "getMe");
  const chat = await telegramApi<TelegramChat>(botToken, "getChat", { chat_id: channelRef.trim() });

  if (chat.type !== "channel") {
    throw new Error("Укажите именно Telegram-канал. Для групп будет отдельный режим.");
  }

  const member = await telegramApi<{ status: string; can_post_messages?: boolean }>(botToken, "getChatMember", {
    chat_id: chat.id,
    user_id: bot.id,
  });

  if (member.status !== "administrator" && member.status !== "creator") {
    throw new Error("Добавьте бота администратором канала и дайте ему право публиковать сообщения.");
  }
  if (member.can_post_messages === false) {
    throw new Error("У бота нет права публиковать сообщения в этом канале.");
  }

  return { bot, chat };
}

export async function getTelegramMemberCount(botToken: string, channelId: string): Promise<number> {
  return telegramApi<number>(botToken, "getChatMemberCount", { chat_id: channelId });
}

export async function sendTelegramPost(botToken: string, channelId: string, text: string): Promise<{ messageId: number }> {
  const result = await telegramApi<{ message_id: number }>(botToken, "sendMessage", {
    chat_id: channelId,
    text,
    link_preview_options: { is_disabled: false },
  });
  return { messageId: result.message_id };
}

export async function sendTelegramMedia(
  botToken: string,
  channelId: string,
  text: string,
  media: { buffer: Buffer; fileName: string; mimeType: string; kind: "photo" | "video" },
): Promise<TelegramSendResult> {
  const form = new FormData();
  form.set("chat_id", channelId);
  const field = media.kind === "photo" ? "photo" : "video";
  const bytes = media.buffer.buffer.slice(
    media.buffer.byteOffset,
    media.buffer.byteOffset + media.buffer.byteLength,
  ) as ArrayBuffer;
  form.set(field, new Blob([bytes], { type: media.mimeType }), media.fileName);

  const captionFits = text.length <= 1024;
  if (captionFits && text) form.set("caption", text);
  if (media.kind === "video") form.set("supports_streaming", "true");

  const sent = await telegramMultipart<{ message_id: number }>(
    botToken,
    media.kind === "photo" ? "sendPhoto" : "sendVideo",
    form,
  );

  if (captionFits || !text) return { messageId: sent.message_id, mediaMessageId: sent.message_id };

  const followUp = await sendTelegramPost(botToken, channelId, text);
  return { messageId: followUp.messageId, mediaMessageId: sent.message_id };
}

export class TelegramConnector implements SocialConnector {
  constructor(private readonly botToken: string) {}

  async validateConnection(accountId: string): Promise<boolean> {
    if (!this.botToken || !accountId) return false;
    try {
      await validateTelegramConnection(this.botToken, accountId);
      return true;
    } catch {
      return false;
    }
  }

  async publish(input: PublishRequest): Promise<PublishResult> {
    if (!input.accountId) return { ok: false, error: "Не указан Telegram-канал" };
    if (!this.botToken) return { ok: false, error: "Не указан токен Telegram-бота" };
    try {
      const sent = await sendTelegramPost(this.botToken, input.accountId, input.text);
      return { ok: true, externalPostId: String(sent.messageId) };
    } catch (error) {
      return { ok: false, error: error instanceof Error ? error.message : "Не удалось опубликовать пост" };
    }
  }
}
