import { db } from "@/lib/db";
import { resolveWorkspaceId } from "@/lib/workspace-context";
import { getInstagramConnection } from "@/lib/instagram-vault";
import { refreshInstagramToken } from "@/lib/instagram";

const GRAPH_URL = "https://graph.instagram.com";

export type InstagramMediaInsight = {
  id: string;
  timestamp?: string;
  mediaType?: string;
  productType?: string;
  permalink?: string;
  caption?: string;
  views?: number;
  reach?: number;
  likes?: number;
  comments?: number;
  saved?: number;
  shares?: number;
  totalInteractions?: number;
};

export type InstagramInsightSnapshot = {
  id: string;
  capturedAt: string;
  userId: string;
  username: string;
  followers?: number;
  mediaCount?: number;
  period: { since: string; until: string };
  metrics: Record<string, number>;
  recentMedia: InstagramMediaInsight[];
};

async function graph<T>(pathname: string, params: Record<string, string>, token: string): Promise<T> {
  const url = new URL(`${GRAPH_URL}/${pathname}`);
  for (const [key, value] of Object.entries(params)) url.searchParams.set(key, value);
  url.searchParams.set("access_token", token);
  const response = await fetch(url, { cache: "no-store" });
  const data = await response.json() as T & { error?: { message?: string } };
  if (!response.ok) throw new Error(data.error?.message || `Instagram Insights API: ${response.status}`);
  return data;
}

function readInsightValue(entry: any): number | undefined {
  const direct = entry?.total_value?.value;
  if (typeof direct === "number") return direct;
  const values = Array.isArray(entry?.values) ? entry.values : [];
  const last = values[values.length - 1]?.value;
  return typeof last === "number" ? last : undefined;
}

async function accountMetrics(userId: string, token: string, since: string, until: string) {
  const names = ["views", "reach", "accounts_engaged", "total_interactions", "likes", "comments", "shares", "saves"];
  const params = { metric: names.join(","), period: "day", metric_type: "total_value", since, until };
  try {
    const data = await graph<{ data?: any[] }>(`${userId}/insights`, params, token);
    return Object.fromEntries((data.data || []).map((entry) => [entry.name, readInsightValue(entry)]).filter((pair) => typeof pair[1] === "number")) as Record<string, number>;
  } catch {
    const pairs = await Promise.all(names.map(async (name) => {
      try {
        const data = await graph<{ data?: any[] }>(`${userId}/insights`, { metric: name, period: "day", metric_type: "total_value", since, until }, token);
        const value = readInsightValue(data.data?.[0]);
        return typeof value === "number" ? [name, value] as const : null;
      } catch { return null; }
    }));
    return Object.fromEntries(pairs.filter(Boolean) as Array<readonly [string, number]>);
  }
}

async function mediaInsights(media: any, token: string): Promise<InstagramMediaInsight> {
  const base: InstagramMediaInsight = { id: String(media.id), timestamp: media.timestamp, mediaType: media.media_type, productType: media.media_product_type, permalink: media.permalink, caption: media.caption };
  const metrics = ["views", "reach", "likes", "comments", "saved", "shares", "total_interactions"];
  try {
    const data = await graph<{ data?: any[] }>(`${media.id}/insights`, { metric: metrics.join(",") }, token);
    const values = Object.fromEntries((data.data || []).map((entry) => [entry.name, readInsightValue(entry)]));
    return { ...base, views: values.views, reach: values.reach, likes: values.likes, comments: values.comments, saved: values.saved, shares: values.shares, totalInteractions: values.total_interactions };
  } catch { return base; }
}

export async function captureInstagramInsights(days = 7, workspaceId?: string): Promise<InstagramInsightSnapshot> {
  const ws = await resolveWorkspaceId(workspaceId);
  const stored = await getInstagramConnection(ws);
  if (!stored) throw new Error("Instagram не подключён");
  const connection = await refreshInstagramToken(stored, ws);
  const untilDate = new Date();
  const sinceDate = new Date(Date.now() - Math.max(1, Math.min(days, 30)) * 24 * 60 * 60 * 1000);
  const since = sinceDate.toISOString().slice(0, 10);
  const until = untilDate.toISOString().slice(0, 10);

  const profile = await graph<{ id?: string; username?: string; followers_count?: number; media_count?: number }>("me", { fields: "id,username,followers_count,media_count" }, connection.accessToken);
  const metrics = await accountMetrics(connection.userId, connection.accessToken, since, until);
  const mediaResponse = await graph<{ data?: any[] }>(`${connection.userId}/media`, { fields: "id,caption,media_type,media_product_type,timestamp,permalink", limit: "8" }, connection.accessToken).catch(() => ({ data: [] }));
  const recentMedia = await Promise.all((mediaResponse.data || []).slice(0, 8).map((media) => mediaInsights(media, connection.accessToken)));

  const payload = { username: profile.username || connection.username, followers: profile.followers_count, mediaCount: profile.media_count, period: { since, until }, metrics, recentMedia };
  const cleanPayload = JSON.parse(JSON.stringify(payload));
  const row = await db.analyticsEvent.create({ data: { workspaceId: ws, network: "INSTAGRAM", accountRef: connection.userId, kind: "account_insights", payload: cleanPayload as any } });
  return { id: row.id, capturedAt: row.capturedAt.toISOString(), userId: connection.userId, ...cleanPayload } as InstagramInsightSnapshot;
}

export async function listInstagramInsights(userId?: string, workspaceId?: string) {
  const ws = await resolveWorkspaceId(workspaceId);
  const rows = await db.analyticsEvent.findMany({ where: { workspaceId: ws, network: "INSTAGRAM", kind: "account_insights", ...(userId ? { accountRef: userId } : {}) }, orderBy: { capturedAt: "asc" }, take: 120 });
  return rows.map((row) => ({ ...(row.payload as any), id: row.id, capturedAt: row.capturedAt.toISOString(), userId: row.accountRef })) as InstagramInsightSnapshot[];
}
