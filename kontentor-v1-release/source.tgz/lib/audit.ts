import { db } from "@/lib/db";
import { resolveWorkspaceId } from "@/lib/workspace-context";
import { getSessionPayload } from "@/lib/auth";

export async function writeAudit(action: string, input?: { entity?: string; entityId?: string; metadata?: unknown; workspaceId?: string }) {
  try {
    const session = await getSessionPayload();
    const workspaceId = await resolveWorkspaceId(input?.workspaceId || session?.workspaceId);
    await db.auditLog.create({ data: { workspaceId, userId: session?.userId, action, entity: input?.entity, entityId: input?.entityId, metadata: input?.metadata as any } });
  } catch {}
}
