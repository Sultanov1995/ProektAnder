import { getInstagramConnection, saveInstagramConnection, type InstagramConnection } from "@/lib/instagram-vault";
import type { StoredMedia } from "@/lib/publication-store";
import { createPublicMediaUrl } from "@/lib/public-media";

const AUTH_URL = "https://www.instagram.com/oauth/authorize";
const TOKEN_URL = "https://api.instagram.com/oauth/access_token";
const GRAPH_URL = "https://graph.instagram.com";

export function instagramRedirectUri() {
  const explicit = process.env.INSTAGRAM_REDIRECT_URI?.trim();
  if (explicit) return explicit;
  const base = (process.env.PUBLIC_APP_URL || process.env.APP_URL)?.replace(/\/$/, "");
  if (!base) throw new Error("Укажите PUBLIC_APP_URL или INSTAGRAM_REDIRECT_URI");
  return `${base}/api/instagram/oauth/callback`;
}

export function buildInstagramAuthUrl(state: string) {
  const appId = process.env.INSTAGRAM_APP_ID;
  if (!appId) throw new Error("INSTAGRAM_APP_ID не настроен");
  const params = new URLSearchParams({
    client_id: appId,
    redirect_uri: instagramRedirectUri(),
    response_type: "code",
    scope: [
      "instagram_business_basic",
      "instagram_business_content_publish",
      "instagram_business_manage_insights",
    ].join(","),
    state,
  });
  return `${AUTH_URL}?${params.toString()}`;
}

type TokenResponse = { access_token?: string; user_id?: string | number; expires_in?: number; error_message?: string; error?: { message?: string } };

type ProfileResponse = { id?: string; user_id?: string; username?: string; account_type?: string; name?: string; error?: { message?: string } };

async function parseJson<T>(response: Response): Promise<T> {
  const data = await response.json() as T;
  if (!response.ok) {
    const value = data as unknown as { error?: { message?: string }; error_message?: string };
    throw new Error(value.error?.message || value.error_message || `Instagram API: ${response.status}`);
  }
  return data;
}

export async function exchangeInstagramCode(code: string) {
  const appId = process.env.INSTAGRAM_APP_ID;
  const appSecret = process.env.INSTAGRAM_APP_SECRET;
  if (!appId || !appSecret) throw new Error("INSTAGRAM_APP_ID / INSTAGRAM_APP_SECRET не настроены");

  const form = new URLSearchParams({
    client_id: appId,
    client_secret: appSecret,
    grant_type: "authorization_code",
    redirect_uri: instagramRedirectUri(),
    code,
  });
  const shortResponse = await fetch(TOKEN_URL, { method: "POST", body: form, cache: "no-store" });
  const short = await parseJson<TokenResponse>(shortResponse);
  if (!short.access_token) throw new Error("Instagram не вернул access token");

  let accessToken = short.access_token;
  let expiresIn = short.expires_in;
  const longUrl = new URL(`${GRAPH_URL}/access_token`);
  longUrl.searchParams.set("grant_type", "ig_exchange_token");
  longUrl.searchParams.set("client_secret", appSecret);
  longUrl.searchParams.set("access_token", short.access_token);
  try {
    const long = await parseJson<TokenResponse>(await fetch(longUrl, { cache: "no-store" }));
    if (long.access_token) accessToken = long.access_token;
    if (long.expires_in) expiresIn = long.expires_in;
  } catch {
    // Short-lived token is still usable; connection can be refreshed later.
  }

  const profileUrl = new URL(`${GRAPH_URL}/me`);
  profileUrl.searchParams.set("fields", "id,username,account_type");
  profileUrl.searchParams.set("access_token", accessToken);
  const profile = await parseJson<ProfileResponse>(await fetch(profileUrl, { cache: "no-store" }));
  const userId = String(profile.user_id || profile.id || short.user_id || "");
  if (!userId || !profile.username) throw new Error("Не удалось определить Instagram Professional аккаунт");

  const connection: InstagramConnection = {
    userId,
    username: profile.username,
    accountType: profile.account_type,
    connectedAt: new Date().toISOString(),
    expiresAt: expiresIn ? new Date(Date.now() + expiresIn * 1000).toISOString() : undefined,
    accessToken,
  };
  await saveInstagramConnection(connection);
  return connection;
}

export async function refreshInstagramToken(connection: InstagramConnection, workspaceId?: string) {
  const expiresAt = connection.expiresAt ? new Date(connection.expiresAt).getTime() : 0;
  if (expiresAt && expiresAt - Date.now() > 7 * 24 * 60 * 60 * 1000) return connection;
  const url = new URL(`${GRAPH_URL}/refresh_access_token`);
  url.searchParams.set("grant_type", "ig_refresh_token");
  url.searchParams.set("access_token", connection.accessToken);
  try {
    const refreshed = await parseJson<TokenResponse>(await fetch(url, { cache: "no-store" }));
    if (!refreshed.access_token) return connection;
    const next = {
      ...connection,
      accessToken: refreshed.access_token,
      expiresAt: refreshed.expires_in ? new Date(Date.now() + refreshed.expires_in * 1000).toISOString() : connection.expiresAt,
    };
    await saveInstagramConnection(next, workspaceId);
    return next;
  } catch {
    return connection;
  }
}

async function postGraph(pathname: string, params: Record<string, string>) {
  const body = new URLSearchParams(params);
  return parseJson<{ id?: string; error?: { message?: string } }>(await fetch(`${GRAPH_URL}/${pathname}`, {
    method: "POST",
    body,
    cache: "no-store",
  }));
}

async function waitForContainer(containerId: string, token: string) {
  for (let attempt = 0; attempt < 12; attempt += 1) {
    const url = new URL(`${GRAPH_URL}/${containerId}`);
    url.searchParams.set("fields", "status_code,status");
    url.searchParams.set("access_token", token);
    const data = await parseJson<{ status_code?: string; status?: string }>(await fetch(url, { cache: "no-store" }));
    if (data.status_code === "FINISHED") return;
    if (data.status_code === "ERROR" || data.status_code === "EXPIRED") throw new Error(`Instagram не подготовил медиа: ${data.status || data.status_code}`);
    await new Promise((resolve) => setTimeout(resolve, 2500));
  }
  throw new Error("Instagram слишком долго обрабатывает медиа. Попробуйте позже.");
}

export async function publishInstagramPost(input: { text: string; media: StoredMedia; connection?: InstagramConnection; workspaceId?: string }) {
  if (input.text.length > 2200) throw new Error("Подпись Instagram должна быть не длиннее 2200 символов");
  const stored = input.connection || await getInstagramConnection(input.workspaceId);
  if (!stored) throw new Error("Instagram не подключён");
  const connection = await refreshInstagramToken(stored, input.workspaceId);
  const mediaUrl = createPublicMediaUrl(input.media, 30 * 60);

  const createParams: Record<string, string> = {
    access_token: connection.accessToken,
    caption: input.text,
  };
  if (input.media.kind === "video") {
    createParams.media_type = "REELS";
    createParams.video_url = mediaUrl;
    createParams.share_to_feed = "true";
  } else {
    createParams.image_url = mediaUrl;
  }

  const created = await postGraph(`${connection.userId}/media`, createParams);
  if (!created.id) throw new Error("Instagram не создал контейнер публикации");
  await waitForContainer(created.id, connection.accessToken);
  const published = await postGraph(`${connection.userId}/media_publish`, {
    creation_id: created.id,
    access_token: connection.accessToken,
  });
  if (!published.id) throw new Error("Instagram не вернул ID публикации");

  let permalink: string | undefined;
  try {
    const url = new URL(`${GRAPH_URL}/${published.id}`);
    url.searchParams.set("fields", "permalink");
    url.searchParams.set("access_token", connection.accessToken);
    const data = await parseJson<{ permalink?: string }>(await fetch(url, { cache: "no-store" }));
    permalink = data.permalink;
  } catch {}

  return { mediaId: published.id, permalink };
}
