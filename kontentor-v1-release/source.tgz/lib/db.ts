import { PrismaPg } from "@prisma/adapter-pg";
import { PrismaClient } from "@/generated/prisma/client";

const globalForPrisma = globalThis as unknown as { kontentorPrisma?: PrismaClient };

function createClient() {
  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) throw new Error("DATABASE_URL не настроен. KONTENTOR v1.0 использует PostgreSQL как основное хранилище.");
  const adapter = new PrismaPg({ connectionString });
  return new PrismaClient({ adapter });
}

export const db = globalForPrisma.kontentorPrisma ?? createClient();
if (process.env.NODE_ENV !== "production") globalForPrisma.kontentorPrisma = db;
