import { NextRequest, NextResponse } from "next/server";

const COOKIE = "kontentor_session";
const publicPrefixes = ["/login", "/register", "/api/auth/login", "/api/auth/register", "/api/health", "/api/media/public", "/api/cron", "/_next", "/favicon", "/icon", "/kontentor-logo-approved.png", "/kontentor-icon-approved.png", "/sw.js", "/manifest.webmanifest"];
const analystWriteAllow = ["/api/auth/logout", "/api/auth/switch-workspace", "/api/team/invite/accept"];

function bytesToBase64Url(bytes: ArrayBuffer) {
  let binary = ""; for (const b of new Uint8Array(bytes)) binary += String.fromCharCode(b);
  return btoa(binary).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"");
}
function decodePayload(raw: string) {
  const base64 = raw.replace(/-/g,"+").replace(/_/g,"/") + "===".slice((raw.length + 3) % 4);
  return JSON.parse(atob(base64)) as { userId?: string; workspaceId?: string; role?: string; sv?: number; exp?: number };
}
async function readSession(token?: string) {
  if (!token) return null; const [raw, sig] = token.split("."); const secret = process.env.AUTH_SECRET;
  if (!raw || !sig || !secret || secret.length < 32) return null;
  try {
    const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
    const expected = bytesToBase64Url(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(raw)));
    if (expected !== sig) return null;
    const payload = decodePayload(raw);
    if (!(payload.userId && payload.workspaceId && payload.role && Number.isInteger(payload.sv) && Number(payload.sv) >= 1 && payload.exp && payload.exp > Math.floor(Date.now()/1000))) return null;
    return payload;
  } catch { return null; }
}
function isMutation(method:string){return !["GET","HEAD","OPTIONS"].includes(method.toUpperCase())}
function firstHeader(value: string | null) { return value?.split(",")[0]?.trim().toLowerCase() || ""; }
function configuredHost(value?: string) { if (!value) return ""; try { return new URL(value).host.toLowerCase(); } catch { return ""; } }
function sameOrigin(request:NextRequest){
  const origin=request.headers.get("origin"); if(!origin)return false;
  try{
    const originUrl=new URL(origin); if(!["http:","https:"].includes(originUrl.protocol))return false;
    const expectedHosts=new Set([
      firstHeader(request.headers.get("x-forwarded-host")), firstHeader(request.headers.get("host")),
      request.nextUrl.host.toLowerCase(), configuredHost(process.env.APP_URL), configuredHost(process.env.PUBLIC_APP_URL),
    ].filter(Boolean));
    if(!expectedHosts.has(originUrl.host.toLowerCase()))return false;
    const forwardedProto=firstHeader(request.headers.get("x-forwarded-proto"));
    if(forwardedProto && originUrl.protocol !== `${forwardedProto}:`)return false;
    return true;
  }catch{return false}
}

export default async function proxy(request: NextRequest) {
  const path = request.nextUrl.pathname;
  const isPublic = publicPrefixes.some((prefix) => path === prefix || path.startsWith(prefix + "/"));
  const isAuthScreen = path === "/login" || path === "/register";
  const session = await readSession(request.cookies.get(COOKIE)?.value);
  if (!session && !isPublic) {
    if (path.startsWith("/api/")) return NextResponse.json({ ok: false, error: "Требуется вход в KONTENTOR" }, { status: 401 });
    const url = new URL("/login", request.url); url.searchParams.set("next", path); return NextResponse.redirect(url);
  }
  if (session && isAuthScreen) return NextResponse.redirect(new URL("/", request.url));
  if (path.startsWith("/api/") && isMutation(request.method) && !path.startsWith("/api/cron")) {
    if (!sameOrigin(request)) return NextResponse.json({ok:false,error:"Запрос отклонён: неверный Origin"},{status:403});
    if (session?.role === "analyst" && !analystWriteAllow.some((p)=>path===p||path.startsWith(p+"/"))) return NextResponse.json({ok:false,error:"Роль Analyst доступна только для просмотра."},{status:403});
  }
  const response=NextResponse.next();
  response.headers.set("X-Content-Type-Options","nosniff"); response.headers.set("Referrer-Policy","strict-origin-when-cross-origin"); return response;
}
export const config = { matcher: ["/((?!.*\\.(?:css|js|map|png|jpg|jpeg|webp|svg|ico|woff2?)$).*)"] };
