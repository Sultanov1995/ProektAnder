# KONTENTOR v1.0

**KONTENTOR — Ваши соцсети. Один интеллект.**

Production-foundation SaaS для управления Telegram, Instagram Professional, VK и YouTube из одного рабочего пространства: контент, AI Radar, медиатека, календарь, публикация, аналитика, AI-стратег и автоматизация.

## Бренд и интерфейс

v1.0 использует зафиксированный **вариант №2**. Канонические assets находятся в `public/`:

- `kontentor-logo-approved.png` — точная горизонтальная композиция из согласованного бренд-борда;
- `kontentor-icon-approved-tight.png` — точная иконка K;
- `kontentor-icon-192.png` / `kontentor-icon-512.png` — PWA-иконки.

Фирменная система: `#B6FF3D` Lime, `#2F6BFF` Deep Blue, `#0B0F14` Charcoal, `#1E2937` Slate, Inter. Не заменяйте эти assets на заново нарисованный похожий знак.

## Что входит в v1.0

- регистрация и вход по email/паролю;
- подписанная server-side сессия `kontentor_session`;
- onboarding нового проекта;
- несколько рабочих пространств на одного пользователя;
- роли `owner / admin / editor / analyst`;
- приглашения команды по одноразовой ссылке;
- тарифный каркас `Start / Pro / Team` и trial 14 дней;
- PostgreSQL + Prisma как основной runtime storage;
- Telegram Bot API + MTProto Analytics;
- Instagram Professional OAuth / Insights / publishing;
- VK ID OAuth 2.1 + PKCE, publishing и analytics;
- Google/YouTube OAuth, upload и YouTube Analytics;
- единый контент, календарь и журнал delivery status;
- AI Radar, AI-стратег, review/autopilot;
- AI Media Studio: генерация и редактирование изображений;
- S3-compatible media storage;
- installable PWA;
- multi-workspace cron jobs;
- audit/security foundation.

## Локальный запуск

Требования: Node.js 22+, PostgreSQL.

```bash
npm install
cp .env.example .env
docker compose up -d
npm run db:generate
npm run db:push
npm run dev
```

Откройте `http://localhost:3000`, зарегистрируйтесь и пройдите onboarding.

Перед production:

```bash
npm run self-check
npm run lint
npm run build
```

## Production

### Production security gate

Сборка v1.0.1 останавливается, если `npm audit --audit-level=high` находит high/critical vulnerability. Top-level зависимости закреплены точными версиями; проверенный Railway build R9 завершился с `0 vulnerabilities`.

 env

Минимально обязательны:

```env
DATABASE_URL="postgresql://..."
APP_URL="https://app.example.ru"
PUBLIC_APP_URL="https://app.example.ru"
AUTH_SECRET="minimum-32-random-characters"
APP_ENCRYPTION_KEY="long-random-secret"
CRON_SECRET="another-long-random-secret"
PUBLIC_MEDIA_SECRET="random-secret"
```

`AUTH_SECRET`, `APP_ENCRYPTION_KEY`, `CRON_SECRET` и OAuth secrets нельзя хранить в Git.

### OpenAI

```env
OPENAI_API_KEY=""
OPENAI_MODEL="gpt-5.6-luna"
OPENAI_IMAGE_MODEL="gpt-image-2.5-flare"
OPENAI_IMAGE_EDIT_MODEL="gpt-image-2.5-sunburst"
```

### Instagram Professional

```env
INSTAGRAM_APP_ID=""
INSTAGRAM_APP_SECRET=""
INSTAGRAM_REDIRECT_URI="https://app.example.ru/api/instagram/oauth/callback"
```

### VK ID

```env
VK_ID_APP_ID=""
VK_ID_REDIRECT_URI="https://app.example.ru/socials/vk"
VK_ID_SCOPE="groups wall photos"
VK_ID_DOMAIN="id.vk.ru"
VK_API_VERSION="5.199"
```

### YouTube

```env
GOOGLE_CLIENT_ID=""
GOOGLE_CLIENT_SECRET=""
GOOGLE_REDIRECT_URI="https://app.example.ru/api/youtube/oauth/callback"
YOUTUBE_DEFAULT_PRIVACY="private"
```

### Telegram MTProto Analytics

```env
TELEGRAM_API_ID=""
TELEGRAM_API_HASH=""
TELEGRAM_MT_SESSION=""
```

Создание сессии выполняется локально: `npm run telegram:session`. Не передавайте строку MTProto-сессии третьим лицам.

### S3-compatible storage

```env
S3_ENDPOINT=""
S3_REGION="ru-1"
S3_BUCKET=""
S3_ACCESS_KEY_ID=""
S3_SECRET_ACCESS_KEY=""
S3_FORCE_PATH_STYLE="0"
```

Без S3 локальная разработка использует `.data/uploads`.

## Cron

Каждый cron защищён `Authorization: Bearer <CRON_SECRET>` и обрабатывает рабочие пространства отдельно:

- `/api/cron/publish` — очередь публикаций;
- `/api/cron/radar` — сбор новых тем;
- `/api/cron/analytics` — аналитика площадок;
- `/api/cron/autopilot` — недельный план и автоматизация.

## PWA

`app/manifest.ts` + `public/sw.js` позволяют установить KONTENTOR на Android/desktop из браузера. API-ответы service worker не кэширует. В PWA используются те же утверждённые PNG-assets логотипа.

## Безопасность v1.0

- пароли хешируются через `scrypt`;
- сессионный cookie подписан HMAC;
- mutating API проверяет `Origin`;
- роль Analyst блокируется от записывающих API-операций;
- OAuth/social tokens шифруются сервером;
- production headers включают `DENY` для framing, `nosniff` и строгую referrer policy;
- cron endpoints требуют отдельный секрет;
- `.env` исключён из Git.

Перед коммерческим запуском всё равно обязательны end-to-end OAuth тесты с реальными приложениями соцсетей, резервное копирование PostgreSQL/S3, мониторинг ошибок и политика восстановления доступа.

## Тарифы

В v1.0 реализован **тарифный каркас и учёт подписки**. Реальный эквайринг/автосписания ещё не подключены — нельзя считать раздел Billing платёжной системой, пока не будет добавлен выбранный российский провайдер.

## Railway

Production-сервис должен запускать миграцию/синхронизацию Prisma до `next start`, использовать отдельный PostgreSQL и HTTPS-домен. Redirect URI всех OAuth-провайдеров должны точно совпадать с публичным доменом KONTENTOR.
