import Link from "next/link";
import { Logo } from "@/components/Logo";
import { Sidebar } from "@/components/Sidebar";

export function ComingSoon({ active, title, description }: { active: string; title: string; description: string }) {
  return (
    <div className="shell">
      <Sidebar active={active} />
      <main className="main coming">
        <div className="card coming-card">
          <Logo compact />
          <div className="eyebrow">Следующий модуль</div>
          <h1>{title}</h1>
          <p className="sub">{description}</p>
          <div className="btns" style={{ justifyContent: "center" }}>
            <Link className="primary button-link" href="/socials/telegram">Настроить Telegram</Link>
            <Link className="secondary button-link" href="/">На главную</Link>
          </div>
        </div>
      </main>
    </div>
  );
}
