"use client";

import { useCallback, useEffect, useState } from "react";

type Network = "telegram" | "instagram" | "vk" | "youtube";
type Analysis = {
  id?: string;
  network: Network;
  capturedAt: string;
  account: { id: string; title: string; username?: string };
  dataLevel: "Базовый" | "Расширенный";
  headline: string;
  summary: string;
  metrics: Array<{ label: string; value: string; note?: string }>;
  strengths: string[];
  risks: string[];
  recommendations: string[];
  topContent: Array<{ title: string; metric: string; link?: string }>;
  limitations: string[];
};

const labels: Record<Network, { action: string; subject: string }> = {
  telegram: { action: "Проанализировать канал", subject: "Telegram-канала" },
  instagram: { action: "Проанализировать аккаунт", subject: "Instagram-аккаунта" },
  vk: { action: "Проанализировать сообщество", subject: "сообщества VK" },
  youtube: { action: "Проанализировать канал", subject: "YouTube-канала" },
};

export function ChannelAnalysisPanel({ network }: { network: Network }) {
  const [analysis, setAnalysis] = useState<Analysis | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    try {
      const response = await fetch(`/api/analytics/analyze?network=${network}`, { cache: "no-store" });
      const data = await response.json();
      if (response.ok && data.ok && data.analysis) setAnalysis(data.analysis);
    } catch { /* analysis is optional until the user runs it */ }
  }, [network]);

  useEffect(() => { void load(); }, [load]);

  async function run() {
    setBusy(true); setError("");
    try {
      const response = await fetch("/api/analytics/analyze", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ network }),
      });
      const data = await response.json();
      if (!response.ok || !data.ok) throw new Error(data.error || "Не удалось выполнить анализ");
      setAnalysis(data.analysis);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Не удалось выполнить анализ");
    } finally { setBusy(false); }
  }

  if (!analysis) {
    return <section className="card channel-analysis-card analysis-empty">
      <div className="analysis-title-row"><div><div className="eyebrow">KONTENTOR CHANNEL INTELLIGENCE</div><h2>Экспресс-анализ {labels[network].subject}</h2></div><span className="analysis-level">ПО ЗАПРОСУ</span></div>
      <p className="sub">KONTENTOR соберёт свежие метрики площадки, выделит сильные стороны, риски и конкретные действия для роста. Анализ сохраняется и обновляется при следующем запуске.</p>
      {error && <div className="notice error">{error}</div>}
      <button className="primary analysis-run" disabled={busy} onClick={() => void run()}>{busy ? "Собираем данные и анализируем…" : labels[network].action}</button>
    </section>;
  }

  return <section className="card channel-analysis-card">
    <div className="analysis-title-row">
      <div><div className="eyebrow">KONTENTOR CHANNEL INTELLIGENCE</div><h2>{analysis.headline}</h2><p className="sub">{analysis.summary}</p></div>
      <div className="analysis-meta"><span className="analysis-level">{analysis.dataLevel}</span><small>{new Date(analysis.capturedAt).toLocaleString("ru-RU")}</small></div>
    </div>

    <div className="analysis-metrics">{analysis.metrics.map((item) => <div className="analysis-metric" key={item.label}><span>{item.label}</span><b>{item.value}</b>{item.note && <small>{item.note}</small>}</div>)}</div>

    <div className="analysis-columns">
      <div className="analysis-block good"><div className="eyebrow">Сильные стороны</div>{analysis.strengths.length ? <ul>{analysis.strengths.map((x,i)=><li key={i}>{x}</li>)}</ul> : <p className="sub">Нужно больше истории для уверенных выводов.</p>}</div>
      <div className="analysis-block risk"><div className="eyebrow">Что ограничивает рост</div>{analysis.risks.length ? <ul>{analysis.risks.map((x,i)=><li key={i}>{x}</li>)}</ul> : <p className="sub">Критичных сигналов в текущем снимке нет.</p>}</div>
    </div>

    <div className="analysis-block recommendations"><div className="eyebrow">Что делать дальше</div><ol>{analysis.recommendations.map((x,i)=><li key={i}><span>{i+1}</span><p>{x}</p></li>)}</ol></div>

    {analysis.topContent.length > 0 && <div className="analysis-block"><div className="eyebrow">Лучший контент в доступной выборке</div><div className="analysis-top-list">{analysis.topContent.map((item,i)=><div className="analysis-top-item" key={`${item.title}-${i}`}><div><b>{item.title}</b><small>{item.metric}</small></div>{item.link && <a href={item.link} target="_blank" rel="noreferrer">Открыть ↗</a>}</div>)}</div></div>}

    {analysis.limitations.length > 0 && <details className="analysis-limitations"><summary>Ограничения данных</summary><ul>{analysis.limitations.map((x,i)=><li key={i}>{x}</li>)}</ul></details>}
    {error && <div className="notice error">{error}</div>}
    <div className="analysis-footer"><button className="secondary" disabled={busy} onClick={() => void run()}>{busy ? "Обновляем анализ…" : "Обновить анализ"}</button><a className="inline-link" href="/analytics">Открыть общую аналитику →</a></div>
  </section>;
}
