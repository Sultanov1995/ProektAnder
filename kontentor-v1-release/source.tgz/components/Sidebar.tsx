"use client";
import Link from "next/link";
import { useEffect,useState } from "react";
import { Logo } from "@/components/Logo";

const links=[
 ["Главная","/","⌂"],["Контент","/content","▤"],["Календарь","/calendar","▣"],["Аналитика","/analytics","▥"],["ИИ-ассистент","/assistant","✦"],["AI Радар","/radar","⌁"],["Медиа-студия","/media","◫"],["Соцсети","/socials","◎"],["Настройки","/settings","⚙"],
] as const;

type Me={user:{name?:string;email:string};workspace:{id:string;name:string};role:string;workspaces:Array<{id:string;name:string;role:string;plan:string}>};
export function Sidebar({active="Главная"}:{active?:string}){
 const[me,setMe]=useState<Me|null>(null);useEffect(()=>{fetch("/api/auth/me",{cache:"no-store"}).then(r=>r.json()).then(d=>{if(d.ok)setMe(d)}).catch(()=>{})},[]);
 async function switchWs(id:string){const r=await fetch("/api/auth/switch-workspace",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({workspaceId:id})});if(r.ok)location.reload()}
 async function logout(){await fetch("/api/auth/logout",{method:"POST"});location.href="/login"}
 return <aside className="sidebar v1-sidebar">
   <Logo/>
   <div className="workspace-switcher"><span className="workspace-k">K</span><div><small>РАБОЧЕЕ ПРОСТРАНСТВО</small><select value={me?.workspace?.id||""} onChange={e=>{if(e.target.value)void switchWs(e.target.value)}}><option value={me?.workspace?.id||""}>{me?.workspace?.name||"KONTENTOR"}</option>{me?.workspaces.filter(x=>x.id!==me?.workspace?.id).map(w=><option key={w.id} value={w.id}>{w.name}</option>)}</select></div></div>
   <nav className="nav v1-nav" aria-label="Основная навигация">{links.map(([label,href,icon])=><Link key={label} className={active===label?"active":""} href={href}><span className="nav-icon">{icon}</span><span>{label}</span>{label==="ИИ-ассистент"&&<em>AI</em>}</Link>)}</nav>
   <div className="sidebar-bottom"><div className="account-mini"><div className="avatar-mini">{(me?.user?.name||me?.user?.email||"K").slice(0,1).toUpperCase()}</div><div><b>{me?.user?.name||"KONTENTOR"}</b><small>{me?.role||"owner"} · {me?.workspaces?.[0]?.plan||"start"}</small></div><button onClick={()=>void logout()} title="Выйти">↪</button></div><div className="sidebar-note"><span className="pulse-dot"/><div><b>KONTENTOR v1.0</b><small>Production foundation</small></div></div></div>
 </aside>
}
