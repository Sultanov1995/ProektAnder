export function Logo({ compact = false }: { compact?: boolean }) {
  if (compact) {
    return <div className="logo-lockup logo-compact" aria-label="KONTENTOR"><img className="logo-approved-icon" src="/kontentor-icon-approved-tight.png" alt="KONTENTOR" /></div>;
  }
  return <div className="logo-lockup logo-approved-lockup" aria-label="KONTENTOR"><img className="logo-approved-full" src="/kontentor-logo-approved.png" alt="KONTENTOR — ИИ-платформа управления соцсетями" /></div>;
}
