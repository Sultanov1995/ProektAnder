"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";

type Network = "telegram" | "instagram" | "vk" | "youtube";
type Analysis = {
  id: string; network: Network; accountLabel: string; generatedAt: string; dataQuality: "low" | "medium" | "high";
  detectedNiche: string; summary: string; audienceProfile: string; strengths: string[]; risks: string[]; growthDirections: string[];
  contentPillars: Array<{ title: string; why: string; examples: string[] }>;
  recommendedFormats: Array<{ format: string; reason: string; frequency: string }>;
  metricsSummary: Array<{ label: string; value: string }>;
  dataNotes: string[];
  nextDays: Array<{ date: string; time: string; topic: string; angle: string; objective: string; format: string; hook: string; material: string; visualBrief: string; cta: string; publicationId?: string }>;
};

const networkLabel: Record<Network,string> = { telegram:"Telegram", instagram:"Instagram", vk:"VK", youtube:"YouTube" };

export function SocialAnalysisPanel({ network, connected, accountLabel }: { network: Network; connected: boolean; accountLabel?: string }) {
  const [analysis,setAnalysis]=useState<Analysis|null>(null),[loading,setLoading]=useState(false),[busy,setBusy]=useState(false),[message,setMessage]=useState<{ok:boolean;text:string}|null>(null);
  const load=useCallback(async()=>{if(!connected)return;setLoading(true);try{const r=await fetch(`/api/analysis/channel?network=${network}`,{cache:"no-store"});const d=await r.json();if(r.ok&&d.ok)setAnalysis(d.analysis||null);}finally{setLoading(false)}},[connected,network]);
  useEffect(()=>{void load()},[load]);
  async function analyze(){setBusy(true);setMessage(null);try{const r=await fetch("/api/analysis/channel",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({network})});const d=await r.json();if(!r.ok||!d.ok)throw new Error(d.error||"Не удалось провести анализ");setAnalysis(d.analysis);setMessage({ok:true,text:"Анализ готов. 5 материалов созданы и добавлены на согласование."});}catch(e){setMessage({ok:false,text:e instanceof Error?e.message:"Ошибка анализа"});}finally{setBusy(false)}}
  if(!connected)return null;
  return <section className="card intelligence-panel">
    <div className="intelligence-head"><div><div className="eyebrow">KONTENTOR CHANNEL INTELLIGENCE</div><h2>Анализ {networkLabel[network]}{accountLabel?` · ${accountLabel}`:""}</h2><p className="sub">Метрики → тематика → точки роста → рубрики → готовый контент на ближайшие 5 дней.</p></div><button className="primary intelligence-button" disabled={busy||loading} onClick={()=>void analyze()}>{busy?"Анализируем и создаём контент…":analysis?"Обновить анализ":"Проанализировать канал"}</button></div>
    {message&&<div className={`notice ${message.ok?"ok":"error"}`}>{message.text}</div>}
    {!analysis&&!loading&&<div className="intelligence-empty"><b>Один клик — и KONTENTOR подготовит стратегию.</b><p>Сервис обновит доступную статистику площадки, сравнит контент-сигналы и создаст материалы на 5 ближайших дней. Публикации останутся на согласовании.</p></div>}
    {loading&&!analysis&&<div className="intelligence-empty">Загрузка последнего анализа…</div>}
    {analysis&&<>
      <div className="analysis-meta"><span className={`quality quality-${analysis.dataQuality}`}>Данные: {analysis.dataQuality==="high"?"высокая точность":analysis.dataQuality==="medium"?"средняя точность":"ограничены"}</span><span>Обновлено {new Date(analysis.generatedAt).toLocaleString("ru-RU")}</span></div>
      <div className="analysis-hero"><div><span>Определённая тематика</span><b>{analysis.detectedNiche}</b></div><div><p>{analysis.summary}</p><p className="audience-profile"><b>Аудитория:</b> {analysis.audienceProfile}</p></div></div>
      {analysis.metricsSummary.length>0&&<div className="analysis-metrics">{analysis.metricsSummary.map((m)=><div key={m.label}><span>{m.label}</span><b>{m.value}</b></div>)}</div>}
      <div className="analysis-columns"><div><h3>Что уже сильное</h3>{analysis.strengths.map((x,i)=><p key={i}>✓ {x}</p>)}</div><div><h3>Риски / что улучшить</h3>{analysis.risks.map((x,i)=><p key={i}>• {x}</p>)}</div><div><h3>Куда расти дальше</h3>{analysis.growthDirections.map((x,i)=><p key={i}>{i+1}. {x}</p>)}</div></div>
      <div className="analysis-section"><div className="section-heading"><div><div className="eyebrow">Контент-ядро</div><h3>Какие тематики развивать</h3></div></div><div className="pillar-grid">{analysis.contentPillars.map((p)=><article key={p.title}><b>{p.title}</b><p>{p.why}</p><ul>{p.examples.map(e=><li key={e}>{e}</li>)}</ul></article>)}</div></div>
      <div className="analysis-section"><div className="section-heading"><div><div className="eyebrow">Форматы</div><h3>Что выпускать чаще</h3></div></div><div className="format-grid">{analysis.recommendedFormats.map((f)=><article key={f.format}><b>{f.format}</b><span>{f.frequency}</span><p>{f.reason}</p></article>)}</div></div>
      <div className="analysis-section"><div className="section-heading"><div><div className="eyebrow">Ближайшие 5 дней</div><h3>Готовые материалы</h3></div><div className="analysis-links"><Link href="/content">Контент →</Link><Link href="/calendar">Календарь →</Link></div></div><div className="future-content-list">{analysis.nextDays.map((p,i)=><article key={`${p.date}-${i}`} className="future-content-item"><div className="future-date"><b>{new Date(`${p.date}T12:00:00`).toLocaleDateString("ru-RU",{day:"2-digit",month:"short"})}</b><span>{p.time}</span></div><div className="future-copy"><div className="future-top"><span className="label">{p.format}</span><b>{p.topic}</b></div><p className="future-hook">{p.hook}</p><details><summary>Открыть готовый материал</summary><div className="future-material">{p.material}</div>{p.visualBrief&&<div className="visual-brief"><b>Визуал:</b> {p.visualBrief}</div>}</details></div><span className="status-badge strategy-review">На согласовании</span></article>)}</div></div>
      {analysis.dataNotes.length>0&&<div className="analysis-notes"><b>Ограничения анализа</b>{analysis.dataNotes.map((n,i)=><p key={i}>{n}</p>)}</div>}
    </>}
  </section>
}
