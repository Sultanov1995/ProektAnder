export type Network = "telegram" | "instagram" | "vk" | "youtube";

export interface PublishRequest {
  network: Network;
  accountId: string;
  text: string;
  mediaUrls?: string[];
  scheduledFor?: string;
}

export interface PublishResult {
  ok: boolean;
  externalPostId?: string;
  error?: string;
}

export interface SocialConnector {
  publish(input: PublishRequest): Promise<PublishResult>;
  validateConnection(accountId: string): Promise<boolean>;
}
