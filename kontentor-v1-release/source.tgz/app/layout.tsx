import "./globals.css";
import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { PwaRegister } from "@/components/PwaRegister";

export const metadata: Metadata = {
  title: "KONTENTOR — Ваши соцсети. Один интеллект.",
  description: "ИИ-платформа управления соцсетями: контент, аналитика, автоматизация и рост.",
  applicationName: "KONTENTOR",
  manifest: "/manifest.webmanifest",
  icons: {
    icon: [{ url: "/kontentor-icon-192.png", type: "image/png", sizes: "192x192" }],
    apple: [{ url: "/kontentor-icon-192.png", type: "image/png", sizes: "192x192" }],
  },
};

export const viewport: Viewport = {
  themeColor: "#0B0F14",
  colorScheme: "dark",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return <html lang="ru"><body><PwaRegister />{children}</body></html>;
}
