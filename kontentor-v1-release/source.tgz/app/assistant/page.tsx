"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { Sidebar } from "@/components/Sidebar";

type StrategyPost = {
  id: string; date: string; time: string; topic: string; angle: string; objective: string; format: string;
  platforms?: Array<"telegram" | "instagram" | "vk" | "youtube">; sourceRadarId: string; sourceUrl: string; status: "planned" | "review" | "scheduled" | "published" | "failed" | "skipped"; publicationId?: string;
};
type Strategy = { id: string; weekStart: string; generatedAt: string; summary: string; focus: string; actions: string[]; posts: StrategyPost[] };
type Settings = { mode: "review" | "autopilot"; timezone: string; preferredTimes: string[]; dailyLimit: number; radarMinScore: number };

const statusLabels: Record<StrategyPost["status"], string> = {
  planned: "В плане", review: "На согласовании", scheduled: "В расписании", published: "Опубликовано", failed: "Ошибка", skipped: "Пропущено",
};

export default function AssistantPage() {
  const [strategy, setStrategy] = useState<Strategy | null>(null);
  const [settings, setSettings] = useState<Settings | null>(null);
  const [busy, setBusy] = useState<"strategy" | "run" | null>(null);
  const [notice, setNotice] = useState<{ ok: boolean; text: string } | null>(null);

  const load = useCallback(async () => {
    const [strategyRes, settingsRes] = await Promise.all([
      fetch("/api/strategy/weekly", { cache: "no-store" }),
      fetch("/api/automation/settings", { cache: "no-store" }),
    ]);
    const [strategyJson, settingsJson] = await Promise.all([strategyRes.json(), settingsRes.json()]);
    if (strategyJson.ok) setStrategy(strategyJson.strategy);
    if (settingsJson.ok) setSettings(settingsJson.settings);
  }, []);

  useEffect(() => { void load(); }, [load]);

  async function generate() {
    setBusy("strategy"); setNotice(null);
    try {
      const res = await fetch("/api/strategy/weekly", { method: "POST" });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data.error || "Не удалось сформировать план");
      setStrategy(data.strategy);
      setNotice({ ok: true, text: "Недельная стратегия сформирована на основе текущих данных KONTENTOR." });
    } catch (error) {
      setNotice({ ok: false, text: error instanceof Error ? error.message : "Ошибка ИИ-стратега" });
    } finally { setBusy(null); }
  }

  async function runAutomation() {
    setBusy("run"); setNotice(null);
    try {
      const res = await fetch("/api/automation/run", { method: "POST" });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data.error || "Не удалось запустить автоматизацию");
      const created = data.result?.created?.length || 0;
      const mode = data.result?.mode === "autopilot" ? "в расписание" : "на согласование";
      setNotice({ ok: true, text: created ? `KONTENTOR подготовил публикаций: ${created} и отправил их ${mode}.` : "Новых публикаций для подготовки сейчас нет." });
      await load();
    } catch (error) {
      setNotice({ ok: false, text: error instanceof Error ? error.message : "Ошибка автоматизации" });
    } finally { setBusy(null); }
  }

  return (
    <div className="shell"><Sidebar active="ИИ-ассистент" /><main className="main strategy-main">
      <div className="topbar compact-topbar strategy-topbar">
        <div><div className="eyebrow">KONTENTOR Intelligence</div><h1>ИИ-стратег на неделю</h1><p className="sub">Строит контент-план из Radar, истории публикаций и данных Telegram, Instagram, VK и YouTube, а затем превращает план в готовые публикации.</p></div>
        <div className="strategy-actions"><button className="secondary" disabled={Boolean(busy)} onClick={() => void runAutomation()}>{busy === "run" ? "Готовим…" : "Подготовить публикации"}</button><button className="primary" disabled={Boolean(busy)} onClick={() => void generate()}>{busy === "strategy" ? "Анализируем…" : strategy ? "Пересобрать план" : "Сформировать план"}</button></div>
      </div>

      {notice && <div className={`notice ${notice.ok ? "ok" : "error"}`}>{notice.text}</div>}

      <section className="strategy-status-grid">
        <div className="card strategy-status"><span>Режим</span><b>{settings?.mode === "autopilot" ? "Автопилот" : "Согласование"}</b><small>{settings?.mode === "autopilot" ? "Готовые посты сразу идут в расписание" : "Перед публикацией требуется ваше подтверждение"}</small></div>
        <div className="card strategy-status"><span>Часовой пояс</span><b>{settings?.timezone || "—"}</b><small>Время контент-плана рассчитывается по этой зоне</small></div>
        <div className="card strategy-status"><span>Порог Radar</span><b>{settings?.radarMinScore ?? "—"}/100</b><small>Слабые материалы не попадают в автопилот</small></div>
        <div className="card strategy-status"><span>Лимит</span><b>{settings?.dailyLimit ?? "—"} / день</b><small>Защита от избыточной частоты публикаций</small></div>
      </section>

      {!strategy ? <section className="card strategy-empty"><div className="strategy-orbit">K</div><h2>Контент-план ещё не создан</h2><p>Сначала настройте Radar и подключите нужные соцсети. Затем KONTENTOR соберёт факты, оценит доступную аналитику и предложит недельную стратегию.</p><button className="primary" disabled={Boolean(busy)} onClick={() => void generate()}>Сформировать первую неделю</button></section> : <>
        <section className="strategy-hero card"><div><div className="eyebrow">Фокус недели · с {new Date(`${strategy.weekStart}T12:00:00Z`).toLocaleDateString("ru-RU", { day: "numeric", month: "long" })}</div><h2>{strategy.focus}</h2><p>{strategy.summary}</p></div><div className="strategy-generated">Обновлено<br/><b>{new Date(strategy.generatedAt).toLocaleString("ru-RU")}</b></div></section>

        <div className="strategy-layout">
          <section><div className="section-heading"><div><div className="eyebrow">Публикации</div><h2>Недельный контент-план</h2></div><Link className="secondary button-link compact-button" href="/calendar">Открыть очередь</Link></div><div className="strategy-posts">
            {strategy.posts.map((post, index) => <article className="card strategy-post" key={post.id}><div className="strategy-index">{String(index + 1).padStart(2, "0")}</div><div className="strategy-post-copy"><div className="strategy-meta"><span>{new Date(`${post.date}T12:00:00Z`).toLocaleDateString("ru-RU", { weekday: "short", day: "2-digit", month: "short" })} · {post.time}</span><span>{post.format}</span><span>{(post.platforms || ["telegram"]).map((p)=>p === "telegram" ? "Telegram" : p === "instagram" ? "Instagram" : p === "vk" ? "VK" : "YouTube").join(" + ")}</span>{post.sourceUrl && <a href={post.sourceUrl} target="_blank" rel="noreferrer">Источник ↗</a>}</div><h3>{post.topic}</h3><p>{post.angle}</p><small>Цель: {post.objective}</small></div><span className={`status-badge strategy-${post.status}`}>{statusLabels[post.status]}</span></article>)}
          </div></section>
          <aside className="card strategy-actions-card"><div className="eyebrow">Действия недели</div><h2>Что делать кроме публикаций</h2><div className="strategy-action-list">{strategy.actions.map((action, index) => <div key={index}><span>{index + 1}</span><p>{action}</p></div>)}</div><Link className="secondary button-link full-button" href="/settings">Настройки автопилота</Link></aside>
        </div>
      </>}
    </main></div>
  );
}
