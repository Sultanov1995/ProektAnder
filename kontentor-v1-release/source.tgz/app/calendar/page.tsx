"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Sidebar } from "@/components/Sidebar";

type Publication = {
  id: string;
  text: string;
  status: "review" | "scheduled" | "publishing" | "published" | "partial" | "failed" | "cancelled";
  createdAt: string;
  scheduledFor?: string;
  publishedAt?: string;
  channelTitle?: string;
  publicLink?: string;
  instagramPermalink?: string;
  vkPublicLink?: string; youtubePublicLink?: string;
  platforms?: Array<"telegram" | "instagram" | "vk" | "youtube">;
  deliveries?: Partial<Record<"telegram" | "instagram" | "vk" | "youtube", { status: string; error?: string; publicLink?: string }>>;
  error?: string;
  source: "manual" | "ai" | "autopilot";
  media?: { name: string; mimeType: string; size: number; kind: "photo" | "video" };
};

function platformName(p: string) { return p === "telegram" ? "Telegram" : p === "instagram" ? "Instagram" : p === "vk" ? "VK" : p === "youtube" ? "YouTube" : p; }

const statusLabel: Record<Publication["status"], string> = {
  review: "На согласовании",
  scheduled: "Запланировано",
  publishing: "Публикуется",
  published: "Опубликовано",
  partial: "Частично",
  failed: "Ошибка",
  cancelled: "Отменено",
};

export default function CalendarPage() {
  const [items, setItems] = useState<Publication[]>([]);
  const [loading, setLoading] = useState(true);
  const [queueBusy, setQueueBusy] = useState(false);
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null);

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/publications", { cache: "no-store" });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data.error || "Ошибка загрузки");
      setItems(data.publications);
    } catch (error) {
      setMessage({ ok: false, text: error instanceof Error ? error.message : "Не удалось загрузить публикации" });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  const review = useMemo(() => items.filter((item) => item.status === "review"), [items]);
  const scheduled = useMemo(() => items.filter((item) => item.status === "scheduled" || item.status === "publishing"), [items]);
  const history = useMemo(() => items.filter((item) => !["review", "scheduled", "publishing"].includes(item.status)), [items]);

  async function cancel(id: string) {
    if (!confirm("Отменить запланированную публикацию?")) return;
    const res = await fetch(`/api/publications?id=${encodeURIComponent(id)}`, { method: "DELETE" });
    const data = await res.json();
    if (!res.ok || !data.ok) {
      setMessage({ ok: false, text: data.error || "Не удалось отменить публикацию" });
      return;
    }
    setMessage({ ok: true, text: "Публикация отменена." });
    await load();
  }

  async function approve(id: string) {
    const res = await fetch("/api/publications", { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify({ id, action: "approve" }) });
    const data = await res.json();
    if (!res.ok || !data.ok) { setMessage({ ok: false, text: data.error || "Не удалось согласовать публикацию" }); return; }
    setMessage({ ok: true, text: "Публикация согласована и добавлена в расписание." });
    await load();
  }

  async function processQueue() {
    setQueueBusy(true);
    setMessage(null);
    try {
      const res = await fetch("/api/cron/publish", { method: "POST" });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data.error || "Не удалось обработать очередь");
      setMessage({ ok: true, text: data.processed ? `Обработано публикаций: ${data.processed}.` : "Публикаций, готовых к отправке, пока нет." });
      await load();
    } catch (error) {
      setMessage({ ok: false, text: error instanceof Error ? error.message : "Ошибка очереди" });
    } finally {
      setQueueBusy(false);
    }
  }

  return (
    <div className="shell">
      <Sidebar active="Календарь" />
      <main className="main">
        <div className="topbar compact-topbar">
          <div>
            <div className="eyebrow">Планирование</div>
            <h1>Календарь и история</h1>
            <p className="sub">Единый календарь Telegram + Instagram + VK + YouTube: согласование, расписание, статусы доставки и история в одном журнале.</p>
          </div>
          <Link className="primary button-link" href="/create">+ Создать публикацию</Link>
        </div>

        {message && <div className={`notice ${message.ok ? "ok" : "error"}`}>{message.text}</div>}

        <section className="calendar-summary">
          <div className="card mini-stat"><span>На согласовании</span><b>{review.length}</b></div>
          <div className="card mini-stat"><span>В очереди</span><b>{scheduled.length}</b></div>
          <div className="card mini-stat"><span>Опубликовано</span><b>{items.filter((i) => i.status === "published").length}</b></div>
          <div className="card mini-stat"><span>Ошибки</span><b>{items.filter((i) => i.status === "failed").length}</b></div>
          <button className="card queue-button" type="button" disabled={queueBusy} onClick={() => void processQueue()}>
            <span>Тест очереди</span><b>{queueBusy ? "Обработка…" : "Запустить сейчас"}</b>
          </button>
        </section>

        <section className="calendar-section">
          <div className="section-heading"><div><div className="eyebrow">Согласование</div><h2>Черновики от ИИ-стратега</h2></div><span className="label">Ручное подтверждение</span></div>
          <div className="publication-list">
            {review.length === 0 && <div className="card empty-state">Публикаций на согласовании нет.</div>}
            {review.map((item) => (
              <article className="card publication-row review-row" key={item.id}>
                <div className="publication-time"><b>{item.scheduledFor ? new Date(item.scheduledFor).toLocaleDateString("ru-RU", { day: "2-digit", month: "short" }) : "—"}</b><span>{item.scheduledFor ? new Date(item.scheduledFor).toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" }) : ""}</span></div>
                <div className="publication-copy"><div className="publication-meta"><span className="status-badge strategy-review">На согласовании</span><span>{(item.platforms || ["telegram"]).map(platformName).join(" + ")}</span><span>✦ ИИ-стратег</span></div><p>{item.text}</p></div>
                <div className="review-actions"><button className="primary compact-button" type="button" onClick={() => void approve(item.id)}>Согласовать</button><button className="danger compact-button" type="button" onClick={() => void cancel(item.id)}>Отклонить</button></div>
              </article>
            ))}
          </div>
        </section>

        <section className="calendar-section">
          <div className="section-heading">
            <div><div className="eyebrow">Очередь</div><h2>Запланированные публикации</h2></div>
            <span className="label">Серверная очередь</span>
          </div>

          <div className="publication-list">
            {loading && <div className="card empty-state">Загрузка…</div>}
            {!loading && scheduled.length === 0 && (
              <div className="card empty-state">Пока ничего не запланировано. <Link href="/create">Создать публикацию →</Link></div>
            )}
            {scheduled.map((item) => (
              <article className="card publication-row" key={item.id}>
                <div className="publication-time">
                  <b>{item.scheduledFor ? new Date(item.scheduledFor).toLocaleDateString("ru-RU", { day: "2-digit", month: "short" }) : "—"}</b>
                  <span>{item.scheduledFor ? new Date(item.scheduledFor).toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" }) : ""}</span>
                </div>
                <div className="publication-copy">
                  <div className="publication-meta">
                    <span className={`status-badge status-${item.status}`}>{statusLabel[item.status]}</span>
                    <span>{(item.platforms || ["telegram"]).map(platformName).join(" + ")}</span>
                    {item.media && <span>{item.media.kind === "photo" ? "Фото" : "Видео"}: {item.media.name}</span>}
                    {item.source !== "manual" && <span>✦ {item.source === "autopilot" ? "ИИ-стратег" : "ИИ"}</span>}
                  </div>
                  <p>{item.text}</p>
                </div>
                {item.status === "scheduled" && <button className="danger compact-button" type="button" onClick={() => void cancel(item.id)}>Отменить</button>}
              </article>
            ))}
          </div>
        </section>

        <section className="calendar-section">
          <div className="section-heading">
            <div><div className="eyebrow">Журнал</div><h2>История отправок</h2></div>
            <span className="label">Последние сначала</span>
          </div>
          <div className="publication-list">
            {!loading && history.length === 0 && <div className="card empty-state">История пока пустая.</div>}
            {history.map((item) => (
              <article className="card publication-row history-row" key={item.id}>
                <div className="publication-time">
                  <b>{new Date(item.publishedAt || item.createdAt).toLocaleDateString("ru-RU", { day: "2-digit", month: "short" })}</b>
                  <span>{new Date(item.publishedAt || item.createdAt).toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" })}</span>
                </div>
                <div className="publication-copy">
                  <div className="publication-meta">
                    <span className={`status-badge status-${item.status}`}>{statusLabel[item.status]}</span>
                    <span>{(item.platforms || ["telegram"]).map(platformName).join(" + ")}</span>
                    {item.source !== "manual" && <span>✦ {item.source === "autopilot" ? "ИИ-стратег" : "ИИ"}</span>}
                  </div>
                  <p>{item.text}</p>
                  {item.deliveries && <div className="delivery-list">{Object.entries(item.deliveries).map(([platform, delivery]) => <span key={platform} className={`delivery-badge delivery-${delivery.status}`}>{platformName(platform)}: {delivery.status === "published" ? "опубликовано" : delivery.status === "failed" ? "ошибка" : delivery.status}</span>)}</div>}
                  {item.error && <div className="publication-error">{item.error}</div>}
                </div>
                <div className="history-links">{item.publicLink && <a className="secondary button-link compact-button" href={item.publicLink} target="_blank" rel="noreferrer">Telegram ↗</a>}{item.instagramPermalink && <a className="secondary button-link compact-button" href={item.instagramPermalink} target="_blank" rel="noreferrer">Instagram ↗</a>}{item.vkPublicLink && <a className="secondary button-link compact-button" href={item.vkPublicLink} target="_blank" rel="noreferrer">VK ↗</a>}{item.youtubePublicLink && <a className="secondary button-link compact-button" href={item.youtubePublicLink} target="_blank" rel="noreferrer">YouTube ↗</a>}</div>
              </article>
            ))}
          </div>
        </section>

        <div className="card cron-note">
          <div className="eyebrow">Production</div>
          <h2>Автоматическая отправка</h2>
          <p className="sub">В production внешний cron должен вызывать <code>/api/cron/publish</code> с заголовком <code>Authorization: Bearer CRON_SECRET</code>. Кнопка «Запустить сейчас» предназначена для локальной проверки и в production без секрета будет закрыта.</p>
        </div>
      </main>
    </div>
  );
}
