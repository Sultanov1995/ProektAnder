"use client";

import Link from "next/link";
import { FormEvent, useEffect, useState } from "react";
import { Sidebar } from "@/components/Sidebar";

type Settings = {
  mode: "review" | "autopilot"; timezone: string; preferredTimes: string[]; dailyLimit: number; radarMinScore: number;
  allowWeekend: boolean; autoGenerateWeeklyPlan: boolean; autoCreateDrafts: boolean;
};
type MtprotoState = { configured: boolean; connected: boolean; channel?: { title: string }; latest?: { capturedAt: string } | null };

export default function SettingsPage() {
  const [settings, setSettings] = useState<Settings | null>(null);
  const [times, setTimes] = useState("");
  const [mtproto, setMtproto] = useState<MtprotoState | null>(null);
  const [busy, setBusy] = useState(false);
  const [mtBusy, setMtBusy] = useState(false);
  const [notice, setNotice] = useState<{ ok: boolean; text: string } | null>(null);

  async function load() {
    const [a, m] = await Promise.all([fetch("/api/automation/settings", { cache: "no-store" }), fetch("/api/mtproto/stats", { cache: "no-store" })]);
    const [aj, mj] = await Promise.all([a.json(), m.json()]);
    if (aj.ok) { setSettings(aj.settings); setTimes(aj.settings.preferredTimes.join(", ")); }
    if (mj.ok) setMtproto(mj);
  }
  useEffect(() => { void load(); }, []);

  async function save(event: FormEvent) {
    event.preventDefault(); if (!settings) return; setBusy(true); setNotice(null);
    try {
      const payload = { ...settings, preferredTimes: times.split(/[,;\n]+/).map((v) => v.trim()).filter(Boolean) };
      const res = await fetch("/api/automation/settings", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(payload) });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data.error || "Не удалось сохранить настройки");
      setSettings(data.settings); setTimes(data.settings.preferredTimes.join(", "));
      setNotice({ ok: true, text: "Настройки автоматизации сохранены." });
    } catch (error) { setNotice({ ok: false, text: error instanceof Error ? error.message : "Ошибка сохранения" }); }
    finally { setBusy(false); }
  }

  async function updateMtproto() {
    setMtBusy(true); setNotice(null);
    try {
      const res = await fetch("/api/mtproto/stats", { method: "POST" }); const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data.error || "Не удалось получить статистику");
      setNotice({ ok: true, text: "Расширенная Telegram-статистика обновлена." }); await load();
    } catch (error) { setNotice({ ok: false, text: error instanceof Error ? error.message : "Ошибка MTProto" }); }
    finally { setMtBusy(false); }
  }

  return <div className="shell"><Sidebar active="Настройки"/><main className="main settings-main">
    <div className="topbar compact-topbar"><div><div className="eyebrow">Управление</div><h1>Настройки KONTENTOR</h1><p className="sub">Режим автоматизации, защитные лимиты и расширенная Telegram Analytics.</p></div></div>
    {notice && <div className={`notice ${notice.ok ? "ok" : "error"}`}>{notice.text}</div>}
    <div className="settings-grid">
      <form className="card automation-card" onSubmit={save}>
        <div className="section-heading"><div><div className="eyebrow">Публикации</div><h2>Уровень автоматизации</h2></div><span className={`mode-pill ${settings?.mode === "autopilot" ? "auto" : "review"}`}>{settings?.mode === "autopilot" ? "AUTOPILOT" : "REVIEW"}</span></div>
        {!settings ? <p className="sub">Загрузка…</p> : <>
          <div className="mode-selector"><button type="button" className={settings.mode === "review" ? "selected" : ""} onClick={() => setSettings({ ...settings, mode: "review" })}><b>Согласование</b><span>ИИ готовит контент, но публикация требует вашего подтверждения.</span></button><button type="button" className={settings.mode === "autopilot" ? "selected" : ""} onClick={() => setSettings({ ...settings, mode: "autopilot" })}><b>Автопилот</b><span>Одобренный правилами контент сразу попадает в расписание.</span></button></div>
          <div className="settings-fields"><label><span>Часовой пояс</span><input value={settings.timezone} onChange={(e) => setSettings({ ...settings, timezone: e.target.value })}/><small>Например: Europe/Moscow, Europe/Kaliningrad, Asia/Yekaterinburg.</small></label><label><span>Предпочтительное время</span><input value={times} onChange={(e) => setTimes(e.target.value)} placeholder="10:00, 19:00"/><small>До 6 значений через запятую.</small></label><label><span>Максимум публикаций в день</span><input type="number" min={1} max={5} value={settings.dailyLimit} onChange={(e) => setSettings({ ...settings, dailyLimit: Number(e.target.value) })}/></label><label><span>Минимальный Radar Score</span><input type="number" min={50} max={100} value={settings.radarMinScore} onChange={(e) => setSettings({ ...settings, radarMinScore: Number(e.target.value) })}/></label></div>
          <div className="toggle-list"><label><input type="checkbox" checked={settings.allowWeekend} onChange={(e) => setSettings({ ...settings, allowWeekend: e.target.checked })}/><span><b>Публикации в выходные</b><small>Разрешить субботу и воскресенье в недельном плане.</small></span></label><label><input type="checkbox" checked={settings.autoGenerateWeeklyPlan} onChange={(e) => setSettings({ ...settings, autoGenerateWeeklyPlan: e.target.checked })}/><span><b>Автоматически создавать недельный план</b><small>Если новый недельный план ещё не создан, cron сможет сформировать его самостоятельно.</small></span></label><label><input type="checkbox" checked={settings.autoCreateDrafts} onChange={(e) => setSettings({ ...settings, autoCreateDrafts: e.target.checked })}/><span><b>Автоматически создавать тексты</b><small>Превращать пункты плана в готовые Telegram-публикации.</small></span></label></div>
          {settings.mode === "autopilot" && <div className="autopilot-warning"><b>Полный автопилот включён</b><p>KONTENTOR сможет ставить сгенерированные публикации в расписание без ручного подтверждения. Порог Radar и дневной лимит остаются обязательными.</p></div>}
          <button className="primary full-button" disabled={busy}>{busy ? "Сохраняем…" : "Сохранить настройки"}</button>
        </>}
      </form>

      <section className="card account-management-card"><div className="eyebrow">АККАУНТ И КОМАНДА</div><h2>Управление пространством</h2><p className="sub">Проекты, роли участников и тариф находятся отдельно от настроек публикаций.</p><div className="management-links"><Link href="/workspaces"><b>Рабочие пространства</b><span>Создать или переключить проект</span>→</Link><Link href="/team"><b>Команда и роли</b><span>Owner · Admin · Editor · Analyst</span>→</Link><Link href="/billing"><b>Тариф и лимиты</b><span>Start · Pro · Team</span>→</Link></div></section>
      <section className="card mtproto-card"><div className="section-heading"><div><div className="eyebrow">Telegram MTProto</div><h2>Расширенная аналитика</h2></div><span className={`connection-pill ${mtproto?.configured ? "connected" : ""}`}>{mtproto?.configured ? "Настроено" : "Не настроено"}</span></div>
        <p className="sub">Пользовательская сессия администратора нужна только для чтения статистики канала: просмотров, пересылок, реакций и графиков Telegram.</p>
        <div className="mtproto-steps"><div><span>1</span><p>Получите <code>api_id</code> и <code>api_hash</code> в <b>my.telegram.org → API development tools</b>.</p></div><div><span>2</span><p>Добавьте <code>TELEGRAM_API_ID</code> и <code>TELEGRAM_API_HASH</code> в <code>.env</code>.</p></div><div><span>3</span><p>В терминале выполните <code>npm run telegram:session</code> и сохраните выданную строку как <code>TELEGRAM_MT_SESSION</code>.</p></div></div>
        <div className="security-note"><b>Важно</b><p>Строка MTProto-сессии эквивалентна длительному входу в Telegram. Не храните её в Git, не отправляйте в чат и используйте secret manager в production.</p></div>
        <button className="secondary full-button" type="button" disabled={mtBusy || !mtproto?.configured} onClick={() => void updateMtproto()}>{mtBusy ? "Получаем статистику…" : "Проверить и обновить статистику"}</button>
        {mtproto?.latest?.capturedAt && <small className="mt-last">Последний расширенный замер: {new Date(mtproto.latest.capturedAt).toLocaleString("ru-RU")}</small>}
      </section>
    </div>
  </main></div>;
}
