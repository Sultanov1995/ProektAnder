import { ComingSoon } from "@/components/ComingSoon";
export default function Page(){return <ComingSoon active="Продвижение" title="Продвижение" description="Рекламные гипотезы, UTM, рекомендации по креативам и росту будут собраны здесь."/>}
