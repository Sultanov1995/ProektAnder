"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { Sidebar } from "@/components/Sidebar";
import { SocialAnalysisPanel } from "@/components/SocialAnalysisPanel";

type Connection = { userId: string; username: string; accountType?: string; connectedAt: string; expiresAt?: string };

export default function InstagramPage() {
  const [connection, setConnection] = useState<Connection | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null);

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/instagram/connection", { cache: "no-store" });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data.error || "Не удалось проверить Instagram");
      setConnection(data.connection);
    } catch (error) {
      setMessage({ ok: false, text: error instanceof Error ? error.message : "Ошибка подключения" });
    } finally { setLoading(false); }
  }, []);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("connected") === "1") setMessage({ ok: true, text: "Instagram Professional успешно подключён к KONTENTOR." });
    const error = params.get("error");
    if (error) setMessage({ ok: false, text: error });
    void load();
  }, [load]);

  async function disconnect() {
    if (!confirm("Отключить Instagram от KONTENTOR?")) return;
    setBusy(true);
    const res = await fetch("/api/instagram/connection", { method: "DELETE" });
    const data = await res.json();
    setBusy(false);
    if (!res.ok || !data.ok) return setMessage({ ok: false, text: data.error || "Не удалось отключить Instagram" });
    setConnection(null);
    setMessage({ ok: true, text: "Instagram отключён. Токен удалён из KONTENTOR." });
  }

  return (
    <div className="shell">
      <Sidebar active="Соцсети" />
      <main className="main socials-main">
        <div className="topbar compact-topbar"><div><div className="eyebrow">Соцсети / Instagram</div><h1>Instagram Professional</h1><p className="sub">Подключение через официальный Meta OAuth. KONTENTOR не получает и не хранит пароль Instagram.</p></div><Link className="secondary button-link" href="/socials">Все соцсети</Link></div>
        {message && <div className={`notice ${message.ok ? "ok" : "error"}`}>{message.text}</div>}

        <section className="integration-layout">
          <div className="card integration-card">
            <div className="integration-icon instagram">◎</div>
            <div><div className="eyebrow">Статус</div><h2>{loading ? "Проверяем…" : connection ? `@${connection.username}` : "Instagram не подключён"}</h2>
              <p className="sub">Поддерживаются профессиональные аккаунты Instagram, которым Meta разрешает Content Publishing API.</p></div>
            {connection ? (
              <div className="integration-details">
                <div><span>Аккаунт</span><b>@{connection.username}</b></div>
                <div><span>Тип</span><b>{connection.accountType || "Professional"}</b></div>
                <div><span>Подключён</span><b>{new Date(connection.connectedAt).toLocaleDateString("ru-RU")}</b></div>
                <div><span>Токен</span><b>{connection.expiresAt ? `до ${new Date(connection.expiresAt).toLocaleDateString("ru-RU")}` : "активен"}</b></div>
              </div>
            ) : null}
            <div className="integration-actions">
              {connection ? <><Link href="/create" className="primary button-link">Создать публикацию</Link><button className="danger" disabled={busy} onClick={() => void disconnect()}>{busy ? "Отключаем…" : "Отключить"}</button></> : <a className="primary button-link" href="/api/instagram/oauth/start">Подключить Instagram</a>}
            </div>
          </div>

          <div className="card integration-help">
            <div className="eyebrow">Что потребуется</div><h2>Настройка Meta App</h2>
            <ol><li>Создать приложение в Meta for Developers и добавить Instagram API.</li><li>Указать callback URL KONTENTOR из <code>INSTAGRAM_REDIRECT_URI</code>.</li><li>Включить разрешения для базового профиля, публикации контента и Insights.</li><li>Аккаунт Instagram должен быть профессиональным и доступным приложению.</li></ol>
            <div className="integration-note"><b>Важно для публикации</b><p>Meta забирает фото или видео по HTTPS. Поэтому production KONTENTOR должен иметь публичный <code>PUBLIC_APP_URL</code>. Локальный <code>localhost</code> для реальной публикации Instagram не подойдёт.</p></div>
          </div>
        </section>
        <SocialAnalysisPanel network="instagram" connected={Boolean(connection)} accountLabel={connection ? `@${connection.username}` : undefined} />
      </main>
    </div>
  );
}
