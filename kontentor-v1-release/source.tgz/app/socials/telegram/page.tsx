"use client";

import Link from "next/link";
import { ChangeEvent, FormEvent, useCallback, useEffect, useState } from "react";
import { Sidebar } from "@/components/Sidebar";
import { SocialAnalysisPanel } from "@/components/SocialAnalysisPanel";

type Connection = {
  botId: number;
  botUsername: string;
  botName: string;
  channelId: string;
  channelTitle: string;
  channelUsername?: string;
  connectedAt: string;
};

export default function TelegramPage() {
  const [connection, setConnection] = useState<Connection | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [token, setToken] = useState("");
  const [channel, setChannel] = useState("");
  const [message, setMessage] = useState<{ type: "ok" | "error"; text: string } | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/telegram/connection", { cache: "no-store" });
      const data = await res.json();
      if (data.ok) setConnection(data.connection);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  async function connect(event: FormEvent) {
    event.preventDefault();
    setSaving(true);
    setMessage(null);
    try {
      const res = await fetch("/api/telegram/connection", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ token, channel }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data.error || "Не удалось подключить Telegram");
      setConnection(data.connection);
      setToken("");
      setMessage({ type: "ok", text: "Telegram-канал успешно подключён к KONTENTOR." });
    } catch (error) {
      setMessage({ type: "error", text: error instanceof Error ? error.message : "Ошибка подключения" });
    } finally {
      setSaving(false);
    }
  }

  async function disconnect() {
    if (!confirm("Отключить Telegram-канал от KONTENTOR?")) return;
    const res = await fetch("/api/telegram/connection", { method: "DELETE" });
    const data = await res.json();
    if (data.ok) {
      setConnection(null);
      setMessage({ type: "ok", text: "Telegram отключён. Зашифрованный токен удалён." });
    } else {
      setMessage({ type: "error", text: data.error || "Не удалось отключить Telegram" });
    }
  }

  return (
    <div className="shell">
      <Sidebar active="Соцсети" />
      <main className="main">
        <div className="topbar compact-topbar">
          <div>
            <div className="eyebrow">Соцсети / Telegram</div>
            <h1>Подключите Telegram-канал</h1>
            <p className="sub">KONTENTOR проверит бота, его права администратора и доступ к каналу. После подключения можно публиковать посты прямо из панели.</p>
          </div>
          <span className={`connection-pill ${connection ? "connected" : ""}`}>
            <span className="pulse-dot" /> {loading ? "Проверяем…" : connection ? "Подключено" : "Не подключено"}
          </span>
        </div>

        {message && <div className={`notice ${message.type}`}>{message.text}</div>}

        {connection ? (
          <section className="telegram-layout">
            <div className="card connection-detail">
              <div className="telegram-badge">✈</div>
              <div>
                <div className="eyebrow">Активный канал</div>
                <h2>{connection.channelTitle}</h2>
                <p className="sub">{connection.channelUsername ? `@${connection.channelUsername}` : `ID ${connection.channelId}`}</p>
              </div>
              <div className="connection-meta">
                <span>Бот</span><b>@{connection.botUsername || connection.botName}</b>
                <span>Подключён</span><b>{new Date(connection.connectedAt).toLocaleString("ru-RU")}</b>
              </div>
              <div className="btns">
                <Link className="primary button-link" href="/create">Создать пост</Link>
                <button className="danger" onClick={disconnect}>Отключить</button>
              </div>
            </div>

            <div className="card security-card">
              <div className="eyebrow">Безопасность</div>
              <h2>Токен не показывается в интерфейсе</h2>
              <p className="sub">После проверки токен сохраняется на сервере в зашифрованном виде AES‑256‑GCM. Для production необходимо задать собственный <code>APP_ENCRYPTION_KEY</code> и использовать HTTPS.</p>
              <div className="security-row"><span>Проверка Bot API</span><b>✓</b></div>
              <div className="security-row"><span>Проверка канала</span><b>✓</b></div>
              <div className="security-row"><span>Право публикации</span><b>✓</b></div>
            </div>
          </section>
        ) : (
          <section className="telegram-layout">
            <form className="card connect-form" onSubmit={connect}>
              <div className="eyebrow">Шаг 1</div>
              <h2>Данные Telegram-бота</h2>
              <label>
                <span>Токен бота от @BotFather</span>
                <input
                  required
                  type="password"
                  autoComplete="off"
                  placeholder="123456789:AA…"
                  value={token}
                  onChange={(e: ChangeEvent<HTMLInputElement>) => setToken(e.target.value)}
                />
              </label>
              <label>
                <span>Канал</span>
                <input
                  required
                  placeholder="@my_channel или -1001234567890"
                  value={channel}
                  onChange={(e: ChangeEvent<HTMLInputElement>) => setChannel(e.target.value)}
                />
              </label>
              <button className="primary full-button" type="submit" disabled={saving}>
                {saving ? "Проверяем подключение…" : "Проверить и подключить"}
              </button>
              <p className="microcopy">KONTENTOR не выводит токен обратно после сохранения.</p>
            </form>

            <div className="card setup-guide">
              <div className="eyebrow">Подготовка Telegram</div>
              <h2>Что нужно сделать</h2>
              <ol className="steps">
                <li><span>1</span><div><b>Создайте бота</b><p>Откройте @BotFather → /newbot → получите токен.</p></div></li>
                <li><span>2</span><div><b>Добавьте бота в канал</b><p>Настройки канала → Администраторы → Добавить администратора.</p></div></li>
                <li><span>3</span><div><b>Разрешите публикацию</b><p>У бота должно быть право «Публиковать сообщения».</p></div></li>
                <li><span>4</span><div><b>Введите канал</b><p>Для публичного канала — @username. Для приватного — числовой chat ID.</p></div></li>
              </ol>
            </div>
          </section>
        )}
      <SocialAnalysisPanel network="telegram" connected={Boolean(connection)} accountLabel={connection ? (connection.channelUsername ? `@${connection.channelUsername}` : connection.channelTitle) : undefined} />
      </main>
    </div>
  );
}
