"use client";
import Link from "next/link";
import { useEffect,useMemo,useState } from "react";
import { Sidebar } from "@/components/Sidebar";

type Platform="telegram"|"instagram"|"vk"|"youtube";
type Item={id:string;text:string;status:string;createdAt:string;scheduledFor?:string;publishedAt?:string;platforms?:Platform[];source?:string;error?:string;media?:{name:string;kind:string;mimeType:string};deliveries?:Partial<Record<Platform,{status:string;publicLink?:string;error?:string}>>};
const labels:Record<string,string>={review:"На согласовании",scheduled:"Запланировано",publishing:"Публикуется",published:"Опубликовано",partial:"Частично",failed:"Ошибка",cancelled:"Отменено"};
const platformLabel=(p:Platform)=>p==="telegram"?"Telegram":p==="instagram"?"Instagram":p==="vk"?"VK":"YouTube";
export default function ContentPage(){
 const[items,setItems]=useState<Item[]>([]),[loading,setLoading]=useState(true),[filter,setFilter]=useState("all");
 async function load(){setLoading(true);try{const r=await fetch("/api/publications",{cache:"no-store"}),d=await r.json();if(d.ok)setItems(d.publications||[])}finally{setLoading(false)}}
 useEffect(()=>{void load()},[]);
 const filtered=useMemo(()=>filter==="all"?items:items.filter(x=>x.status===filter),[items,filter]);
 const counts=useMemo(()=>({all:items.length,review:items.filter(x=>x.status==="review").length,scheduled:items.filter(x=>x.status==="scheduled").length,published:items.filter(x=>x.status==="published"||x.status==="partial").length}),[items]);
 return <div className="shell"><Sidebar active="Контент"/><main className="main content-main">
  <div className="topbar compact-topbar"><div><div className="eyebrow">КОНТЕНТ</div><h1>Библиотека публикаций</h1><p className="sub">Все материалы KONTENTOR: черновики на согласовании, расписание, опубликованные записи и ошибки доставки.</p></div><Link className="primary button-link" href="/create">+ Создать публикацию</Link></div>
  <section className="content-summary"><button className={filter==="all"?"active":""} onClick={()=>setFilter("all")}><span>Все</span><b>{counts.all}</b></button><button className={filter==="review"?"active":""} onClick={()=>setFilter("review")}><span>Согласование</span><b>{counts.review}</b></button><button className={filter==="scheduled"?"active":""} onClick={()=>setFilter("scheduled")}><span>В расписании</span><b>{counts.scheduled}</b></button><button className={filter==="published"?"active":""} onClick={()=>setFilter("published")}><span>Опубликовано</span><b>{counts.published}</b></button></section>
  <section className="content-list">{loading?<div className="card content-empty">Загрузка библиотеки…</div>:!filtered.length?<div className="card content-empty"><b>Здесь пока пусто</b><p>Создайте первую публикацию или запустите ИИ-стратега.</p><Link href="/create" className="primary button-link">Создать материал</Link></div>:filtered.map(item=><article className="card content-row" key={item.id}><div className="content-status"><span className={`status-badge status-${item.status}`}>{labels[item.status]||item.status}</span><small>{new Date(item.publishedAt||item.scheduledFor||item.createdAt).toLocaleString("ru-RU")}</small></div><div className="content-body"><div className="content-platforms">{(item.platforms?.length?item.platforms:["telegram"]).map(p=><span key={p}>{platformLabel(p as Platform)}</span>)}{item.media&&<span>{item.media.kind==="video"?"Видео":"Фото"}</span>}<span>{item.source==="autopilot"?"Автопилот":item.source==="ai"?"ИИ":"Вручную"}</span></div><p>{item.text}</p>{item.error&&<div className="content-error">{item.error}</div>}</div><div className="content-delivery">{Object.entries(item.deliveries||{}).map(([p,d])=><div key={p}><i className={d?.status==="published"?"ok":d?.status==="failed"?"bad":""}/><span>{platformLabel(p as Platform)}</span>{d?.publicLink?<a href={d.publicLink} target="_blank" rel="noreferrer">Открыть ↗</a>:<small>{d?.status||"pending"}</small>}</div>)}</div></article>)}</section>
 </main></div>;
}
