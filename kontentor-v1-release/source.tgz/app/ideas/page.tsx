import { ComingSoon } from "@/components/ComingSoon";
export default function Page(){return <ComingSoon active="Идеи" title="Банк идей" description="Здесь будут храниться найденные темы, оценки ИИ, источники и идеи для будущих публикаций."/>}
