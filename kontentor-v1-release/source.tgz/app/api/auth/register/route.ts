import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { hashPassword } from "@/lib/password";
import { createSessionToken, SESSION_COOKIE } from "@/lib/session-token";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function slugify(value: string) {
  const base = value.toLowerCase().replace(/[^a-z0-9а-яё]+/gi,"-").replace(/^-|-$/g,"").slice(0,40) || "workspace";
  return `${base}-${Math.random().toString(36).slice(2,7)}`;
}
function setSession(response: NextResponse, token: string) {
  response.cookies.set(SESSION_COOKIE, token, { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", path: "/", maxAge: 60*60*24*30 });
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const email = String(body.email || "").trim().toLowerCase();
    const name = String(body.name || "").trim().slice(0,80);
    const password = String(body.password || "");
    if (!/^\S+@\S+\.\S+$/.test(email)) return NextResponse.json({ok:false,error:"Введите корректный email."},{status:400});
    if (name.length < 2) return NextResponse.json({ok:false,error:"Укажите имя."},{status:400});
    if (password.length < 8) return NextResponse.json({ok:false,error:"Пароль должен содержать минимум 8 символов."},{status:400});
    if (await db.user.findUnique({where:{email},select:{id:true}})) return NextResponse.json({ok:false,error:"Аккаунт с таким email уже существует."},{status:409});

    const created = await db.$transaction(async (tx) => {
      const user = await tx.user.create({ data: { email, name, passwordHash: hashPassword(password), lastLoginAt: new Date() } });
      const workspace = await tx.workspace.create({ data: { name: `${name} — проект`, slug: slugify(name), members: { create: { userId: user.id, role: "owner" } }, subscriptions: { create: { plan: "start", status: "trial", trialEndsAt: new Date(Date.now()+14*86400000) } } } });
      return { user, workspace };
    });
    const token = createSessionToken({userId:created.user.id,workspaceId:created.workspace.id,role:"owner"});
    const response = NextResponse.json({ok:true,user:{id:created.user.id,email:created.user.email,name:created.user.name},workspace:{id:created.workspace.id,name:created.workspace.name}});
    setSession(response,token);
    return response;
  } catch (error) {
    console.error("register",error);
    return NextResponse.json({ok:false,error:"Не удалось создать аккаунт."},{status:500});
  }
}
