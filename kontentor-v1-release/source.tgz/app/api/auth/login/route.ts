import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { hashPassword, verifyPassword } from "@/lib/password";
import { createSessionToken, SESSION_COOKIE } from "@/lib/session-token";
import { clearRateLimit, clientIp, hitRateLimit } from "@/lib/auth-rate-limit";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// Ensures unknown-email attempts still pay roughly the same scrypt cost.
const DUMMY_HASH = hashPassword("kontentor-dummy-password-for-timing");

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const email = String(body.email || "").trim().toLowerCase();
    const password = String(body.password || "");
    if (!/^\S+@\S+\.\S+$/.test(email) || password.length < 1 || password.length > 256) {
      return NextResponse.json({ ok: false, error: "Неверный email или пароль." }, { status: 401 });
    }

    const ip = clientIp(request);
    const [byIp, byEmail] = await Promise.all([
      hitRateLimit({ scope: "login-ip", subject: ip, limit: 30, windowMs: 15 * 60_000, blockMs: 15 * 60_000 }),
      hitRateLimit({ scope: "login-email", subject: email, limit: 8, windowMs: 15 * 60_000, blockMs: 15 * 60_000 }),
    ]);
    const limited = !byIp.allowed ? byIp : !byEmail.allowed ? byEmail : null;
    if (limited && !limited.allowed) {
      return NextResponse.json(
        { ok: false, error: "Слишком много попыток входа. Попробуйте позже." },
        { status: 429, headers: { "retry-after": String(limited.retryAfter), "cache-control": "no-store" } },
      );
    }

    const user = await db.user.findUnique({
      where: { email },
      include: { workspaces: { include: { workspace: true }, orderBy: { createdAt: "asc" } } },
    });
    const valid = verifyPassword(password, user?.passwordHash || DUMMY_HASH);
    if (!user || !valid) return NextResponse.json({ ok: false, error: "Неверный email или пароль." }, { status: 401 });

    const member = user.workspaces[0];
    if (!member) return NextResponse.json({ ok: false, error: "Для аккаунта не найдено рабочее пространство." }, { status: 403 });

    await Promise.all([
      db.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } }),
      clearRateLimit("login-email", email),
    ]);

    const response = NextResponse.json({
      ok: true,
      user: { id: user.id, email: user.email, name: user.name, onboardingComplete: Boolean(user.onboardingCompletedAt) },
      workspace: { id: member.workspace.id, name: member.workspace.name },
      role: member.role,
    });
    response.cookies.set(SESSION_COOKIE, createSessionToken({ userId: user.id, workspaceId: member.workspaceId, role: member.role }), {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      maxAge: 60 * 60 * 24 * 30,
    });
    response.headers.set("cache-control", "no-store");
    return response;
  } catch (error) {
    console.error("login", error);
    return NextResponse.json({ ok: false, error: "Не удалось выполнить вход." }, { status: 500 });
  }
}
