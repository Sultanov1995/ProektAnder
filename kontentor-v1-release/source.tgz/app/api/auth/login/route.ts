import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { verifyPassword } from "@/lib/password";
import { createSessionToken, SESSION_COOKIE } from "@/lib/session-token";

export const runtime="nodejs";export const dynamic="force-dynamic";
export async function POST(request:Request){
 try{
  const body=await request.json();const email=String(body.email||"").trim().toLowerCase(),password=String(body.password||"");
  const user=await db.user.findUnique({where:{email},include:{workspaces:{include:{workspace:true},orderBy:{createdAt:"asc"}}}});
  if(!user||!verifyPassword(password,user.passwordHash))return NextResponse.json({ok:false,error:"Неверный email или пароль."},{status:401});
  const member=user.workspaces[0];if(!member)return NextResponse.json({ok:false,error:"Для аккаунта не найдено рабочее пространство."},{status:403});
  await db.user.update({where:{id:user.id},data:{lastLoginAt:new Date()}});
  const response=NextResponse.json({ok:true,user:{id:user.id,email:user.email,name:user.name,onboardingComplete:Boolean(user.onboardingCompletedAt)},workspace:{id:member.workspace.id,name:member.workspace.name},role:member.role});
  response.cookies.set(SESSION_COOKIE,createSessionToken({userId:user.id,workspaceId:member.workspaceId,role:member.role}),{httpOnly:true,secure:process.env.NODE_ENV==="production",sameSite:"lax",path:"/",maxAge:60*60*24*30});
  return response;
 }catch(error){console.error("login",error);return NextResponse.json({ok:false,error:"Не удалось выполнить вход."},{status:500})}
}
