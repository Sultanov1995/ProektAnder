import { exchangeInstagramCode } from "@/lib/instagram";
import { requireSession } from "@/lib/auth";

export const runtime = "nodejs";

function cookieValue(header: string | null, name: string) {
  if (!header) return "";
  const found = header.split(";").map((part) => part.trim()).find((part) => part.startsWith(`${name}=`));
  return found ? decodeURIComponent(found.slice(name.length + 1)) : "";
}

export async function GET(request: Request) {
  const url = new URL(request.url);
  const base = (process.env.PUBLIC_APP_URL || process.env.APP_URL)?.replace(/\/$/, "") || `${url.protocol}//${url.host}`;
  try {
    await requireSession();
    const code = url.searchParams.get("code");
    const state = url.searchParams.get("state");
    const expected = cookieValue(request.headers.get("cookie"), "kontentor_ig_state");
    const oauthError = url.searchParams.get("error_description") || url.searchParams.get("error");
    if (oauthError) throw new Error(oauthError);
    if (!code || !state || !expected || state !== expected) throw new Error("Не удалось проверить OAuth state. Повторите подключение.");
    await exchangeInstagramCode(code);
    const response = Response.redirect(`${base}/socials/instagram?connected=1`, 302);
    response.headers.append("set-cookie", `kontentor_ig_state=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${process.env.NODE_ENV === "production" ? "; Secure" : ""}`);
    return response;
  } catch (error) {
    const message = encodeURIComponent(error instanceof Error ? error.message : "Не удалось подключить Instagram");
    return Response.redirect(`${base}/socials/instagram?error=${message}`, 302);
  }
}
