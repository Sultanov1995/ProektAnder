import { randomBytes } from "crypto";
import { buildInstagramAuthUrl } from "@/lib/instagram";
import { requireSession } from "@/lib/auth";

export const runtime = "nodejs";

export async function GET() {
  try {
    await requireSession();
    const state = randomBytes(24).toString("base64url");
    const response = Response.redirect(buildInstagramAuthUrl(state), 302);
    response.headers.append("set-cookie", `kontentor_ig_state=${state}; Path=/; HttpOnly; SameSite=Lax; Max-Age=600${process.env.NODE_ENV === "production" ? "; Secure" : ""}`);
    return response;
  } catch (error) {
    const message = encodeURIComponent(error instanceof Error ? error.message : "Instagram OAuth не настроен");
    return Response.redirect(`${process.env.PUBLIC_APP_URL || process.env.APP_URL || "http://localhost:3000"}/socials/instagram?error=${message}`, 302);
  }
}
