import { deleteInstagramConnection, getInstagramConnection, publicInstagramConnection } from "@/lib/instagram-vault";
import { refreshInstagramToken } from "@/lib/instagram";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const connection = await getInstagramConnection();
    return Response.json({ ok: true, connection: publicInstagramConnection(connection) });
  } catch (error) {
    return Response.json({ ok: false, error: error instanceof Error ? error.message : "Не удалось прочитать подключение" }, { status: 500 });
  }
}

export async function PATCH() {
  try {
    const connection = await getInstagramConnection();
    if (!connection) return Response.json({ ok: false, error: "Instagram не подключён" }, { status: 404 });
    const refreshed = await refreshInstagramToken({ ...connection, expiresAt: new Date(Date.now() + 60_000).toISOString() });
    return Response.json({ ok: true, connection: publicInstagramConnection(refreshed) });
  } catch (error) {
    return Response.json({ ok: false, error: error instanceof Error ? error.message : "Не удалось обновить токен" }, { status: 502 });
  }
}

export async function DELETE() {
  await deleteInstagramConnection();
  return Response.json({ ok: true });
}
