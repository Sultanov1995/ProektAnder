import { z } from "zod";
import { runContentAI } from "@/lib/openai";
import { requireSession } from "@/lib/auth";

export const runtime = "nodejs";

const schema = z.object({
  action: z.enum(["generate", "improve", "shorten", "cta"]),
  text: z.string().trim().min(2, "Добавьте тему или текст для обработки").max(12000, "Слишком большой исходный текст"),
});

export async function POST(request: Request) {
  try {
    await requireSession();
    const parsed = schema.safeParse(await request.json());
    if (!parsed.success) {
      return Response.json({ ok: false, error: parsed.error.issues[0]?.message || "Проверьте текст" }, { status: 400 });
    }
    const text = await runContentAI(parsed.data.action, parsed.data.text);
    return Response.json({ ok: true, text });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Не удалось обработать текст через ИИ";
    const status = message.includes("OPENAI_API_KEY") ? 503 : 502;
    return Response.json({ ok: false, error: message }, { status });
  }
}
