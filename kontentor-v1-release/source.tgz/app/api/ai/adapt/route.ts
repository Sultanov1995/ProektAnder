import { z } from "zod";
import { createCrossPlatformVariants } from "@/lib/openai";
import { requireSession } from "@/lib/auth";

export const runtime = "nodejs";

const schema = z.object({ text: z.string().trim().min(2).max(12000) });

export async function POST(request: Request) {
  try {
    await requireSession();
    const parsed = schema.safeParse(await request.json());
    if (!parsed.success) return Response.json({ ok: false, error: "Добавьте исходный текст" }, { status: 400 });
    const variants = await createCrossPlatformVariants(parsed.data.text);
    return Response.json({ ok: true, variants });
  } catch (error) {
    return Response.json({ ok: false, error: error instanceof Error ? error.message : "Не удалось адаптировать текст" }, { status: 502 });
  }
}
