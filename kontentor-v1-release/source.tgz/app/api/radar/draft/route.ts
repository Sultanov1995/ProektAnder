import { z } from "zod";
import { createRadarDraft } from "@/lib/openai";
import { getRadarItem, updateRadarItem } from "@/lib/radar-store";

export const runtime = "nodejs";
const schema = z.object({ id: z.string().uuid() });

export async function POST(request: Request) {
  try {
    const parsed = schema.safeParse(await request.json());
    if (!parsed.success) return Response.json({ ok: false, error: "Материал не найден" }, { status: 400 });
    const item = await getRadarItem(parsed.data.id);
    if (!item) return Response.json({ ok: false, error: "Материал не найден" }, { status: 404 });
    const text = await createRadarDraft(item);
    await updateRadarItem(item.id, { status: "drafted", draftText: text });
    return Response.json({ ok: true, text });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Не удалось создать черновик";
    return Response.json({ ok: false, error: message }, { status: message.includes("OPENAI_API_KEY") ? 503 : 502 });
  }
}
