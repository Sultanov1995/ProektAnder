import { z } from "zod";
import { updateRadarItem } from "@/lib/radar-store";

const schema = z.object({ id: z.string().uuid(), status: z.enum(["new", "drafted", "skipped"]) });
export async function PATCH(request: Request) {
  const parsed = schema.safeParse(await request.json());
  if (!parsed.success) return Response.json({ ok: false, error: "Некорректные данные" }, { status: 400 });
  const item = await updateRadarItem(parsed.data.id, { status: parsed.data.status });
  return item ? Response.json({ ok: true, item }) : Response.json({ ok: false, error: "Материал не найден" }, { status: 404 });
}
