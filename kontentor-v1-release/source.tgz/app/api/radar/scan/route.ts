import { getRadarSettings, listRadarItems } from "@/lib/radar-store";
import { scanRadar } from "@/lib/radar";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const [settings, items] = await Promise.all([getRadarSettings(), listRadarItems()]);
  return Response.json({ ok: true, settings, items: items.slice(0, 200) });
}

export async function POST() {
  try {
    const settings = await getRadarSettings();
    const result = await scanRadar(settings);
    return Response.json({ ok: true, ...result });
  } catch (error) {
    return Response.json({ ok: false, error: error instanceof Error ? error.message : "Radar не смог выполнить поиск" }, { status: 502 });
  }
}
