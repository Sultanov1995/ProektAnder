import { z } from "zod";
import { assertPublicFeedUrl } from "@/lib/radar";
import { getRadarSettings, saveRadarSettings } from "@/lib/radar-store";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const feedSchema = z.object({ id: z.string().optional().default(""), name: z.string().trim().min(1).max(100), url: z.string().trim().url().max(1000), enabled: z.boolean() });
const schema = z.object({
  topics: z.array(z.string().trim().min(2).max(100)).max(12),
  excludeKeywords: z.array(z.string().trim().min(2).max(80)).max(30),
  feeds: z.array(feedSchema).max(20),
});

export async function GET() {
  return Response.json({ ok: true, settings: await getRadarSettings() });
}

export async function PUT(request: Request) {
  try {
    const parsed = schema.safeParse(await request.json());
    if (!parsed.success) return Response.json({ ok: false, error: parsed.error.issues[0]?.message || "Проверьте настройки" }, { status: 400 });
    for (const feed of parsed.data.feeds) await assertPublicFeedUrl(feed.url);
    const settings = await saveRadarSettings(parsed.data);
    return Response.json({ ok: true, settings });
  } catch (error) {
    return Response.json({ ok: false, error: error instanceof Error ? error.message : "Не удалось сохранить настройки" }, { status: 400 });
  }
}
