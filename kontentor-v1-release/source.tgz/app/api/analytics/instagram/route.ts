import { captureInstagramInsights, listInstagramInsights } from "@/lib/instagram-insights";
import { getInstagramConnection } from "@/lib/instagram-vault";
export const runtime = "nodejs"; export const dynamic = "force-dynamic";
async function payload(){ const connection=await getInstagramConnection(); if(!connection)return {connected:false,snapshots:[],latest:null}; const snapshots=await listInstagramInsights(connection.userId); return {connected:true,account:{username:connection.username,userId:connection.userId},snapshots:snapshots.slice(-30),latest:snapshots.at(-1)||null}; }
export async function GET(){ return Response.json({ok:true,...await payload()}); }
export async function POST(){ try{ await captureInstagramInsights(7); return Response.json({ok:true,...await payload()}); }catch(error){ return Response.json({ok:false,error:error instanceof Error?error.message:"Не удалось получить Instagram Insights"},{status:502}); } }
