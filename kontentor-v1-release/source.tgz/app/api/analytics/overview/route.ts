import { listAudienceSnapshots } from "@/lib/analytics-store";
import { listInstagramInsights } from "@/lib/instagram-insights";
import { listMtprotoSnapshots } from "@/lib/mtproto-store";
import { listPublications } from "@/lib/publication-store";
import { getInstagramConnection } from "@/lib/instagram-vault";
import { getTelegramConnection } from "@/lib/telegram-vault";
import { getValidVkConnection } from "@/lib/vk-vault";
import { listVkAnalytics } from "@/lib/vk-analytics";
import { getValidYouTubeConnection } from "@/lib/youtube-vault";
import { listYouTubeInsights } from "@/lib/youtube-insights";
export const runtime="nodejs";export const dynamic="force-dynamic";
export async function GET(){
 const [tg,ig,vk,yt,pubs]=await Promise.all([getTelegramConnection(),getInstagramConnection(),getValidVkConnection(),getValidYouTubeConnection(),listPublications()]);
 const [audience,mt,instagram,vkRows,ytRows]=await Promise.all([tg?listAudienceSnapshots(tg.channelId):Promise.resolve([]),tg?listMtprotoSnapshots(tg.channelUsername?`@${tg.channelUsername}`:tg.channelId):Promise.resolve([]),ig?listInstagramInsights(ig.userId):Promise.resolve([]),vk?listVkAnalytics(vk.groupId):Promise.resolve([]),yt?listYouTubeInsights(yt.channelId):Promise.resolve([])]);
 const mtLatest=mt.at(-1)||null,igLatest=instagram.at(-1)||null,vkLatest=vkRows.at(-1)||null,ytLatest=ytRows.at(-1)||null;const weekAgo=Date.now()-7*86400000;
 const published7d=pubs.filter(p=>p.publishedAt&&new Date(p.publishedAt).getTime()>=weekAgo&&["published","partial"].includes(p.status)).length,failed7d=pubs.filter(p=>p.status==="failed"&&new Date(p.createdAt).getTime()>=weekAgo).length;const tgFirst=audience[0],tgLast=audience.at(-1);
 const recommendations:Array<{title:string;text:string,type:string}>=[];
 if(igLatest?.metrics?.reach!==undefined&&igLatest.metrics.reach>0)recommendations.push({type:"instagram",title:"Instagram: сравнивайте охват и взаимодействия",text:`Текущий охват: ${igLatest.metrics.reach.toLocaleString("ru-RU")}. AI‑стратег использует его вместе с вовлечёнными аккаунтами и взаимодействиями.`});
 if(mtLatest?.viewsPerPost?.current!==undefined)recommendations.push({type:"telegram",title:"Telegram: база по просмотрам",text:`Средний уровень: ${mtLatest.viewsPerPost.current.toLocaleString("ru-RU",{maximumFractionDigits:1})} просмотров на пост.`});
 if(vkLatest?.averages?.viewsPerPost!==undefined)recommendations.push({type:"vk",title:"VK: видна эффективность стены",text:`Среднее по последним ${vkLatest.postsAnalyzed} постам: ${vkLatest.averages.viewsPerPost.toLocaleString("ru-RU",{maximumFractionDigits:0})} просмотров.`});
 if(ytLatest?.metrics?.views!==undefined)recommendations.push({type:"youtube",title:"YouTube: учитывайте не только просмотры",text:`За период: ${ytLatest.metrics.views.toLocaleString("ru-RU")} просмотров и ${Math.round(ytLatest.metrics.estimatedMinutesWatched||0).toLocaleString("ru-RU")} минут просмотра.`});
 if(published7d<3)recommendations.push({type:"cadence",title:"Нужно больше истории",text:`За 7 дней опубликовано ${published7d}. Регулярная история улучшит рекомендации по четырём площадкам.`});if(failed7d)recommendations.push({type:"error",title:"Проверьте ошибки доставки",text:`За 7 дней неуспешных публикаций: ${failed7d}. Исправьте их до полного автопилота.`});
 return Response.json({ok:true,telegram:{connected:Boolean(tg),channel:tg?{title:tg.channelTitle,username:tg.channelUsername}:null,members:tgLast?.members,memberDelta:tgFirst&&tgLast?tgLast.members-tgFirst.members:0,mtproto:mtLatest},instagram:{connected:Boolean(ig),account:ig?{username:ig.username}:null,latest:igLatest},vk:{connected:Boolean(vk),group:vk?{id:vk.groupId,name:vk.groupName,screenName:vk.screenName}:null,latest:vkLatest},youtube:{connected:Boolean(yt),channel:yt?{id:yt.channelId,title:yt.channelTitle,handle:yt.channelHandle}:null,latest:ytLatest},publications:{published7d,failed7d,scheduled:pubs.filter(p=>p.status==="scheduled").length},recommendations:recommendations.slice(0,7)});
}
