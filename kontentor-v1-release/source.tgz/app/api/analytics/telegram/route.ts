import { addAudienceSnapshot, listAudienceSnapshots } from "@/lib/analytics-store";
import { getTelegramMemberCount } from "@/lib/telegram";
import { getTelegramConnection } from "@/lib/telegram-vault";
import { listPublications } from "@/lib/publication-store";
import { listRadarItems } from "@/lib/radar-store";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

async function payload() {
  const connection = await getTelegramConnection();
  if (!connection) return { connected: false, snapshots: [], publications: {}, recommendations: [] };
  const [snapshots, publications, radar] = await Promise.all([
    listAudienceSnapshots(connection.channelId), listPublications(), listRadarItems(),
  ]);
  const now = Date.now();
  const weekAgo = now - 7 * 24 * 60 * 60 * 1000;
  const published7d = publications.filter((item) => (item.deliveries?.telegram?.status === "published" || (!item.deliveries && item.status === "published")) && item.publishedAt && new Date(item.publishedAt).getTime() >= weekAgo).length;
  const failed7d = publications.filter((item) => item.status === "failed" && new Date(item.createdAt).getTime() >= weekAgo).length;
  const scheduled = publications.filter((item) => item.status === "scheduled").length;
  const publishedTotal = publications.filter((item) => item.deliveries?.telegram?.status === "published" || (!item.deliveries && item.status === "published")).length;
  const first = snapshots[0]; const latest = snapshots[snapshots.length - 1];
  const memberDelta = first && latest ? latest.members - first.members : 0;
  const recommendations: Array<{ title: string; text: string; type: string }> = [];
  const strong = radar.find((item) => item.status === "new" && item.score >= .7);
  if (strong) recommendations.push({ type: "radar", title: "Сильная тема в Radar", text: `Рассмотрите материал «${strong.title}». Оценка Radar: ${Math.round(strong.score * 100)}/100.` });
  if (published7d < 3) recommendations.push({ type: "cadence", title: "Низкая частота публикаций", text: `За последние 7 дней опубликовано ${published7d}. Подготовьте стабильный график и сравните динамику аудитории после нескольких недель.` });
  if (failed7d > 0) recommendations.push({ type: "error", title: "Есть ошибки публикации", text: `За последние 7 дней зафиксировано ошибок: ${failed7d}. Проверьте историю и права Telegram-бота.` });
  if (memberDelta > 0) recommendations.push({ type: "growth", title: "Аудитория растёт", text: `С момента первого замера размер канала увеличился на ${memberDelta}. Не связываем рост с конкретными постами без расширенной статистики Telegram.` });
  if (!recommendations.length) recommendations.push({ type: "baseline", title: "Накопите базу для рекомендаций", text: "Продолжайте ежедневные замеры аудитории и публикации. После накопления истории рекомендации станут полезнее." });

  return {
    connected: true,
    channel: { title: connection.channelTitle, username: connection.channelUsername },
    snapshots: snapshots.slice(-60),
    currentMembers: latest?.members,
    memberDelta,
    publications: { published7d, publishedTotal, failed7d, scheduled },
    recommendations: recommendations.slice(0, 4),
  };
}

export async function GET() { return Response.json({ ok: true, ...(await payload()) }); }

export async function POST() {
  try {
    const connection = await getTelegramConnection();
    if (!connection) return Response.json({ ok: false, error: "Telegram-канал не подключён" }, { status: 409 });
    const members = await getTelegramMemberCount(connection.token, connection.channelId);
    await addAudienceSnapshot(connection.channelId, members);
    return Response.json({ ok: true, ...(await payload()) });
  } catch (error) {
    return Response.json({ ok: false, error: error instanceof Error ? error.message : "Не удалось обновить аналитику" }, { status: 502 });
  }
}
