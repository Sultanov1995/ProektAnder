import { getValidYouTubeConnection } from "@/lib/youtube-vault";
import { fetchYouTubeAnalytics } from "@/lib/youtube";
import { listYouTubeInsights,saveYouTubeInsights } from "@/lib/youtube-insights";
export const runtime="nodejs";export const dynamic="force-dynamic";
export async function GET(){const c=await getValidYouTubeConnection();if(!c)return Response.json({ok:true,connected:false,snapshots:[]});return Response.json({ok:true,connected:true,channel:{id:c.channelId,title:c.channelTitle,handle:c.channelHandle},snapshots:await listYouTubeInsights(c.channelId)});}
export async function POST(){try{const c=await getValidYouTubeConnection();if(!c)return Response.json({ok:false,error:"YouTube не подключён"},{status:400});const snapshot=await fetchYouTubeAnalytics(c);await saveYouTubeInsights(c.channelId,snapshot);return Response.json({ok:true,snapshot});}catch(e){return Response.json({ok:false,error:e instanceof Error?e.message:"Ошибка YouTube Analytics"},{status:502});}}
