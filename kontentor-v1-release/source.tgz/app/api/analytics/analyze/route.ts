import { z } from "zod";
import { addAudienceSnapshot, listAudienceSnapshots } from "@/lib/analytics-store";
import { getTelegramMemberCount } from "@/lib/telegram";
import { getTelegramConnection } from "@/lib/telegram-vault";
import { fetchTelegramBroadcastStats, isMtprotoConfigured } from "@/lib/mtproto";
import { listMtprotoSnapshots } from "@/lib/mtproto-store";
import { listPublications } from "@/lib/publication-store";
import { captureInstagramInsights } from "@/lib/instagram-insights";
import { getInstagramConnection } from "@/lib/instagram-vault";
import { getValidVkConnection } from "@/lib/vk-vault";
import { fetchVkAnalytics, saveVkAnalytics } from "@/lib/vk-analytics";
import { getValidYouTubeConnection } from "@/lib/youtube-vault";
import { fetchYouTubeAnalytics } from "@/lib/youtube";
import { saveYouTubeInsights } from "@/lib/youtube-insights";
import { getLatestChannelAnalysis, numberRu, percentRu, saveChannelAnalysis, type AnalysisNetwork, type ChannelAnalysis } from "@/lib/channel-analysis";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const schema = z.object({ network: z.enum(["telegram", "instagram", "vk", "youtube"]) });
const metric = (label: string, value: string, note?: string) => ({ label, value, ...(note ? { note } : {}) });


async function telegramAnalysis(): Promise<ChannelAnalysis> {
  const connection = await getTelegramConnection();
  if (!connection) throw new Error("Сначала подключите Telegram-канал.");

  const members = await getTelegramMemberCount(connection.token, connection.channelId);
  await addAudienceSnapshot(connection.channelId, members);

  const channelRef = connection.channelUsername ? `@${connection.channelUsername}` : connection.channelId;
  let mtError = "";
  if (isMtprotoConfigured()) {
    try { await fetchTelegramBroadcastStats(channelRef); }
    catch (error) { mtError = error instanceof Error ? error.message : "Не удалось получить расширенную Telegram-статистику"; }
  }

  const [snapshots, mtRows, publications] = await Promise.all([
    listAudienceSnapshots(connection.channelId),
    listMtprotoSnapshots(channelRef),
    listPublications(),
  ]);
  const mt = mtRows.at(-1) || null;
  const first = snapshots[0];
  const latest = snapshots.at(-1);
  const previous = snapshots.at(-2);
  const totalDelta = first && latest ? latest.members - first.members : 0;
  const lastDelta = previous && latest ? latest.members - previous.members : undefined;
  const monthAgo = Date.now() - 30 * 86400000;
  const tgPublished = publications.filter((item) => {
    const delivered = item.deliveries?.telegram?.status === "published" || (!item.deliveries && item.status === "published");
    const when = item.publishedAt ? new Date(item.publishedAt).getTime() : 0;
    return delivered && when >= monthAgo;
  });
  const tgFailed = publications.filter((item) => item.status === "failed" && new Date(item.createdAt).getTime() >= monthAgo).length;

  const views = mt?.viewsPerPost?.current;
  const reactions = mt?.reactionsPerPost?.current;
  const shares = mt?.sharesPerPost?.current;
  const viewRate = views !== undefined && members > 0 ? (views / members) * 100 : undefined;

  const strengths: string[] = [];
  const risks: string[] = [];
  const recommendations: string[] = [];
  if (totalDelta > 0) strengths.push(`Аудитория выросла на ${numberRu(totalDelta)} подписчиков с первого замера.`);
  if (viewRate !== undefined && viewRate >= 50) strengths.push(`Средние просмотры поста составляют около ${percentRu(viewRate)} от текущей аудитории.`);
  if (reactions !== undefined && reactions > 0) strengths.push(`На постах фиксируются реакции: в среднем ${numberRu(reactions, 1)} на публикацию.`);
  if (tgPublished.length >= 8) strengths.push(`Есть регулярность: ${tgPublished.length} публикаций за последние 30 дней.`);

  if (snapshots.length < 2) risks.push("Пока есть только базовый замер аудитории — динамика станет точнее после следующих анализов.");
  if (!mt) risks.push("Расширенные просмотры, реакции и пересылки недоступны без MTProto-статистики.");
  if (tgPublished.length < 4) risks.push(`Низкая частота публикаций в KONTENTOR: ${tgPublished.length} за последние 30 дней.`);
  if (tgFailed > 0) risks.push(`За последние 30 дней есть неуспешные публикации: ${tgFailed}.`);

  if (viewRate !== undefined && viewRate < 35) recommendations.push("Усильте первые 2–3 строки постов и тестируйте более короткие форматы: текущая доля просмотров от аудитории сравнительно низкая.");
  if (tgPublished.length < 8) recommendations.push("Сформируйте стабильный график на 2–3 публикации в неделю и повторите анализ через 7–14 дней.");
  if (shares !== undefined && shares < 1) recommendations.push("Добавляйте сохраняемые и пересылаемые форматы: чек-листы, подборки, инструкции и короткие выводы.");
  if (!mt) recommendations.push("Подключите расширенную Telegram-аналитику MTProto, чтобы KONTENTOR видел просмотры, пересылки, реакции и лучшие посты.");
  if (!recommendations.length) recommendations.push("Сохраняйте текущий ритм и повторяйте анализ регулярно — KONTENTOR будет сравнивать новые снимки с историей.");

  const topContent = (mt?.recentPosts || []).slice().sort((a,b)=>b.views-a.views).slice(0,5).map((post) => ({
    title: `Пост #${post.messageId}`,
    metric: `${numberRu(post.views)} просмотров · ${numberRu(post.reactions)} реакций · ${numberRu(post.forwards)} пересылок`,
    ...(connection.channelUsername ? { link: `https://t.me/${connection.channelUsername}/${post.messageId}` } : {}),
  }));

  const headline = totalDelta > 0 ? "Канал растёт — зафиксирована положительная динамика аудитории." : mt ? "Расширенная аналитика Telegram собрана." : "Базовый анализ Telegram готов.";
  const summary = `Сейчас в канале ${numberRu(members)} подписчиков. ${snapshots.length >= 2 ? `Последнее изменение: ${lastDelta === undefined ? "—" : `${lastDelta >= 0 ? "+" : ""}${numberRu(lastDelta)}`}.` : "Это первый базовый замер KONTENTOR."} ${views !== undefined ? `Средние просмотры на пост: ${numberRu(views, 1)}.` : "Расширенные просмотры пока недоступны."}`;

  return {
    network: "telegram",
    capturedAt: new Date().toISOString(),
    account: { id: connection.channelId, title: connection.channelTitle, username: connection.channelUsername },
    dataLevel: mt ? "Расширенный" : "Базовый",
    headline,
    summary,
    metrics: [
      metric("Подписчики", numberRu(members)),
      metric("Динамика", snapshots.length >= 2 ? `${totalDelta >= 0 ? "+" : ""}${numberRu(totalDelta)}` : "Базовый замер"),
      metric("Просмотры / пост", numberRu(views, 1), viewRate !== undefined ? `${percentRu(viewRate)} аудитории` : undefined),
      metric("Публикации · 30 дней", numberRu(tgPublished.length)),
      metric("Реакции / пост", numberRu(reactions, 1)),
      metric("Пересылки / пост", numberRu(shares, 1)),
    ],
    strengths: strengths.length ? strengths : ["Канал подключён корректно, базовые данные доступны для дальнейшего накопления истории."],
    risks,
    recommendations: recommendations.slice(0,5),
    topContent,
    limitations: [
      ...(!mt ? ["Bot API не отдаёт историю просмотров и реакций канала; для этого нужен MTProto-доступ."] : []),
      ...(mtError ? [`MTProto: ${mtError}`] : []),
      "KONTENTOR не приписывает рост аудитории конкретным постам без подтверждающих данных Telegram.",
    ],
  };
}

async function instagramAnalysis(): Promise<ChannelAnalysis> {
  const connection = await getInstagramConnection();
  if (!connection) throw new Error("Сначала подключите Instagram Professional.");
  const s = await captureInstagramInsights(7);
  const m = s.metrics || {};
  const reach = m.reach;
  const interactions = m.total_interactions;
  const engagement = typeof reach === "number" && reach > 0 && interactions !== undefined ? (interactions / reach) * 100 : undefined;
  const top = (s.recentMedia || []).slice().sort((a,b)=>(b.totalInteractions||b.views||b.reach||0)-(a.totalInteractions||a.views||a.reach||0)).slice(0,5);
  const formatCounts = top.reduce<Record<string,number>>((acc,item)=>{const key=item.productType||item.mediaType||"MEDIA";acc[key]=(acc[key]||0)+1;return acc;},{});
  const bestFormat = Object.entries(formatCounts).sort((a,b)=>b[1]-a[1])[0]?.[0];
  const strengths:string[]=[]; const risks:string[]=[]; const recommendations:string[]=[];
  if (engagement !== undefined && engagement >= 3) strengths.push(`Взаимодействия составляют около ${percentRu(engagement)} от охвата за выбранный период.`);
  if ((m.saves||0) > 0) strengths.push(`Контент сохраняют: ${numberRu(m.saves)} сохранений за период.`);
  if ((m.shares||0) > 0) strengths.push(`Есть органические распространения: ${numberRu(m.shares)} отправок/репостов.`);
  if (top.length) strengths.push(`KONTENTOR получил метрики по ${top.length} последним публикациям.`);
  if (!reach) risks.push("Instagram не вернул охват за период или он равен нулю — часть выводов ограничена.");
  if (engagement !== undefined && engagement < 1) risks.push("Доля взаимодействий относительно охвата ниже 1% — стоит пересмотреть подачу и CTA.");
  if (!(m.saves||0) && !(m.shares||0)) risks.push("В текущем снимке нет сохранений и отправок либо эти метрики недоступны приложению Meta.");
  if (bestFormat) recommendations.push(`Продолжите тестировать формат ${bestFormat}: он чаще встречается среди лучших последних публикаций.`);
  if (engagement !== undefined && engagement < 3) recommendations.push("Усильте первый экран, конкретную пользу и призыв к сохранению/ответу; затем сравните следующий 7-дневный снимок.");
  recommendations.push("Используйте лучшие темы из последних публикаций как основу для серии Reels/каруселей, а не как разовые посты.");
  return {
    network:"instagram",capturedAt:new Date().toISOString(),account:{id:connection.userId,title:`@${connection.username}`,username:connection.username},dataLevel:"Расширенный",
    headline: engagement !== undefined && engagement >= 3 ? "Instagram показывает хороший уровень взаимодействия с охватом." : "Instagram Insights собраны — есть база для оптимизации контента.",
    summary:`За последние 7 дней KONTENTOR получил охват ${numberRu(reach)}, ${numberRu(m.views)} просмотров и ${numberRu(interactions)} взаимодействий. ${engagement !== undefined ? `Отношение взаимодействий к охвату — ${percentRu(engagement)}.` : "Для расчёта относительной вовлечённости не хватает данных."}`,
    metrics:[metric("Подписчики",numberRu(s.followers)),metric("Охват · 7 дней",numberRu(reach)),metric("Просмотры",numberRu(m.views)),metric("Взаимодействия",numberRu(interactions)),metric("Сохранения",numberRu(m.saves)),metric("Отправки",numberRu(m.shares))],
    strengths:strengths.length?strengths:["Профессиональный аккаунт подключён и отдаёт Insights в KONTENTOR."],risks,recommendations:recommendations.slice(0,5),
    topContent:top.map((item,i)=>({title:(item.caption||`${item.productType||item.mediaType||"Публикация"} #${i+1}`).replace(/\s+/g," ").slice(0,82),metric:`${numberRu(item.views)} просмотров · ${numberRu(item.totalInteractions)} взаимодействий`,...(item.permalink?{link:item.permalink}:{})})),
    limitations:["Набор Instagram Insights зависит от типа аккаунта, разрешений Meta App и доступности конкретных метрик."],
  };
}

async function vkAnalysis(): Promise<ChannelAnalysis> {
  const connection = await getValidVkConnection();
  if (!connection) throw new Error("Сначала подключите сообщество VK.");
  const s = await fetchVkAnalytics(connection);
  await saveVkAnalytics(connection.groupId, s);
  const interactions=s.totals.likes+s.totals.comments+s.totals.reposts;
  const interactionRate=s.totals.views>0?(interactions/s.totals.views)*100:undefined;
  const strengths:string[]=[];const risks:string[]=[];const recommendations:string[]=[];
  if(s.averages.viewsPerPost>0)strengths.push(`Средний пост получает ${numberRu(s.averages.viewsPerPost)} просмотров.`);
  if(interactionRate!==undefined&&interactionRate>=2)strengths.push(`Суммарные лайки, комментарии и репосты составляют около ${percentRu(interactionRate)} от просмотров.`);
  if(s.topPosts.length)strengths.push(`Определены ${s.topPosts.length} лучших публикаций по просмотрам.`);
  if(s.postsAnalyzed<5)risks.push(`Небольшая выборка: проанализировано только ${s.postsAnalyzed} публикаций.`);
  if(s.averages.commentsPerPost<1)risks.push("В среднем меньше одного комментария на пост — дискуссионность контента низкая.");
  if(s.averages.repostsPerPost<1)recommendations.push("Добавьте больше контента, которым удобно делиться: списки, инструкции, локальные подборки и полезные карточки.");
  recommendations.push("Используйте темы из топ-5 по просмотрам как основу следующего контент-цикла и сравните изменения после 5–10 новых публикаций.");
  if(s.averages.commentsPerPost<1)recommendations.push("Добавляйте конкретный вопрос в конце поста и тестируйте темы, где аудитория может поделиться опытом.");
  return {network:"vk",capturedAt:new Date().toISOString(),account:{id:connection.groupId,title:connection.groupName,username:connection.screenName},dataLevel:"Расширенный",headline:"VK-стена проанализирована по последним публикациям.",summary:`KONTENTOR проанализировал ${s.postsAnalyzed} публикаций: ${numberRu(s.totals.views)} просмотров, ${numberRu(s.totals.likes)} лайков, ${numberRu(s.totals.comments)} комментариев и ${numberRu(s.totals.reposts)} репостов.`,metrics:[metric("Участники",numberRu(s.members)),metric("Постов в выборке",numberRu(s.postsAnalyzed)),metric("Просмотры / пост",numberRu(s.averages.viewsPerPost,1)),metric("Лайки / пост",numberRu(s.averages.likesPerPost,1)),metric("Комментарии / пост",numberRu(s.averages.commentsPerPost,1)),metric("Репосты / пост",numberRu(s.averages.repostsPerPost,1))],strengths:strengths.length?strengths:["Сообщество подключено и отдаёт данные стены."],risks,recommendations:recommendations.slice(0,5),topContent:s.topPosts.map(p=>({title:(p.text||`Пост #${p.id}`).replace(/\s+/g," ").slice(0,82),metric:`${numberRu(p.views)} просмотров · ${numberRu(p.likes)} лайков`,link:p.link})),limitations:["Анализ VK сейчас строится по последним публикациям стены и доступным счётчикам API."]};
}

async function youtubeAnalysis(): Promise<ChannelAnalysis> {
  const connection = await getValidYouTubeConnection();
  if (!connection) throw new Error("Сначала подключите YouTube-канал.");
  const s = await fetchYouTubeAnalytics(connection,28);
  await saveYouTubeInsights(connection.channelId,s);
  const m=s.metrics||{};const net=(m.subscribersGained||0)-(m.subscribersLost||0);
  const strengths:string[]=[];const risks:string[]=[];const recommendations:string[]=[];
  if((m.views||0)>0)strengths.push(`За 28 дней получено ${numberRu(m.views)} просмотров.`);
  if(net>0)strengths.push(`Чистый прирост подписчиков за период: +${numberRu(net)}.`);
  if((m.averageViewDuration||0)>0)strengths.push(`Средняя длительность просмотра: ${numberRu(m.averageViewDuration)} сек.`);
  if(net<0)risks.push(`За период ушло больше подписчиков, чем пришло: чистое изменение ${numberRu(net)}.`);
  if((m.views||0)===0)risks.push("YouTube Analytics не вернул просмотры за период либо канал пока не имеет данных.");
  if((m.shares||0)<1)recommendations.push("Добавляйте в ролики конкретный повод поделиться: чек-лист, сравнение, спорный тезис или полезный результат.");
  if((m.averageViewDuration||0)>0)recommendations.push("Сравнивайте среднюю длительность просмотра после каждого нового цикла Shorts/видео и усиливайте первые 5–15 секунд.");
  recommendations.push("Стабильно выпускайте серию материалов одной темы и повторите анализ через 28 дней для сопоставимого периода.");
  return {network:"youtube",capturedAt:new Date().toISOString(),account:{id:connection.channelId,title:connection.channelTitle,username:connection.channelHandle},dataLevel:"Расширенный",headline:net>0?"YouTube показывает положительный чистый прирост подписчиков.":"YouTube Analytics собран за последние 28 дней.",summary:`За 28 дней: ${numberRu(m.views)} просмотров, ${numberRu(m.estimatedMinutesWatched)} минут просмотра и ${net>=0?"+":""}${numberRu(net)} чистого изменения подписчиков.`,metrics:[metric("Подписчики",numberRu(s.subscribers)),metric("Просмотры · 28 дней",numberRu(m.views)),metric("Минуты просмотра",numberRu(m.estimatedMinutesWatched)),metric("Средняя длительность",m.averageViewDuration!==undefined?`${numberRu(m.averageViewDuration)} сек.`:"—"),metric("Новые подписчики",numberRu(m.subscribersGained)),metric("Ушедшие подписчики",numberRu(m.subscribersLost))],strengths:strengths.length?strengths:["YouTube-канал подключён и отдаёт Analytics в KONTENTOR."],risks,recommendations:recommendations.slice(0,5),topContent:[],limitations:["Текущий YouTube-анализ использует агрегированные метрики канала за 28 дней; рейтинг отдельных видео будет добавлен отдельным этапом."],};
}

async function currentAccountRef(network: AnalysisNetwork) {
  if (network === "telegram") return (await getTelegramConnection())?.channelId;
  if (network === "instagram") return (await getInstagramConnection())?.userId;
  if (network === "vk") return (await getValidVkConnection())?.groupId;
  return (await getValidYouTubeConnection())?.channelId;
}

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const parsed = schema.safeParse({ network: url.searchParams.get("network") });
    if (!parsed.success) return Response.json({ ok:false,error:"Укажите соцсеть для анализа" },{status:400});
    const network = parsed.data.network as AnalysisNetwork;
    const accountRef = await currentAccountRef(network);
    if (!accountRef) return Response.json({ ok:true, analysis:null });
    const latest = await getLatestChannelAnalysis(network, accountRef);
    return Response.json({ ok:true, analysis:latest });
  } catch (error) {
    return Response.json({ ok:false,error:error instanceof Error?error.message:"Не удалось прочитать анализ" },{status:500});
  }
}

export async function POST(request: Request) {
  try {
    const parsed = schema.safeParse(await request.json());
    if (!parsed.success) return Response.json({ ok:false,error:"Выберите соцсеть для анализа" },{status:400});
    const network=parsed.data.network as AnalysisNetwork;
    const analysis = network==="telegram"?await telegramAnalysis():network==="instagram"?await instagramAnalysis():network==="vk"?await vkAnalysis():await youtubeAnalysis();
    const saved=await saveChannelAnalysis(analysis);
    return Response.json({ok:true,analysis:saved});
  } catch (error) {
    const message=error instanceof Error?error.message:"Не удалось выполнить анализ";
    const status=/Сначала подключите/.test(message)?409:502;
    return Response.json({ok:false,error:message},{status});
  }
}
