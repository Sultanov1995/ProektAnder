import { z } from "zod";
import { inspectVkGroup } from "@/lib/vk";
import { deleteVkConnection,getVkConnection,publicVkConnection,saveVkConnection } from "@/lib/vk-vault";
export const runtime="nodejs";
export async function GET(){return Response.json({ok:true,connection:publicVkConnection(await getVkConnection())});}
const schema=z.object({groupId:z.string().trim().min(1),accessToken:z.string().trim().min(10),tokenKind:z.enum(["community","user"]).default("community")});
export async function POST(request:Request){try{if(process.env.NODE_ENV==="production"&&process.env.ALLOW_MANUAL_VK_TOKEN!=="true")return Response.json({ok:false,error:"Ручное подключение VK отключено. Используйте VK ID OAuth 2.1."},{status:403});const parsed=schema.safeParse(await request.json());if(!parsed.success)return Response.json({ok:false,error:"Укажите ID сообщества и access token"},{status:400});const group=await inspectVkGroup(parsed.data.groupId,parsed.data.accessToken);await saveVkConnection({...group,accessToken:parsed.data.accessToken,tokenKind:parsed.data.tokenKind,connectedAt:new Date().toISOString()});return Response.json({ok:true,connection:publicVkConnection(await getVkConnection())});}catch(error){return Response.json({ok:false,error:error instanceof Error?error.message:"Не удалось подключить VK"},{status:400});}}
export async function DELETE(){await deleteVkConnection();return Response.json({ok:true});}
