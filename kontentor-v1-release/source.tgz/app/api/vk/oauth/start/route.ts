import { randomBytes } from "crypto";
import { z } from "zod";
import { createVkOAuthState } from "@/lib/vk-oauth";

export const runtime = "nodejs";

const schema = z.object({ groupId: z.string().trim().regex(/^\d+$/) });

export async function POST(request: Request) {
  try {
    const parsed = schema.safeParse(await request.json());
    if (!parsed.success) return Response.json({ ok: false, error: "Укажите числовой ID сообщества VK" }, { status: 400 });
    const appId = Number(process.env.VK_ID_APP_ID || 0);
    const redirectUrl = process.env.VK_ID_REDIRECT_URI;
    if (!appId || !redirectUrl) return Response.json({ ok: false, error: "VK_ID_APP_ID / VK_ID_REDIRECT_URI не настроены" }, { status: 500 });
    const state = await createVkOAuthState(parsed.data.groupId);
    const codeVerifier = randomBytes(48).toString("base64url");
    return Response.json({
      ok: true,
      appId,
      redirectUrl,
      scope: process.env.VK_ID_SCOPE || "groups wall photos",
      state,
      codeVerifier,
    });
  } catch (error) {
    return Response.json({ ok: false, error: error instanceof Error ? error.message : "Не удалось подготовить VK ID OAuth" }, { status: 500 });
  }
}
