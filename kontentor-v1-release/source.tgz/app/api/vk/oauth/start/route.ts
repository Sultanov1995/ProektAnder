import { createHash, randomBytes } from "node:crypto";
import { z } from "zod";
import { createVkOAuthState } from "@/lib/vk-oauth";
import { requireSession } from "@/lib/auth";

export const runtime = "nodejs";

const schema = z.object({ groupId: z.string().trim().regex(/^\d+$/) });

export async function POST(request: Request) {
  try {
    await requireSession();
    const parsed = schema.safeParse(await request.json());
    if (!parsed.success) return Response.json({ ok: false, error: "Укажите числовой ID сообщества VK" }, { status: 400 });

    const appId = String(process.env.VK_ID_APP_ID || "").trim();
    const redirectUrl = String(process.env.VK_ID_REDIRECT_URI || "").trim();
    if (!/^\d+$/.test(appId) || !redirectUrl) {
      return Response.json({ ok: false, error: "VK_ID_APP_ID / VK_ID_REDIRECT_URI не настроены" }, { status: 500 });
    }

    const state = await createVkOAuthState(parsed.data.groupId);
    const codeVerifier = randomBytes(48).toString("base64url");
    const codeChallenge = createHash("sha256").update(codeVerifier).digest("base64url");
    const scope = process.env.VK_ID_SCOPE || "groups wall photos";
    const domain = process.env.VK_ID_DOMAIN || "id.vk.ru";
    const params = new URLSearchParams({
      client_id: appId,
      redirect_uri: redirectUrl,
      response_type: "code",
      scope,
      state,
      code_challenge: codeChallenge,
      code_challenge_method: "S256",
    });

    return Response.json({
      ok: true,
      state,
      codeVerifier,
      authUrl: `https://${domain}/authorize?${params.toString()}`,
    });
  } catch (error) {
    const message = error instanceof Error && error.message === "UNAUTHORIZED" ? "UNAUTHORIZED" : "Не удалось подготовить VK ID OAuth";
    return Response.json({ ok: false, error: message }, { status: message === "UNAUTHORIZED" ? 401 : 500 });
  }
}
