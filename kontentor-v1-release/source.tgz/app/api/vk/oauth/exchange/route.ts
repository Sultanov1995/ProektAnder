import { z } from "zod";
import { inspectVkGroup } from "@/lib/vk";
import { consumeVkOAuthState } from "@/lib/vk-oauth";
import { publicVkConnection, saveVkConnection, getVkConnection } from "@/lib/vk-vault";

export const runtime = "nodejs";

const schema = z.object({
  code: z.string().min(2),
  deviceId: z.string().min(1),
  codeVerifier: z.string().min(32).max(256),
  state: z.string().min(8),
});

export async function POST(request: Request) {
  try {
    const parsed = schema.safeParse(await request.json());
    if (!parsed.success) return Response.json({ ok: false, error: "Некорректные данные VK ID OAuth" }, { status: 400 });
    const stateData = await consumeVkOAuthState(parsed.data.state);
    if (!stateData) return Response.json({ ok: false, error: "VK ID OAuth state истёк или уже использован" }, { status: 400 });

    const clientId = process.env.VK_ID_APP_ID;
    const redirectUri = process.env.VK_ID_REDIRECT_URI;
    if (!clientId || !redirectUri) return Response.json({ ok: false, error: "VK_ID_APP_ID / VK_ID_REDIRECT_URI не настроены" }, { status: 500 });

    const domain = process.env.VK_ID_DOMAIN || "id.vk.ru";
    const query = new URLSearchParams({
      grant_type: "authorization_code",
      redirect_uri: redirectUri,
      client_id: clientId,
      code_verifier: parsed.data.codeVerifier,
      state: parsed.data.state,
      device_id: parsed.data.deviceId,
    });
    const tokenRes = await fetch(`https://${domain}/oauth2/auth?${query.toString()}`, {
      method: "POST",
      body: new URLSearchParams({ code: parsed.data.code }),
      cache: "no-store",
    });
    const token = await tokenRes.json() as any;
    if (!tokenRes.ok || token.error || !token.access_token) throw new Error(token.error_description || token.error || `VK ID ${tokenRes.status}`);
    if (token.state && token.state !== parsed.data.state) throw new Error("VK ID OAuth state не совпал");

    const group = await inspectVkGroup(stateData.groupId, token.access_token);
    await saveVkConnection({
      ...group,
      accessToken: token.access_token,
      refreshToken: token.refresh_token,
      deviceId: parsed.data.deviceId,
      expiresAt: new Date(Date.now() + Number(token.expires_in || 3600) * 1000).toISOString(),
      tokenKind: "vkid",
      connectedAt: new Date().toISOString(),
    });
    return Response.json({ ok: true, connection: publicVkConnection(await getVkConnection()) });
  } catch (error) {
    return Response.json({ ok: false, error: error instanceof Error ? error.message : "Не удалось завершить VK ID OAuth" }, { status: 400 });
  }
}
