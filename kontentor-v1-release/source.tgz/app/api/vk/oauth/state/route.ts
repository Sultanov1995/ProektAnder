import { z } from "zod";
import { createVkOAuthState } from "@/lib/vk-oauth";
export const runtime="nodejs";
const schema=z.object({groupId:z.string().trim().regex(/^\d+$/)});
export async function POST(request:Request){const parsed=schema.safeParse(await request.json());if(!parsed.success)return Response.json({ok:false,error:"Укажите числовой ID сообщества"},{status:400});const state=await createVkOAuthState(parsed.data.groupId);return Response.json({ok:true,state});}
