import { deleteMediaFile } from "@/lib/media-store";
import { approvePublication, cancelPublication, listPublications, publicPublication } from "@/lib/publication-store";
import { updateStrategyPostByPublication } from "@/lib/strategy-store";

export const runtime = "nodejs";

export async function GET() {
  try {
    const items = await listPublications();
    return Response.json({ ok: true, publications: items.map(publicPublication) });
  } catch {
    return Response.json({ ok: false, error: "Не удалось загрузить историю публикаций" }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const url = new URL(request.url);
    const id = url.searchParams.get("id");
    if (!id) return Response.json({ ok: false, error: "Не указан ID публикации" }, { status: 400 });

    const items = await listPublications();
    const current = items.find((item) => item.id === id);
    if (!current) return Response.json({ ok: false, error: "Публикация не найдена" }, { status: 404 });
    if (current.status !== "scheduled" && current.status !== "review") {
      return Response.json({ ok: false, error: "Отменить можно только публикацию на согласовании или в расписании" }, { status: 409 });
    }

    await deleteMediaFile(current.media);
    const cancelled = await cancelPublication(id);
    await updateStrategyPostByPublication(id, { status: "skipped" });
    return Response.json({ ok: true, publication: cancelled ? publicPublication(cancelled) : null });
  } catch (error) {
    return Response.json(
      { ok: false, error: error instanceof Error ? error.message : "Не удалось отменить публикацию" },
      { status: 500 },
    );
  }
}


export async function PATCH(request: Request) {
  try {
    const body = await request.json() as { id?: string; action?: string };
    if (!body.id) return Response.json({ ok: false, error: "Не указан ID публикации" }, { status: 400 });
    if (body.action !== "approve") return Response.json({ ok: false, error: "Неизвестное действие" }, { status: 400 });
    const items = await listPublications();
    const current = items.find((item) => item.id === body.id);
    if (!current) return Response.json({ ok: false, error: "Публикация не найдена" }, { status: 404 });
    if (current.status !== "review") return Response.json({ ok: false, error: "Согласовать можно только черновик на проверке" }, { status: 409 });
    if (!current.scheduledFor || new Date(current.scheduledFor).getTime() <= Date.now() + 30_000) {
      return Response.json({ ok: false, error: "Время публикации уже прошло. Создайте новое расписание в редакторе." }, { status: 409 });
    }
    const approved = await approvePublication(body.id);
    await updateStrategyPostByPublication(body.id, { status: "scheduled" });
    return Response.json({ ok: true, publication: approved ? publicPublication(approved) : null });
  } catch (error) {
    return Response.json({ ok: false, error: error instanceof Error ? error.message : "Не удалось согласовать публикацию" }, { status: 500 });
  }
}
