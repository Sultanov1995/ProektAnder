import { db } from "@/lib/db";
import { mediaStorageMode } from "@/lib/media-store";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await db.$queryRaw`SELECT 1`;
    return Response.json(
      { ok: true, service: "KONTENTOR", version: "1.0.1", database: "postgresql", mediaStorage: mediaStorageMode() },
      { headers: { "cache-control": "no-store" } },
    );
  } catch {
    // Do not expose database hostnames, driver errors, or environment details publicly.
    return Response.json(
      { ok: false, service: "KONTENTOR", version: "1.0.1", database: "unavailable" },
      { status: 503, headers: { "cache-control": "no-store" } },
    );
  }
}
