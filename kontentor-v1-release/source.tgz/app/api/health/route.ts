import { db } from "@/lib/db";import { mediaStorageMode } from "@/lib/media-store";
export const runtime="nodejs";export const dynamic="force-dynamic";
export async function GET(){try{await db.$queryRaw`SELECT 1`;return Response.json({ok:true,service:"KONTENTOR",version:"1.0.0",database:"postgresql",mediaStorage:mediaStorageMode(),auth:Boolean(process.env.AUTH_SECRET)});}catch(error){return Response.json({ok:false,service:"KONTENTOR",version:"1.0.0",database:"unavailable",mediaStorage:mediaStorageMode(),error:error instanceof Error?error.message:"Database error"},{status:503})}}
