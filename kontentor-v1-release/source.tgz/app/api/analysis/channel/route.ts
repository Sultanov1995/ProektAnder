import { z } from "zod";
import { getChannelAnalysis } from "@/lib/channel-analysis-store";
import { runChannelAnalysis } from "@/lib/channel-analysis";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const networkSchema = z.enum(["telegram", "instagram", "vk", "youtube"]);

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const parsed = networkSchema.safeParse(url.searchParams.get("network"));
    if (!parsed.success) return Response.json({ ok: false, error: "Неизвестная соцсеть" }, { status: 400 });
    return Response.json({ ok: true, analysis: await getChannelAnalysis(parsed.data) });
  } catch (error) {
    return Response.json({ ok: false, error: error instanceof Error ? error.message : "Не удалось загрузить анализ" }, { status: 400 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json().catch(() => ({}));
    const parsed = networkSchema.safeParse(body?.network);
    if (!parsed.success) return Response.json({ ok: false, error: "Неизвестная соцсеть" }, { status: 400 });
    const analysis = await runChannelAnalysis(parsed.data);
    return Response.json({ ok: true, analysis });
  } catch (error) {
    return Response.json({ ok: false, error: error instanceof Error ? error.message : "Не удалось провести анализ" }, { status: 400 });
  }
}
