import { generateWeeklyStrategy } from "@/lib/strategy";
import { getWeeklyStrategy } from "@/lib/strategy-store";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  return Response.json({ ok: true, strategy: await getWeeklyStrategy() });
}

export async function POST() {
  try {
    const strategy = await generateWeeklyStrategy();
    return Response.json({ ok: true, strategy });
  } catch (error) {
    return Response.json({ ok: false, error: error instanceof Error ? error.message : "Не удалось создать недельный план" }, { status: 400 });
  }
}
