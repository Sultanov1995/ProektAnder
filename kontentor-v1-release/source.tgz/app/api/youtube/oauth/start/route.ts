import { createYouTubeOAuthState } from "@/lib/youtube-oauth";
export const runtime="nodejs";
export async function GET(){
  const clientId=process.env.GOOGLE_CLIENT_ID, redirectUri=process.env.GOOGLE_REDIRECT_URI;
  if(!clientId||!redirectUri)return Response.json({ok:false,error:"GOOGLE_CLIENT_ID / GOOGLE_REDIRECT_URI не настроены"},{status:500});
  const state=await createYouTubeOAuthState();
  const scope=["https://www.googleapis.com/auth/youtube.upload","https://www.googleapis.com/auth/youtube.readonly","https://www.googleapis.com/auth/yt-analytics.readonly"].join(" ");
  const params=new URLSearchParams({client_id:clientId,redirect_uri:redirectUri,response_type:"code",scope,state,access_type:"offline",include_granted_scopes:"true",prompt:"consent"});
  return Response.json({ok:true,url:`https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`});
}
