import { consumeYouTubeOAuthState } from "@/lib/youtube-oauth";
import { inspectYouTubeChannel } from "@/lib/youtube";
import { saveYouTubeConnection } from "@/lib/youtube-vault";
export const runtime="nodejs";
export async function GET(request:Request){
  const url=new URL(request.url);const code=url.searchParams.get("code");const state=url.searchParams.get("state");const error=url.searchParams.get("error");
  const appUrl=process.env.PUBLIC_APP_URL||process.env.APP_URL||url.origin;
  if(error)return Response.redirect(`${appUrl}/socials/youtube?error=${encodeURIComponent(error)}`);
  if(!code||!state||!(await consumeYouTubeOAuthState(state)))return Response.redirect(`${appUrl}/socials/youtube?error=${encodeURIComponent("Некорректный или истёкший OAuth state")}`);
  try{
    const clientId=process.env.GOOGLE_CLIENT_ID,clientSecret=process.env.GOOGLE_CLIENT_SECRET,redirectUri=process.env.GOOGLE_REDIRECT_URI;
    if(!clientId||!clientSecret||!redirectUri)throw new Error("Google OAuth не настроен");
    const body=new URLSearchParams({client_id:clientId,client_secret:clientSecret,code,grant_type:"authorization_code",redirect_uri:redirectUri});
    const tokenRes=await fetch("https://oauth2.googleapis.com/token",{method:"POST",headers:{"content-type":"application/x-www-form-urlencoded"},body,cache:"no-store"});
    const token=await tokenRes.json() as any;if(!tokenRes.ok||!token.access_token)throw new Error(token.error_description||token.error||"Не удалось получить YouTube token");
    const channel=await inspectYouTubeChannel(token.access_token);
    await saveYouTubeConnection({...channel,accessToken:token.access_token,refreshToken:token.refresh_token,expiresAt:new Date(Date.now()+Number(token.expires_in||3600)*1000).toISOString(),connectedAt:new Date().toISOString()});
    return Response.redirect(`${appUrl}/socials/youtube?connected=1`);
  }catch(e){return Response.redirect(`${appUrl}/socials/youtube?error=${encodeURIComponent(e instanceof Error?e.message:"Ошибка YouTube OAuth")}`);}
}
