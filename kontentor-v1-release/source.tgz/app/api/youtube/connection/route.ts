import { deleteYouTubeConnection,getYouTubeConnection,publicYouTubeConnection } from "@/lib/youtube-vault";
export const runtime="nodejs";export async function GET(){return Response.json({ok:true,connection:publicYouTubeConnection(await getYouTubeConnection())});}export async function DELETE(){await deleteYouTubeConnection();return Response.json({ok:true});}
