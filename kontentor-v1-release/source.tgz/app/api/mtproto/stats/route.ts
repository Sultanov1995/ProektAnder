import { fetchTelegramBroadcastStats, isMtprotoConfigured } from "@/lib/mtproto";
import { listMtprotoSnapshots } from "@/lib/mtproto-store";
import { getTelegramConnection } from "@/lib/telegram-vault";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

async function channelRef() {
  const connection = await getTelegramConnection();
  if (!connection) return { connection: null, ref: "" };
  return {
    connection,
    ref: connection.channelUsername ? `@${connection.channelUsername}` : connection.channelId,
  };
}

export async function GET() {
  const { connection, ref } = await channelRef();
  if (!connection) return Response.json({ ok: true, configured: isMtprotoConfigured(), connected: false, snapshots: [] });
  const snapshots = await listMtprotoSnapshots(ref);
  return Response.json({
    ok: true,
    configured: isMtprotoConfigured(),
    connected: true,
    channel: { title: connection.channelTitle, username: connection.channelUsername },
    snapshots: snapshots.slice(-30),
    latest: snapshots[snapshots.length - 1] || null,
  });
}

export async function POST() {
  try {
    if (!isMtprotoConfigured()) {
      return Response.json({ ok: false, error: "MTProto не настроен. Добавьте TELEGRAM_API_ID, TELEGRAM_API_HASH и TELEGRAM_MT_SESSION." }, { status: 409 });
    }
    const { connection, ref } = await channelRef();
    if (!connection) return Response.json({ ok: false, error: "Сначала подключите Telegram-канал." }, { status: 409 });
    const snapshot = await fetchTelegramBroadcastStats(ref);
    return Response.json({ ok: true, snapshot });
  } catch (error) {
    return Response.json({ ok: false, error: error instanceof Error ? error.message : "Не удалось получить MTProto-статистику" }, { status: 502 });
  }
}
