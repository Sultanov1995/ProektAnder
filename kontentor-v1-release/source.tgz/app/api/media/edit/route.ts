import { z } from "zod";
import { editMediaImage } from "@/lib/openai";
import { createMediaAsset, readMediaAsset } from "@/lib/media-assets";

export const runtime = "nodejs";

const schema = z.object({
  assetId: z.string().trim().min(1),
  prompt: z.string().trim().min(3).max(4000),
  format: z.enum(["square", "portrait", "story", "landscape"]).default("square"),
  quality: z.enum(["low", "medium", "high"]).default("medium"),
});

export async function POST(request: Request) {
  try {
    const parsed = schema.safeParse(await request.json());
    if (!parsed.success) return Response.json({ ok: false, error: "Выберите изображение и опишите изменения" }, { status: 400 });
    const source = await readMediaAsset(parsed.data.assetId);
    if (source.row.kind !== "photo") return Response.json({ ok: false, error: "Редактировать с ИИ можно только изображения" }, { status: 400 });
    const image = await editMediaImage({ buffer: source.buffer, mimeType: source.row.mimeType, prompt: parsed.data.prompt, format: parsed.data.format, quality: parsed.data.quality });
    const asset = await createMediaAsset({
      buffer: image.buffer,
      name: `kontentor-edit-${Date.now()}.jpg`,
      mimeType: image.mimeType,
      source: "ai",
      prompt: `Версия ${source.row.id.slice(0, 8)} · ${parsed.data.prompt}`,
    });
    return Response.json({ ok: true, sourceAssetId: source.row.id, asset: { id: asset.id, name: asset.name, mimeType: asset.mimeType, size: asset.size, kind: asset.kind, source: asset.source, prompt: asset.prompt, createdAt: asset.createdAt.toISOString() }, model: image.model, size: image.size });
  } catch (error) {
    return Response.json({ ok: false, error: error instanceof Error ? error.message : "Не удалось отредактировать изображение" }, { status: 502 });
  }
}
