import { z } from "zod";
import { generateMediaImage } from "@/lib/openai";
import { createMediaAsset } from "@/lib/media-assets";
export const runtime="nodejs";
const schema=z.object({prompt:z.string().trim().min(5).max(4000),format:z.enum(["square","portrait","story","landscape"]).default("square"),quality:z.enum(["low","medium","high"]).default("medium")});
export async function POST(request:Request){try{const parsed=schema.safeParse(await request.json());if(!parsed.success)return Response.json({ok:false,error:"Опишите визуал и выберите формат"},{status:400});const image=await generateMediaImage(parsed.data);const asset=await createMediaAsset({buffer:image.buffer,name:`kontentor-ai-${Date.now()}.jpg`,mimeType:image.mimeType,source:"ai",prompt:parsed.data.prompt});return Response.json({ok:true,asset:{id:asset.id,name:asset.name,mimeType:asset.mimeType,size:asset.size,kind:asset.kind,source:asset.source,prompt:asset.prompt,createdAt:asset.createdAt.toISOString()},model:image.model,size:image.size});}catch(error){return Response.json({ok:false,error:error instanceof Error?error.message:"Не удалось создать изображение"},{status:502});}}
