import { parsePublicMediaToken } from "@/lib/public-media";
import { readMediaFile } from "@/lib/media-store";
export const runtime="nodejs"; export const dynamic="force-dynamic";
export async function GET(request:Request){ try{ const token=new URL(request.url).searchParams.get("token"); if(!token)return new Response("Not found",{status:404}); const media=parsePublicMediaToken(token); const buffer=await readMediaFile({path:media.path,name:"public-media",mimeType:media.mimeType,size:0,kind:media.mimeType.startsWith("video/")?"video":"photo",storage:media.storage}); return new Response(buffer,{headers:{"content-type":media.mimeType,"content-length":String(buffer.length),"cache-control":"private, max-age=60"}});}catch{return new Response("Not found",{status:404});}}
