import { getAutomationSettings, saveAutomationSettings, type AutomationSettings } from "@/lib/automation-store";

export const runtime = "nodejs";

export async function GET() {
  return Response.json({ ok: true, settings: await getAutomationSettings() });
}

export async function POST(request: Request) {
  try {
    const input = await request.json() as AutomationSettings;
    if (!input || (input.mode !== "review" && input.mode !== "autopilot")) {
      return Response.json({ ok: false, error: "Некорректный режим автоматизации" }, { status: 400 });
    }
    const settings = await saveAutomationSettings(input);
    return Response.json({ ok: true, settings });
  } catch (error) {
    return Response.json({ ok: false, error: error instanceof Error ? error.message : "Не удалось сохранить настройки" }, { status: 400 });
  }
}
