import { deleteMediaFile, saveMediaFile } from "@/lib/media-store";
import { createPublication, publicPublication, updatePublication } from "@/lib/publication-store";
import { publishRecordToTelegram } from "@/lib/publisher";
import { getTelegramConnection } from "@/lib/telegram-vault";

export const runtime = "nodejs";

export async function POST(request: Request) {
  let recordId: string | null = null;
  try {
    const form = await request.formData();
    const text = String(form.get("text") || "").trim();
    const source = form.get("source") === "ai" ? "ai" : "manual";

    if (!text) return Response.json({ ok: false, error: "Введите текст публикации" }, { status: 400 });
    if (text.length > 4096) {
      return Response.json({ ok: false, error: "Telegram допускает до 4096 символов в текстовом сообщении" }, { status: 400 });
    }

    const connection = await getTelegramConnection();
    if (!connection) return Response.json({ ok: false, error: "Сначала подключите Telegram-канал" }, { status: 409 });

    const file = form.get("media");
    const media = file instanceof File && file.size > 0 ? await saveMediaFile(file) : undefined;

    const record = await createPublication({
      text,
      source,
      status: "publishing",
      channelId: connection.channelId,
      channelTitle: connection.channelTitle,
      channelUsername: connection.channelUsername,
      media,
    });
    recordId = record.id;

    const sent = await publishRecordToTelegram(record, connection);
    if (record.media) await deleteMediaFile(record.media);
    const published = await updatePublication(record.id, {
      status: "published",
      publishedAt: new Date().toISOString(),
      messageId: sent.messageId,
      mediaMessageId: sent.mediaMessageId,
      publicLink: sent.publicLink,
      media: undefined,
      error: undefined,
    });

    return Response.json({
      ok: true,
      messageId: sent.messageId,
      publicLink: sent.publicLink,
      publication: published ? publicPublication(published) : undefined,
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Не удалось опубликовать сообщение";
    if (recordId) await updatePublication(recordId, { status: "failed", error: message });
    return Response.json({ ok: false, error: message }, { status: 400 });
  }
}
