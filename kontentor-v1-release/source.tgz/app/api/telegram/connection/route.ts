import { z } from "zod";
import { validateTelegramConnection } from "@/lib/telegram";
import {
  deleteTelegramConnection,
  getTelegramConnection,
  publicTelegramConnection,
  saveTelegramConnection,
} from "@/lib/telegram-vault";

export const runtime = "nodejs";

const connectSchema = z.object({
  token: z.string().min(20, "Токен выглядит слишком коротким"),
  channel: z.string().min(2, "Укажите @username канала или его числовой ID"),
});

export async function GET() {
  try {
    const connection = await getTelegramConnection();
    return Response.json({ ok: true, connection: publicTelegramConnection(connection) });
  } catch {
    return Response.json({ ok: false, error: "Не удалось прочитать подключение Telegram" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const parsed = connectSchema.safeParse(await request.json());
    if (!parsed.success) {
      return Response.json({ ok: false, error: parsed.error.issues[0]?.message || "Проверьте данные" }, { status: 400 });
    }

    const { token, channel } = parsed.data;
    const { bot, chat } = await validateTelegramConnection(token.trim(), channel.trim());

    await saveTelegramConnection({
      token: token.trim(),
      botId: bot.id,
      botUsername: bot.username || "",
      botName: bot.first_name,
      channelId: String(chat.id),
      channelTitle: chat.title || chat.username || String(chat.id),
      channelUsername: chat.username,
      connectedAt: new Date().toISOString(),
    });

    const connection = await getTelegramConnection();
    return Response.json({ ok: true, connection: publicTelegramConnection(connection) });
  } catch (error) {
    return Response.json(
      { ok: false, error: error instanceof Error ? error.message : "Не удалось подключить Telegram" },
      { status: 400 },
    );
  }
}

export async function DELETE() {
  try {
    await deleteTelegramConnection();
    return Response.json({ ok: true });
  } catch {
    return Response.json({ ok: false, error: "Не удалось отключить Telegram" }, { status: 500 });
  }
}
