import { saveMediaFile } from "@/lib/media-store";
import { createPublication, publicPublication } from "@/lib/publication-store";
import { getTelegramConnection } from "@/lib/telegram-vault";

export const runtime = "nodejs";

export async function POST(request: Request) {
  try {
    const form = await request.formData();
    const text = String(form.get("text") || "").trim();
    const scheduledForRaw = String(form.get("scheduledFor") || "").trim();
    const source = form.get("source") === "ai" ? "ai" : "manual";

    if (!text) return Response.json({ ok: false, error: "Введите текст публикации" }, { status: 400 });
    if (text.length > 4096) return Response.json({ ok: false, error: "Текст Telegram не должен превышать 4096 символов" }, { status: 400 });
    if (!scheduledForRaw) return Response.json({ ok: false, error: "Выберите дату и время публикации" }, { status: 400 });

    const scheduledFor = new Date(scheduledForRaw);
    if (Number.isNaN(scheduledFor.getTime())) return Response.json({ ok: false, error: "Некорректная дата публикации" }, { status: 400 });
    if (scheduledFor.getTime() < Date.now() + 30_000) {
      return Response.json({ ok: false, error: "Запланируйте публикацию хотя бы на 30 секунд вперёд" }, { status: 400 });
    }

    const connection = await getTelegramConnection();
    if (!connection) return Response.json({ ok: false, error: "Сначала подключите Telegram-канал" }, { status: 409 });

    const file = form.get("media");
    const media = file instanceof File && file.size > 0 ? await saveMediaFile(file) : undefined;

    const record = await createPublication({
      text,
      source,
      status: "scheduled",
      scheduledFor: scheduledFor.toISOString(),
      channelId: connection.channelId,
      channelTitle: connection.channelTitle,
      channelUsername: connection.channelUsername,
      media,
    });

    return Response.json({ ok: true, publication: publicPublication(record) });
  } catch (error) {
    return Response.json(
      { ok: false, error: error instanceof Error ? error.message : "Не удалось запланировать публикацию" },
      { status: 400 },
    );
  }
}
