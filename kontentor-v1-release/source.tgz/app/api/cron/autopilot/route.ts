import { db } from "@/lib/db";
import { runAutopilot } from "@/lib/autopilot";
export const runtime = "nodejs"; export const dynamic = "force-dynamic";
function authorized(request: Request) { if (process.env.NODE_ENV !== "production") return true; const secret = process.env.CRON_SECRET; return Boolean(secret) && request.headers.get("authorization") === `Bearer ${secret}`; }
async function handler(request: Request) {
  if (!authorized(request)) return Response.json({ ok: false, error: "Неверный CRON_SECRET" }, { status: 401 });
  const workspaces = await db.workspace.findMany({ select: { id: true } });
  const results: Array<{ workspaceId:string; ok:boolean; result?:unknown; skipped?:boolean; error?:string }> = [];
  for (const workspace of workspaces) {
    try { results.push({ workspaceId: workspace.id, ok: true, result: await runAutopilot(workspace.id) }); }
    catch (error) { const message=error instanceof Error?error.message:"Ошибка автопилота"; const skipped=/подключите хотя бы одну соцсеть|план ещё не создан/i.test(message); results.push({workspaceId:workspace.id,ok:skipped,skipped,error:message}); }
  }
  return Response.json({ ok: results.every(x=>x.ok), workspaces: results }, { status: results.some(x=>x.ok) ? 200 : 500 });
}
export async function POST(request: Request) { return handler(request); } export async function GET(request: Request) { return handler(request); }
