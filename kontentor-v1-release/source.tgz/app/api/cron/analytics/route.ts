import { db } from "@/lib/db";
import { addAudienceSnapshot } from "@/lib/analytics-store";
import { captureInstagramInsights } from "@/lib/instagram-insights";
import { getInstagramConnection } from "@/lib/instagram-vault";
import { fetchTelegramBroadcastStats,isMtprotoConfigured } from "@/lib/mtproto";
import { getTelegramMemberCount } from "@/lib/telegram";
import { getTelegramConnection } from "@/lib/telegram-vault";
import { fetchVkAnalytics,saveVkAnalytics } from "@/lib/vk-analytics";
import { getValidVkConnection } from "@/lib/vk-vault";
import { fetchYouTubeAnalytics } from "@/lib/youtube";
import { saveYouTubeInsights } from "@/lib/youtube-insights";
import { getValidYouTubeConnection } from "@/lib/youtube-vault";
export const runtime="nodejs"; export const dynamic="force-dynamic";
function authorized(request:Request){if(process.env.NODE_ENV!=="production")return true;const secret=process.env.CRON_SECRET;return Boolean(secret)&&request.headers.get("authorization")===`Bearer ${secret}`;}
async function capture(workspaceId:string){
 const [telegram,instagram,vk,youtube]=await Promise.all([getTelegramConnection(workspaceId),getInstagramConnection(workspaceId),getValidVkConnection(workspaceId),getValidYouTubeConnection(workspaceId)]);
 const result:any={workspaceId,ok:true,telegram:null,instagram:null,vk:null,youtube:null,errors:[]};
 if(telegram){try{const members=await getTelegramMemberCount(telegram.token,telegram.channelId);const audience=await addAudienceSnapshot(telegram.channelId,members,workspaceId);let mtproto=null;if(isMtprotoConfigured()){try{mtproto=await fetchTelegramBroadcastStats(telegram.channelUsername?`@${telegram.channelUsername}`:telegram.channelId,workspaceId);}catch(e){result.errors.push(`MTProto: ${e instanceof Error?e.message:"ошибка"}`);}}result.telegram={audience,mtproto};}catch(e){result.errors.push(`Telegram: ${e instanceof Error?e.message:"ошибка"}`);}}
 if(instagram){try{result.instagram=await captureInstagramInsights(7,workspaceId);}catch(e){result.errors.push(`Instagram: ${e instanceof Error?e.message:"ошибка"}`);}}
 if(vk){try{const snapshot=await fetchVkAnalytics(vk);await saveVkAnalytics(vk.groupId,snapshot,workspaceId);result.vk=snapshot;}catch(e){result.errors.push(`VK: ${e instanceof Error?e.message:"ошибка"}`);}}
 if(youtube){try{const snapshot=await fetchYouTubeAnalytics(youtube);await saveYouTubeInsights(youtube.channelId,snapshot,workspaceId);result.youtube=snapshot;}catch(e){result.errors.push(`YouTube: ${e instanceof Error?e.message:"ошибка"}`);}}
 if(!telegram&&!instagram&&!vk&&!youtube)return{...result,skipped:true,reason:"Соцсети не подключены"}; const success=[result.telegram,result.instagram,result.vk,result.youtube].filter(Boolean).length; result.ok=!result.errors.length||success>0;return result;
}
async function run(request:Request){if(!authorized(request))return Response.json({ok:false,error:"Неверный CRON_SECRET"},{status:401});const workspaces=await db.workspace.findMany({select:{id:true}});const results=[];for(const ws of workspaces)results.push(await capture(ws.id));return Response.json({ok:results.every((x:any)=>x.ok),workspaces:results},{status:results.some((x:any)=>x.ok)?200:502});}
export const GET=run;export const POST=run;
