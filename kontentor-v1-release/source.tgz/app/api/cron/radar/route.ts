import { db } from "@/lib/db";
import { getRadarSettings } from "@/lib/radar-store";
import { scanRadar } from "@/lib/radar";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
function authorized(request: Request) { if (process.env.NODE_ENV !== "production") return true; const secret = process.env.CRON_SECRET; return Boolean(secret) && request.headers.get("authorization") === `Bearer ${secret}`; }

async function run(request: Request) {
  if (!authorized(request)) return Response.json({ ok: false, error: "Неверный CRON_SECRET" }, { status: 401 });
  const workspaces = await db.workspace.findMany({ select: { id: true } });
  const results: Array<{ workspaceId: string; ok: boolean; skipped?: boolean; result?: unknown; error?: string }> = [];
  for (const workspace of workspaces) {
    try {
      const settings = await getRadarSettings(workspace.id);
      if (!settings.topics.length && !settings.feeds.some((feed) => feed.enabled)) { results.push({ workspaceId: workspace.id, ok: true, skipped: true }); continue; }
      results.push({ workspaceId: workspace.id, ok: true, result: await scanRadar(settings, workspace.id) });
    } catch (error) { results.push({ workspaceId: workspace.id, ok: false, error: error instanceof Error ? error.message : "Radar cron завершился с ошибкой" }); }
  }
  return Response.json({ ok: results.every((x) => x.ok), workspaces: results }, { status: results.some((x) => x.ok) ? 200 : 502 });
}
export const GET = run; export const POST = run;
