import { db } from "@/lib/db";
import { getDuePublications, updatePublication } from "@/lib/publication-store";
import { publishRecordAcrossPlatforms } from "@/lib/multichannel-publisher";
import { updateStrategyPostByPublication } from "@/lib/strategy-store";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function authorized(request: Request) {
  if (process.env.NODE_ENV !== "production") return true;
  const secret = process.env.CRON_SECRET;
  return Boolean(secret) && request.headers.get("authorization") === `Bearer ${secret}`;
}

async function runWorkspace(workspaceId: string) {
  const due = (await getDuePublications(new Date(), workspaceId)).slice(0, 20);
  const results: Array<{ id: string; ok: boolean; status?: string; error?: string }> = [];
  for (const record of due) {
    await updatePublication(record.id, { status: "publishing", error: undefined }, workspaceId);
    try {
      const result = await publishRecordAcrossPlatforms(record, workspaceId);
      await updatePublication(record.id, {
        status: result.status,
        deliveries: result.deliveries,
        publishedAt: result.status !== "failed" ? new Date().toISOString() : undefined,
        messageId: result.telegram?.messageId,
        mediaMessageId: result.telegram?.mediaMessageId,
        publicLink: result.telegram?.publicLink,
        instagramMediaId: result.instagram?.mediaId,
        instagramPermalink: result.instagram?.permalink,
        vkPostId: result.vk?.postId,
        vkPublicLink: result.vk?.publicLink,
        youtubeVideoId: result.youtube?.videoId,
        youtubePublicLink: result.youtube?.publicLink,
        error: result.error,
        media: result.status === "published" ? undefined : record.media,
      }, workspaceId);
      await updateStrategyPostByPublication(record.id, { status: result.status === "published" ? "published" : result.status === "partial" ? "scheduled" : "failed" }, workspaceId);
      results.push({ id: record.id, ok: result.status !== "failed", status: result.status, error: result.error });
    } catch (error) {
      const message = error instanceof Error ? error.message : "Ошибка публикации";
      await updatePublication(record.id, { status: "failed", error: message }, workspaceId);
      await updateStrategyPostByPublication(record.id, { status: "failed" }, workspaceId);
      results.push({ id: record.id, ok: false, error: message });
    }
  }
  return results;
}

export async function POST(request: Request) {
  if (!authorized(request)) return Response.json({ ok: false, error: "Неверный CRON_SECRET" }, { status: 401 });
  try {
    const workspaces = await db.workspace.findMany({ select: { id: true } });
    const output: Array<{ workspaceId: string; processed: number; results: unknown[] }> = [];
    for (const workspace of workspaces) {
      const results = await runWorkspace(workspace.id);
      if (results.length) output.push({ workspaceId: workspace.id, processed: results.length, results });
    }
    return Response.json({ ok: true, processed: output.reduce((sum, item) => sum + item.processed, 0), workspaces: output });
  } catch (error) {
    return Response.json({ ok: false, error: error instanceof Error ? error.message : "Не удалось обработать очередь" }, { status: 500 });
  }
}
export async function GET(request: Request) { return POST(request); }
