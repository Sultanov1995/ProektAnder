"use client";

import { useEffect, useMemo, useState } from "react";
import { Sidebar } from "@/components/Sidebar";

type Feed = { id: string; name: string; url: string; enabled: boolean };
type Settings = { topics: string[]; excludeKeywords: string[]; feeds: Feed[]; lastScanAt?: string };
type RadarItem = {
  id: string; title: string; url: string; sourceName: string; sourceType: "news_search" | "rss";
  snippet?: string; publishedAt?: string; discoveredAt: string; matchedTopics: string[];
  relevance: number; novelty: number; freshness: number; quality: number; score: number;
  status: "new" | "drafted" | "skipped"; draftText?: string;
};

type ApiState = { settings: Settings; items: RadarItem[] };
const blank: Settings = { topics: [], excludeKeywords: [], feeds: [] };

function percent(value: number) { return Math.round(value * 100); }
function scoreTone(value: number) { return value >= .78 ? "hot" : value >= .62 ? "good" : "normal"; }
function formatDate(value?: string) {
  if (!value) return "дата не указана";
  const date = new Date(value);
  return new Intl.DateTimeFormat("ru-RU", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }).format(date);
}

export default function RadarPage() {
  const [settings, setSettings] = useState<Settings>(blank);
  const [items, setItems] = useState<RadarItem[]>([]);
  const [topicsText, setTopicsText] = useState("");
  const [excludeText, setExcludeText] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [draftBusy, setDraftBusy] = useState<string | null>(null);
  const [filter, setFilter] = useState<"active" | "new" | "drafted" | "skipped">("active");
  const [notice, setNotice] = useState<{ ok: boolean; text: string } | null>(null);

  async function load() {
    const res = await fetch("/api/radar/scan", { cache: "no-store" });
    const data = await res.json() as { ok: boolean } & Partial<ApiState>;
    if (!res.ok || !data.ok || !data.settings || !data.items) throw new Error("Не удалось загрузить Radar");
    setSettings(data.settings);
    setItems(data.items);
    setTopicsText(data.settings.topics.join("\n"));
    setExcludeText(data.settings.excludeKeywords.join(", "));
  }

  useEffect(() => { load().catch((error) => setNotice({ ok: false, text: error.message })).finally(() => setLoading(false)); }, []);

  const visible = useMemo(() => items.filter((item) => {
    if (filter === "active") return item.status !== "skipped";
    return item.status === filter;
  }), [items, filter]);

  const stats = useMemo(() => ({
    active: items.filter((item) => item.status !== "skipped").length,
    strong: items.filter((item) => item.status !== "skipped" && item.score >= .72).length,
    drafts: items.filter((item) => item.status === "drafted").length,
    sources: new Set(items.map((item) => item.sourceName)).size,
  }), [items]);

  function parseLines(value: string, max: number) {
    return [...new Set(value.split(/[\n,;]/).map((part) => part.trim()).filter((part) => part.length >= 2))].slice(0, max);
  }

  async function save() {
    setSaving(true); setNotice(null);
    try {
      const payload = { topics: parseLines(topicsText, 12), excludeKeywords: parseLines(excludeText, 30), feeds: settings.feeds };
      const res = await fetch("/api/radar/settings", { method: "PUT", headers: { "content-type": "application/json" }, body: JSON.stringify(payload) });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data.error || "Не удалось сохранить настройки");
      setSettings(data.settings); setNotice({ ok: true, text: "Настройки Radar сохранены." });
      return true;
    } catch (error) { setNotice({ ok: false, text: error instanceof Error ? error.message : "Ошибка сохранения" }); return false; }
    finally { setSaving(false); }
  }

  async function scan() {
    setScanning(true); setNotice(null);
    try {
      const saved = await save();
      if (!saved) return;
      const res = await fetch("/api/radar/scan", { method: "POST" });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data.error || "Поиск не выполнен");
      await load();
      const warning = data.errors?.length ? ` Часть источников недоступна: ${data.errors.length}.` : "";
      setNotice({ ok: true, text: `Radar проверил ${data.found} материалов и добавил ${data.added} новых.${warning}` });
    } catch (error) { setNotice({ ok: false, text: error instanceof Error ? error.message : "Ошибка Radar" }); }
    finally { setScanning(false); }
  }

  function addFeed() {
    setSettings((current) => ({ ...current, feeds: [...current.feeds, { id: `feed-${Date.now()}`, name: "Новый источник", url: "https://", enabled: true }] }));
  }

  function updateFeed(id: string, patch: Partial<Feed>) {
    setSettings((current) => ({ ...current, feeds: current.feeds.map((feed) => feed.id === id ? { ...feed, ...patch } : feed) }));
  }

  function removeFeed(id: string) {
    setSettings((current) => ({ ...current, feeds: current.feeds.filter((feed) => feed.id !== id) }));
  }

  async function patchItem(id: string, status: RadarItem["status"]) {
    const res = await fetch("/api/radar/item", { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify({ id, status }) });
    const data = await res.json();
    if (!res.ok || !data.ok) throw new Error(data.error || "Не удалось обновить материал");
    setItems((current) => current.map((item) => item.id === id ? data.item : item));
  }

  async function createDraft(id: string) {
    setDraftBusy(id); setNotice(null);
    try {
      const res = await fetch("/api/radar/draft", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ id }) });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data.error || "Не удалось создать черновик");
      setItems((current) => current.map((item) => item.id === id ? { ...item, status: "drafted", draftText: data.text } : item));
      setNotice({ ok: true, text: "ИИ подготовил оригинальный черновик. Проверьте его перед публикацией." });
    } catch (error) { setNotice({ ok: false, text: error instanceof Error ? error.message : "Ошибка ИИ" }); }
    finally { setDraftBusy(null); }
  }

  function openEditor(item: RadarItem) {
    if (!item.draftText) return;
    sessionStorage.setItem("kontentor:radar-draft", item.draftText);
    window.location.href = "/create?from=radar";
  }

  return (
    <div className="shell">
      <Sidebar active="AI Радар" />
      <main className="main radar-main">
        <div className="topbar radar-topbar">
          <div>
            <div className="eyebrow">KONTENTOR Radar</div>
            <h1>Находит темы раньше, чем закончится контент-план.</h1>
            <p className="sub">Свежие материалы → защита от дублей → оценка темы → оригинальный черновик для Telegram.</p>
          </div>
          <button className="primary radar-scan" onClick={() => void scan()} disabled={scanning || saving}>{scanning ? "Ищем материалы…" : "⌁ Запустить Radar"}</button>
        </div>

        {notice && <div className={`notice ${notice.ok ? "ok" : "error"}`}>{notice.text}</div>}

        <section className="radar-stats">
          <div className="card mini-stat"><span>Активные находки</span><b>{stats.active}</b></div>
          <div className="card mini-stat"><span>Сильные темы</span><b>{stats.strong}</b></div>
          <div className="card mini-stat"><span>Черновики</span><b>{stats.drafts}</b></div>
          <div className="card mini-stat"><span>Источники</span><b>{stats.sources}</b></div>
        </section>

        <div className="radar-layout">
          <aside className="card radar-settings">
            <div className="section-heading"><div><div className="eyebrow">Настройка поиска</div><h2>Тематика</h2></div></div>
            <label className="radar-field"><span>Темы и ключевые направления</span><textarea value={topicsText} onChange={(e) => setTopicsText(e.target.value)} placeholder={"нейросети\nпродвижение в Telegram\nконтент-маркетинг"} /></label>
            <p className="microcopy">Каждая строка — отдельное направление. Radar использует их для поиска и оценки релевантности.</p>
            <label className="radar-field"><span>Исключить</span><input value={excludeText} onChange={(e) => setExcludeText(e.target.value)} placeholder="вакансии, курсы, ставки" /></label>

            <div className="radar-feeds-head"><div><div className="eyebrow">Свои источники</div><h2>RSS / Atom</h2></div><button type="button" className="chip" onClick={addFeed}>+ Добавить</button></div>
            <div className="feed-list">
              {settings.feeds.length === 0 && <div className="feed-empty">Необязательно. Можно добавить отраслевые СМИ, блоги или корпоративные RSS.</div>}
              {settings.feeds.map((feed) => (
                <div className="feed-editor" key={feed.id}>
                  <div className="feed-row"><input value={feed.name} onChange={(e) => updateFeed(feed.id, { name: e.target.value })} aria-label="Название RSS" /><label className="feed-toggle"><input type="checkbox" checked={feed.enabled} onChange={(e) => updateFeed(feed.id, { enabled: e.target.checked })} /> вкл.</label></div>
                  <input value={feed.url} onChange={(e) => updateFeed(feed.id, { url: e.target.value })} aria-label="RSS URL" />
                  <button type="button" className="text-button" onClick={() => removeFeed(feed.id)}>Удалить источник</button>
                </div>
              ))}
            </div>
            <button className="secondary radar-save" disabled={saving} onClick={() => void save()}>{saving ? "Сохраняем…" : "Сохранить настройки"}</button>
            <div className="radar-cron-info"><b>Автопоиск</b><span>В production вызывайте <code>/api/cron/radar</code> по расписанию. Radar будет пополнять ленту без открытого браузера.</span>{settings.lastScanAt && <small>Последняя проверка: {formatDate(settings.lastScanAt)}</small>}</div>
          </aside>

          <section className="radar-results">
            <div className="radar-results-head">
              <div><div className="eyebrow">Лента находок</div><h2>{loading ? "Загрузка…" : `${visible.length} материалов`}</h2></div>
              <div className="radar-filters">
                {(["active", "new", "drafted", "skipped"] as const).map((key) => <button key={key} className={filter === key ? "active" : ""} onClick={() => setFilter(key)}>{key === "active" ? "Актуальные" : key === "new" ? "Новые" : key === "drafted" ? "Черновики" : "Скрытые"}</button>)}
              </div>
            </div>

            {!loading && visible.length === 0 && <div className="card radar-empty"><b>Radar пока пуст.</b><span>Добавьте тематику слева и нажмите «Запустить Radar».</span></div>}

            <div className="radar-items">
              {visible.map((item) => (
                <article className={`card radar-item ${item.status === "skipped" ? "is-skipped" : ""}`} key={item.id}>
                  <div className="radar-item-main">
                    <div className="radar-source-line"><span>{item.sourceType === "rss" ? "RSS" : "ПОИСК"}</span><b>{item.sourceName}</b><time>{formatDate(item.publishedAt)}</time></div>
                    <h3>{item.title}</h3>
                    {item.snippet && <p>{item.snippet}</p>}
                    <div className="radar-tags">{item.matchedTopics.slice(0, 4).map((topic) => <span key={topic}>{topic}</span>)}</div>
                    <div className="radar-source-actions"><a href={item.url} target="_blank" rel="noreferrer">Открыть источник ↗</a>{item.status === "skipped" ? <button className="text-button" onClick={() => void patchItem(item.id, "new")}>Вернуть</button> : <button className="text-button" onClick={() => void patchItem(item.id, "skipped")}>Скрыть</button>}</div>
                    {item.draftText && <div className="radar-draft"><div className="eyebrow">Черновик KONTENTOR</div><p>{item.draftText}</p></div>}
                  </div>
                  <aside className="radar-score-panel">
                    <div className={`radar-score ${scoreTone(item.score)}`}><strong>{percent(item.score)}</strong><span>оценка</span></div>
                    <div className="radar-metrics"><span><i style={{ width: `${percent(item.relevance)}%` }} />Релевантность {percent(item.relevance)}%</span><span><i style={{ width: `${percent(item.novelty)}%` }} />Новизна {percent(item.novelty)}%</span><span><i style={{ width: `${percent(item.freshness)}%` }} />Свежесть {percent(item.freshness)}%</span></div>
                    {item.draftText ? <button className="primary compact-button" onClick={() => openEditor(item)}>Открыть в редакторе</button> : <button className="primary compact-button" disabled={draftBusy === item.id || item.status === "skipped"} onClick={() => void createDraft(item.id)}>{draftBusy === item.id ? "ИИ пишет…" : "Создать пост с ИИ"}</button>}
                  </aside>
                </article>
              ))}
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}
