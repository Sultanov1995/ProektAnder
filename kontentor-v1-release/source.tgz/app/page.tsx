import { redirect } from "next/navigation";import { Dashboard } from "@/components/Dashboard";import { Sidebar } from "@/components/Sidebar";import { getCurrentUser } from "@/lib/auth";
export const dynamic="force-dynamic";
export default async function Home(){const current=await getCurrentUser();if(!current)return redirect("/login");if(!current.user.onboardingCompletedAt)redirect("/onboarding");return <div className="shell"><Sidebar active="Главная"/><Dashboard/></div>}
