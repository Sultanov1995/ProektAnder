import { ComingSoon } from "@/components/ComingSoon";
export default function Page(){return <ComingSoon active="Конкуренты" title="Конкуренты" description="Мониторинг публичных аккаунтов и тем подключим после базовой аналитики собственных каналов."/>}
