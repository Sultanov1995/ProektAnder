import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "KONTENTOR — AI Social Intelligence",
    short_name: "KONTENTOR",
    description: "Ваши соцсети. Один интеллект.",
    start_url: "/",
    scope: "/",
    display: "standalone",
    background_color: "#0B0F14",
    theme_color: "#0B0F14",
    lang: "ru",
    icons: [
      { src: "/kontentor-icon-192.png", sizes: "192x192", type: "image/png", purpose: "any maskable" },
      { src: "/kontentor-icon-512.png", sizes: "512x512", type: "image/png", purpose: "any maskable" },
    ],
  };
}
