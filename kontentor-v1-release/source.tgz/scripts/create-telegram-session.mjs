import "dotenv/config";
import { TelegramClient } from "teleproto";
import { StringSession } from "teleproto/sessions";
import { createInterface } from "node:readline/promises";
import { stdin as input, stdout as output } from "node:process";

const apiId = Number(process.env.TELEGRAM_API_ID || 0);
const apiHash = process.env.TELEGRAM_API_HASH || "";
if (!apiId || !apiHash) {
  console.error("Сначала задайте TELEGRAM_API_ID и TELEGRAM_API_HASH в окружении.");
  process.exit(1);
}

const rl = createInterface({ input, output });
const client = new TelegramClient(new StringSession(""), apiId, apiHash, { connectionRetries: 5 });

try {
  await client.start({
    phoneNumber: () => rl.question("Номер Telegram (+7...): "),
    phoneCode: () => rl.question("Код из Telegram: "),
    password: () => rl.question("Пароль 2FA (если включён): "),
    onError: (error) => console.error("Telegram:", error instanceof Error ? error.message : error),
  });
  const me = await client.getMe();
  console.log(`\nВход выполнен: ${me.username ? `@${me.username}` : me.firstName || "Telegram user"}`);
  console.log("\nСкопируйте строку ниже в .env. НЕ публикуйте её и не отправляйте третьим лицам:\n");
  console.log(`TELEGRAM_MT_SESSION="${client.session.save()}"`);
} finally {
  rl.close();
  await client.disconnect().catch(() => undefined);
}
