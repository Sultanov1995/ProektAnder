import { existsSync, readFileSync } from "node:fs";
import { resolve } from "node:path";

const root = process.cwd();
const requiredFiles = [
  "app/login/page.tsx",
  "app/register/page.tsx",
  "app/onboarding/page.tsx",
  "app/workspaces/page.tsx",
  "app/team/page.tsx",
  "app/billing/page.tsx",
  "app/content/page.tsx",
  "app/socials/vk/page.tsx",
  "app/socials/youtube/page.tsx",
  "app/api/auth/login/route.ts",
  "app/api/auth/register/route.ts",
  "app/api/auth/me/route.ts",
  "app/api/workspaces/route.ts",
  "app/api/team/route.ts",
  "app/api/team/invite/route.ts",
  "app/api/billing/route.ts",
  "app/api/vk/oauth/start/route.ts",
  "app/api/youtube/oauth/start/route.ts",
  "app/api/media/edit/route.ts",
  "lib/auth.ts",
  "lib/session-token.ts",
  "lib/password.ts",
  "lib/workspace-context.ts",
  "lib/multichannel-publisher.ts",
  "proxy.ts",
  "app/manifest.ts",
  "public/sw.js",
  "public/kontentor-logo-approved.png",
  "public/kontentor-icon-approved-tight.png",
  "public/kontentor-icon-192.png",
  "public/kontentor-icon-512.png",
];
const missing = requiredFiles.filter((file) => !existsSync(resolve(root, file)));
if (missing.length) {
  console.error("Missing v1.0 files:\n" + missing.join("\n"));
  process.exit(1);
}

const pkg = JSON.parse(readFileSync(resolve(root, "package.json"), "utf8"));
if (pkg.version !== "1.0.1") throw new Error(`Expected package version 1.0.1, got ${pkg.version}`);

const env = readFileSync(resolve(root, ".env.example"), "utf8");
for (const key of [
  "AUTH_SECRET",
  "APP_ENCRYPTION_KEY",
  "CRON_SECRET",
  "INSTAGRAM_APP_ID",
  "VK_ID_APP_ID",
  "GOOGLE_CLIENT_ID",
  "GOOGLE_CLIENT_SECRET",
  "OPENAI_API_KEY",
]) {
  if (!env.includes(`${key}=`)) throw new Error(`Missing ${key} in .env.example`);
}

const health = readFileSync(resolve(root, "app/api/health/route.ts"), "utf8");
if (!/version\s*:\s*["\']1\.0\.1["\']/.test(health)) throw new Error("Health endpoint version is not 1.0.1");

const publisher = readFileSync(resolve(root, "lib/multichannel-publisher.ts"), "utf8");
for (const platform of ["telegram", "instagram", "vk", "youtube"]) {
  if (!publisher.includes(`platform===\"${platform}\"`) && !publisher.includes(`platform === \"${platform}\"`)) {
    throw new Error(`Publisher is missing ${platform}`);
  }
}

const logo = readFileSync(resolve(root, "components/Logo.tsx"), "utf8");
if (!logo.includes("/kontentor-logo-approved.png") || !logo.includes("/kontentor-icon-approved-tight.png")) {
  throw new Error("Approved KONTENTOR brand assets are not wired into Logo.tsx");
}
if (logo.includes("kontentor-mark.svg")) throw new Error("Logo.tsx still references the non-canonical SVG logo");

const proxy = readFileSync(resolve(root, "proxy.ts"), "utf8");
for (const guard of ["AUTH_SECRET", "sameOrigin", "analyst"]) {
  if (!proxy.includes(guard)) throw new Error(`Security proxy is missing ${guard}`);
}

const schema = readFileSync(resolve(root, "prisma/schema.prisma"), "utf8");
for (const model of ["model User", "model Workspace", "model WorkspaceMember", "model WorkspaceInvite", "model Subscription", "model AuditLog"]) {
  if (!schema.includes(model)) throw new Error(`Prisma schema is missing ${model}`);
}

console.log("KONTENTOR v1.0.1 hardening self-check: OK");
