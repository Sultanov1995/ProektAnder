import "dotenv/config";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { PrismaPg } from "@prisma/adapter-pg";
import { PrismaClient } from "../generated/prisma/client.js";

if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL не настроен");
const db = new PrismaClient({ adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL }) });
const dir = process.env.KONTENTOR_DATA_DIR || path.join(process.cwd(), ".data");
async function json(name, fallback=null){ try{return JSON.parse(await readFile(path.join(dir,name),"utf8"));}catch(e){if(e?.code==="ENOENT")return fallback;throw e;} }
let imported=0;

const automation=await json("automation-settings.json");
if(automation){await db.appSetting.upsert({where:{key:"automation.settings"},create:{key:"automation.settings",value:automation},update:{value:automation}});imported++;}
const radarSettings=await json("radar-settings.json");
if(radarSettings){await db.appSetting.upsert({where:{key:"radar.settings"},create:{key:"radar.settings",value:radarSettings},update:{value:radarSettings}});imported++;}
for(const item of await json("radar-items.json",[])){await db.radarRecord.upsert({where:{fingerprint:item.fingerprint},create:{id:item.id,fingerprint:item.fingerprint,title:item.title,url:item.url,sourceName:item.sourceName,sourceType:item.sourceType,score:Number(item.score||0),status:item.status||"new",discoveredAt:new Date(item.discoveredAt||Date.now()),payload:item},update:{title:item.title,url:item.url,sourceName:item.sourceName,sourceType:item.sourceType,score:Number(item.score||0),status:item.status||"new",payload:item}});imported++;}
for(const item of await json("publications.json",[])){await db.publicationQueue.upsert({where:{id:item.id},create:{id:item.id,payload:item,status:item.status||"review",scheduledFor:item.scheduledFor?new Date(item.scheduledFor):null,publishedAt:item.publishedAt?new Date(item.publishedAt):null,createdAt:new Date(item.createdAt||Date.now())},update:{payload:item,status:item.status||"review",scheduledFor:item.scheduledFor?new Date(item.scheduledFor):null,publishedAt:item.publishedAt?new Date(item.publishedAt):null}});imported++;}
for(const item of await json("telegram-analytics.json",[])){await db.analyticsEvent.create({data:{id:item.id,network:"TELEGRAM",accountRef:item.channelId,kind:"audience",capturedAt:new Date(item.capturedAt),payload:{members:item.members}}}).catch(()=>{});imported++;}
for(const item of await json("telegram-mtproto-analytics.json",[])){const {id,capturedAt,channelRef,...payload}=item;await db.analyticsEvent.create({data:{id,network:"TELEGRAM",accountRef:channelRef,kind:"mtproto",capturedAt:new Date(capturedAt),payload}}).catch(()=>{});imported++;}
const strategy=await json("weekly-strategy.json");
if(strategy){await db.strategyPlan.upsert({where:{id:strategy.id},create:{id:strategy.id,weekStart:strategy.weekStart,generatedAt:new Date(strategy.generatedAt),payload:strategy},update:{weekStart:strategy.weekStart,generatedAt:new Date(strategy.generatedAt),payload:strategy}});imported++;}
const tg=await json("telegram-connection.json");
if(tg){await db.connectionState.upsert({where:{network:"TELEGRAM"},create:{network:"TELEGRAM",externalId:tg.channelId,username:tg.channelUsername,displayName:tg.channelTitle,tokenEnc:tg.tokenEnc,connectedAt:new Date(tg.connectedAt),metadata:{botId:tg.botId,botUsername:tg.botUsername,botName:tg.botName}},update:{externalId:tg.channelId,username:tg.channelUsername,displayName:tg.channelTitle,tokenEnc:tg.tokenEnc,connectedAt:new Date(tg.connectedAt),metadata:{botId:tg.botId,botUsername:tg.botUsername,botName:tg.botName}}});imported++;}
const ig=await json("instagram-connection.json");
if(ig){await db.connectionState.upsert({where:{network:"INSTAGRAM"},create:{network:"INSTAGRAM",externalId:ig.userId,username:ig.username,displayName:ig.username,tokenEnc:ig.accessTokenEnc,connectedAt:new Date(ig.connectedAt),expiresAt:ig.expiresAt?new Date(ig.expiresAt):null,metadata:{accountType:ig.accountType}},update:{externalId:ig.userId,username:ig.username,displayName:ig.username,tokenEnc:ig.accessTokenEnc,connectedAt:new Date(ig.connectedAt),expiresAt:ig.expiresAt?new Date(ig.expiresAt):null,metadata:{accountType:ig.accountType}}});imported++;}
console.log(`KONTENTOR: импорт завершён. Обработано записей/настроек: ${imported}`);
await db.$disconnect();
