# KONTENTOR — Changelog

## v1.1.0 — Channel Intelligence

- После подключения Telegram, Instagram, VK или YouTube появляется кнопка экспресс-анализа площадки.
- Анализ запускает свежий сбор метрик платформы и сохраняет результат в PostgreSQL.
- Результат включает ключевые показатели, сильные стороны, риски, рекомендации и лучший доступный контент.
- Telegram использует Bot API и, если настроен MTProto, расширенные просмотры/реакции/пересылки; без MTProto явно показывает ограничение данных.
- Instagram анализирует 7-дневные Insights и последние доступные публикации.
- VK анализирует последние посты стены и топ публикаций по просмотрам.
- YouTube анализирует агрегированные метрики канала за 28 дней.
- Telegram теперь принимает не только @username и chat_id, но и ссылки вида https://t.me/channel.
- Сохранены утверждённые логотип и дизайн KONTENTOR variant 2.

## v1.0.1 — Production hardening

- Усилен public healthcheck: внутренние ошибки PostgreSQL больше не возвращаются клиенту.
- Добавлены security headers и отключён X-Powered-By.
- Добавлен persistent rate-limit для входа и регистрации на PostgreSQL.
- Сессии сокращены до 7 дней и получили server-side sessionVersion для отзыва устаревших токенов.
- `requireSession()` повторно проверяет membership и актуальную версию сессии по БД.
- Добавлен AuditLog foundation и модель AuthRateLimit.
- Зафиксирован approved KONTENTOR variant 2: логотип и дизайн не изменялись.

## v1.0.0

- Зафиксирован и подключён **точный согласованный бренд KONTENTOR variant 2**; UI и PWA используют канонические PNG-assets из бренд-борда, а не похожую перерисовку.
- Добавлены регистрация, вход, подписанные сессии и onboarding.
- Добавлена SaaS-модель рабочих пространств: один пользователь может иметь несколько проектов.
- Добавлены роли owner / admin / editor / analyst и приглашения команды по одноразовой ссылке.
- Добавлен тарифный каркас Start / Pro / Team, trial 14 дней и экран Billing без фиктивного эквайринга.
- Все runtime stores и cron-процессы переведены на явный workspace scope.
- Добавлена production content library и управление workspace/team/billing из интерфейса.
- Добавлена PWA с утверждёнными иконками KONTENTOR и service worker без кэширования API.
- Усилена безопасность: HMAC session, scrypt password hash, Origin guard для mutations, read-only Analyst, production security headers.
- `/api/health` обновлён до `1.0.0` и проверяет PostgreSQL.
- Сохранены возможности v0.9: Telegram, Instagram, VK, YouTube, AI Radar, AI Media Studio, analytics, AI strategist, calendar, scheduler/autopilot, S3-compatible media.

## v0.9.0

- VK ID OAuth 2.1 + PKCE, VK Analytics.
- YouTube OAuth/upload/analytics.
- AI Media Studio 2.0 с редактированием изображений.
- Единый editor/calendar/delivery status для Telegram + Instagram + VK + YouTube.

## v0.8.0

- VK, S3-compatible media library, AI Media Studio.

## v0.7.0

- PostgreSQL/Prisma как основной runtime storage, Instagram Insights.
