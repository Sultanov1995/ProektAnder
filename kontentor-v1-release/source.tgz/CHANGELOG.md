# KONTENTOR — Changelog

## v1.0.1 — Production hardening

- Усилен public healthcheck: внутренние ошибки PostgreSQL больше не возвращаются клиенту.
- Добавлены security headers и отключён X-Powered-By.
- Добавлен persistent rate-limit для входа и регистрации на PostgreSQL.
- Сессии сокращены до 7 дней и получили server-side sessionVersion для отзыва устаревших токенов.
- `requireSession()` повторно проверяет membership и актуальную версию сессии по БД.
- Добавлен AuditLog foundation и модель AuthRateLimit.
- Зафиксирован approved KONTENTOR variant 2: логотип и дизайн не изменялись.
- Все top-level зависимости закреплены точными версиями; AWS SDK обновлён до 3.1142.0.
- Production Docker build содержит обязательный `npm audit --audit-level=high`; проверка Railway: **0 vulnerabilities**.

## v1.0.0

- Зафиксирован и подключён **точный согласованный бренд KONTENTOR variant 2**; UI и PWA используют канонические PNG-assets из бренд-борда, а не похожую перерисовку.
- Добавлены регистрация, вход, подписанные сессии и onboarding.
- Добавлена SaaS-модель рабочих пространств: один пользователь может иметь несколько проектов.
- Добавлены роли owner / admin / editor / analyst и приглашения команды по одноразовой ссылке.
- Добавлен тарифный каркас Start / Pro / Team, trial 14 дней и экран Billing без фиктивного эквайринга.
- Все runtime stores и cron-процессы переведены на явный workspace scope.
- Добавлена production content library и управление workspace/team/billing из интерфейса.
- Добавлена PWA с утверждёнными иконками KONTENTOR и service worker без кэширования API.
- Усилена безопасность: HMAC session, scrypt password hash, Origin guard для mutations, read-only Analyst, production security headers.
- `/api/health` обновлён до `1.0.0` и проверяет PostgreSQL.
- Сохранены возможности v0.9: Telegram, Instagram, VK, YouTube, AI Radar, AI Media Studio, analytics, AI strategist, calendar, scheduler/autopilot, S3-compatible media.

## v0.9.0

- VK ID OAuth 2.1 + PKCE, VK Analytics.
- YouTube OAuth/upload/analytics.
- AI Media Studio 2.0 с редактированием изображений.
- Единый editor/calendar/delivery status для Telegram + Instagram + VK + YouTube.

## v0.8.0

- VK, S3-compatible media library, AI Media Studio.

## v0.7.0

- PostgreSQL/Prisma как основной runtime storage, Instagram Insights.
